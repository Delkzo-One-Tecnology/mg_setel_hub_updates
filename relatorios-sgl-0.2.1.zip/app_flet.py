from __future__ import annotations

import os
import threading
import time
from datetime import datetime
from pathlib import Path

import flet as ft
import keyring

from app import (
    CONTRACTS,
    KEYRING_SERVICE,
    Cancelled,
    Credentials,
    Processor,
    credential_key,
    load_settings,
    save_settings,
)


VERSION = "0.2.1"
GREEN = "#168270"
GREEN_LIGHT = "#E0F3EE"
BLUE = "#2866A5"
BACKGROUND = "#EEF3F7"
SURFACE = "#FFFFFF"
TEXT = "#172333"
MUTED = "#687B89"
BORDER = "#DCE5EA"
ERROR = "#B33A3A"


class RelatoriosSGLApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.settings = load_settings()
        self.stop_event = threading.Event()
        self.running = False
        self.started_at: float | None = None
        self.output_result: Path | None = None

        self.contract = ft.Dropdown(
            label="Contrato",
            value="Mantiqueira",
            options=[ft.dropdown.Option(item) for item in CONTRACTS],
            border_color=BORDER,
            focused_border_color=GREEN,
            bgcolor=SURFACE,
            expand=True,
        )
        self.reference = ft.TextField(
            label="Referência",
            value=datetime.now().strftime("%m/%Y"),
            hint_text="MM/AAAA",
            border_color=BORDER,
            focused_border_color=GREEN,
            bgcolor=SURFACE,
            width=190,
        )
        self.output = ft.TextField(
            label="Pasta de saída",
            value=self.settings.get("output", str(Path.home() / "Downloads")),
            border_color=BORDER,
            focused_border_color=GREEN,
            bgcolor=SURFACE,
            read_only=True,
            expand=True,
        )
        self.stage = ft.Text("Pronto para iniciar", size=15, weight=ft.FontWeight.W_700, color=TEXT)
        self.stage_detail = ft.Text("Configure o contrato e a referência para começar.", size=11, color=MUTED)
        self.progress = ft.ProgressBar(value=0, color=GREEN, bgcolor="#DDE7EB", height=7)
        self.progress_count = ft.Text("0/0 etapas", size=11, weight=ft.FontWeight.W_600, color=MUTED)
        self.elapsed = ft.Text("00:00", size=11, weight=ft.FontWeight.W_600, color=MUTED)
        self.log = ft.ListView(expand=True, spacing=7, auto_scroll=True, padding=0)
        self.status_badge = self.badge("AGUARDANDO", GREEN_LIGHT, GREEN)
        self.start_button = ft.ElevatedButton(
            "Iniciar processo completo",
            icon=ft.Icons.PLAY_ARROW_ROUNDED,
            bgcolor=GREEN,
            color="white",
            height=46,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=9)),
            on_click=self.start,
        )
        self.stop_button = ft.OutlinedButton(
            "Interromper",
            icon=ft.Icons.STOP_ROUNDED,
            disabled=True,
            height=46,
            style=ft.ButtonStyle(color=ERROR, side=ft.BorderSide(1, "#E3BDBD"), shape=ft.RoundedRectangleBorder(radius=9)),
            on_click=self.stop,
        )
        self.open_output_button = ft.OutlinedButton(
            "Abrir resultado",
            icon=ft.Icons.FOLDER_OPEN_ROUNDED,
            disabled=True,
            height=40,
            on_click=self.open_result,
        )

        self.folder_picker = ft.FilePicker(on_result=self.folder_selected)
        self.page.overlay.append(self.folder_picker)
        self.configure_page()
        self.render()

    def configure_page(self):
        self.page.title = f"Relatórios e Consolidação SGL · v{VERSION}"
        self.page.bgcolor = BACKGROUND
        self.page.padding = 0
        self.page.window.width = 1180
        self.page.window.height = 760
        self.page.window.min_width = 980
        self.page.window.min_height = 660
        self.page.theme = ft.Theme(font_family="Segoe UI", color_scheme_seed=GREEN)

    @staticmethod
    def badge(text: str, background: str, color: str):
        return ft.Container(
            content=ft.Text(text, size=9, weight=ft.FontWeight.W_700, color=color),
            bgcolor=background,
            border_radius=20,
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
        )

    @staticmethod
    def card(content, padding=20, expand=False):
        return ft.Container(
            content=content,
            bgcolor=SURFACE,
            border=ft.border.all(1, BORDER),
            border_radius=14,
            padding=padding,
            shadow=ft.BoxShadow(blur_radius=18, color="#0B22330A", offset=ft.Offset(0, 5)),
            expand=expand,
        )

    def render(self):
        configuration = self.card(
            ft.Column([
                ft.Row([
                    ft.Column([
                        ft.Text("Configuração do processo", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Informe os dados da extração que será executada no SGL.", size=11, color=MUTED),
                    ], spacing=3, expand=True),
                    ft.OutlinedButton("Credenciais", icon=ft.Icons.KEY_ROUNDED, on_click=self.open_credentials),
                ]),
                ft.Container(height=5),
                ft.Row([
                    self.contract,
                    self.reference,
                    self.output,
                    ft.IconButton(
                        icon=ft.Icons.FOLDER_OPEN_ROUNDED,
                        tooltip="Escolher pasta",
                        icon_color=GREEN,
                        on_click=lambda _: self.folder_picker.get_directory_path(dialog_title="Selecione a pasta de saída"),
                    ),
                ], spacing=12),
                ft.Row([self.start_button, self.stop_button], spacing=10),
            ], spacing=13),
        )

        progress_card = self.card(
            ft.Column([
                ft.Row([
                    ft.Column([self.stage, self.stage_detail], spacing=3, expand=True),
                    self.status_badge,
                ]),
                self.progress,
                ft.Row([
                    ft.Row([ft.Icon(ft.Icons.FORMAT_LIST_NUMBERED_ROUNDED, size=15, color=MUTED), self.progress_count], spacing=5),
                    ft.Row([ft.Icon(ft.Icons.TIMER_OUTLINED, size=15, color=MUTED), self.elapsed], spacing=5),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], spacing=12),
        )

        log_card = self.card(
            ft.Column([
                ft.Row([
                    ft.Column([
                        ft.Text("Atividade da execução", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Acompanhe downloads, tentativas e arquivos processados.", size=10, color=MUTED),
                    ], spacing=2, expand=True),
                    self.open_output_button,
                ]),
                ft.Container(
                    content=self.log,
                    bgcolor="#102C42",
                    border_radius=10,
                    padding=14,
                    expand=True,
                ),
            ], spacing=12, expand=True),
            expand=True,
        )

        main = ft.Container(
            expand=True,
            padding=ft.padding.only(left=30, right=30, top=25, bottom=25),
            content=ft.Column([
                ft.Row([
                    ft.Column([
                        ft.Text("SGL · RELATÓRIOS OPERACIONAIS", size=10, color=GREEN, weight=ft.FontWeight.BOLD),
                        ft.Text("Relatórios e consolidação", size=27, color=TEXT, weight=ft.FontWeight.BOLD),
                        ft.Text("Baixe, processe e consolide as leituras sem trocar de aplicativo.", size=12, color=MUTED),
                    ], spacing=3, expand=True),
                    self.badge(f"VERSÃO {VERSION}", "#E6EDF8", BLUE),
                ]),
                configuration,
                progress_card,
                log_card,
            ], spacing=16, expand=True),
        )
        self.page.add(main)

    def folder_selected(self, event: ft.FilePickerResultEvent):
        if event.path:
            self.output.value = event.path
            self.page.update()

    def show_message(self, title: str, message: str, error=False):
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(title),
            content=ft.Text(message, color=ERROR if error else TEXT),
            actions=[ft.TextButton("Fechar", on_click=lambda _: self.close_dialog(dialog))],
        )
        self.page.open(dialog)

    def close_dialog(self, dialog):
        self.page.close(dialog)

    def open_credentials(self, _):
        contract = self.contract.value
        controls = []
        fields = {}
        for city in CONTRACTS[contract]:
            key = credential_key(contract, city)
            user = self.settings.setdefault("users", {}).get(key, "")
            username = ft.TextField(label=f"Usuário · {city}", value=user, border_color=BORDER, expand=True)
            password = ft.TextField(label="Senha", password=True, can_reveal_password=True, border_color=BORDER, width=230)
            fields[city] = (username, password)
            controls.append(ft.Row([username, password], spacing=10))

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Credenciais · {contract}", weight=ft.FontWeight.BOLD),
            content=ft.Container(
                content=ft.Column([
                    ft.Text("As senhas serão armazenadas pelo Gerenciador de Credenciais do Windows.", size=10, color=MUTED),
                    *controls,
                ], scroll=ft.ScrollMode.AUTO, spacing=10),
                width=650,
                height=min(520, 86 + len(controls) * 66),
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda _: self.close_dialog(dialog)),
                ft.ElevatedButton("Salvar credenciais", bgcolor=GREEN, color="white", on_click=lambda _: self.save_credentials(dialog, contract, fields)),
            ],
        )
        self.page.open(dialog)

    def save_credentials(self, dialog, contract, fields):
        saved = 0
        for city, (username, password) in fields.items():
            key = credential_key(contract, city)
            if username.value.strip():
                self.settings["users"][key] = username.value.strip()
            if password.value:
                keyring.set_password(KEYRING_SERVICE, key, password.value)
            if username.value.strip() and (password.value or keyring.get_password(KEYRING_SERVICE, key)):
                saved += 1
        save_settings(self.settings)
        self.close_dialog(dialog)
        self.show_message("Credenciais salvas", f"{saved} credencial(is) configurada(s) para {contract}.")

    def get_credentials(self):
        contract = self.contract.value
        result = {}
        missing = []
        for city in CONTRACTS[contract]:
            key = credential_key(contract, city)
            username = self.settings.get("users", {}).get(key, "")
            password = keyring.get_password(KEYRING_SERVICE, key)
            if not username or not password:
                missing.append(city)
            else:
                result[city] = Credentials(username, password)
        if missing:
            self.show_message("Credenciais pendentes", "Cadastre usuário e senha para:\n\n" + "\n".join(missing), True)
            return None
        return result

    def start(self, _):
        try:
            datetime.strptime(self.reference.value.strip(), "%m/%Y")
        except ValueError:
            self.show_message("Referência inválida", "Informe o período no formato MM/AAAA.", True)
            return
        credentials = self.get_credentials()
        if credentials is None:
            return
        output = Path(self.output.value.strip())
        try:
            output.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self.show_message("Pasta inválida", str(exc), True)
            return

        self.settings["output"] = str(output)
        save_settings(self.settings)
        self.running = True
        self.started_at = time.time()
        self.stop_event.clear()
        self.output_result = None
        self.log.controls.clear()
        self.progress.value = 0
        self.progress_count.value = "0/0 etapas"
        self.stage.value = "Preparando o ambiente"
        self.stage_detail.value = "O navegador será iniciado para consultar o SGL."
        self.status_badge.content.value = "PROCESSANDO"
        self.status_badge.bgcolor = "#FFF2D8"
        self.status_badge.content.color = "#9B6508"
        self.start_button.disabled = True
        self.stop_button.disabled = False
        self.open_output_button.disabled = True
        self.add_log(f"Iniciando {self.contract.value} · {self.reference.value}", "info")
        self.page.update()

        contract = self.contract.value
        reference = self.reference.value.strip()

        def worker():
            emit = self.receive_event
            try:
                result = Processor(emit, self.stop_event).run(contract, reference, output, credentials)
                self.finished(result)
            except Cancelled:
                self.cancelled()
            except Exception as exc:
                self.failed(str(exc))

        threading.Thread(target=worker, daemon=True).start()
        threading.Thread(target=self.clock_loop, daemon=True).start()

    def receive_event(self, *event):
        kind = event[0]
        if kind == "stage":
            self.stage.value = event[1]
            self.stage_detail.value = "Download e processamento automático em andamento."
        elif kind == "log":
            self.add_log(event[1], "warning" if str(event[1]).startswith("⚠") else "success")
        elif kind == "progress":
            done, total = event[1], event[2]
            self.progress.value = done / total if total else 0
            self.progress_count.value = f"{done}/{total} etapas"
        self.safe_update()

    def add_log(self, message: str, kind="info"):
        colors = {"success": "#63D8B9", "warning": "#F0BF63", "error": "#FF8F8F", "info": "#C9D8E2"}
        self.log.controls.append(
            ft.Row([
                ft.Text(datetime.now().strftime("%H:%M:%S"), size=9, color="#7890A2", width=58),
                ft.Text(message, size=10, color=colors.get(kind, "#C9D8E2"), selectable=True, expand=True),
            ], vertical_alignment=ft.CrossAxisAlignment.START)
        )

    def clock_loop(self):
        while self.running and self.started_at:
            elapsed = int(time.time() - self.started_at)
            self.elapsed.value = f"{elapsed // 60:02d}:{elapsed % 60:02d}"
            self.safe_update()
            time.sleep(1)

    def stop(self, _):
        self.stop_event.set()
        self.stage.value = "Interrompendo com segurança"
        self.stage_detail.value = "A etapa atual será finalizada antes de fechar o navegador."
        self.stop_button.disabled = True
        self.add_log("Interrupção solicitada pelo usuário.", "warning")
        self.page.update()

    def finished(self, result):
        root, files, errors = result
        self.output_result = root
        self.running = False
        self.progress.value = 1
        self.stage.value = "Processamento concluído"
        self.stage_detail.value = f"{files} pacotes processados · {len(errors)} pendência(s)."
        self.status_badge.content.value = "CONCLUÍDO"
        self.status_badge.bgcolor = GREEN_LIGHT
        self.status_badge.content.color = GREEN
        self.start_button.disabled = False
        self.stop_button.disabled = True
        self.open_output_button.disabled = False
        self.add_log(f"Resultado salvo em: {root}", "success")
        self.safe_update()

    def cancelled(self):
        self.running = False
        self.stage.value = "Processamento interrompido"
        self.stage_detail.value = "Os arquivos concluídos foram preservados."
        self.status_badge.content.value = "INTERROMPIDO"
        self.status_badge.bgcolor = "#FFF2D8"
        self.status_badge.content.color = "#9B6508"
        self.start_button.disabled = False
        self.stop_button.disabled = True
        self.safe_update()

    def failed(self, error):
        self.running = False
        self.stage.value = "Falha no processamento"
        self.stage_detail.value = error
        self.status_badge.content.value = "FALHA"
        self.status_badge.bgcolor = "#FBE5E5"
        self.status_badge.content.color = ERROR
        self.start_button.disabled = False
        self.stop_button.disabled = True
        self.add_log(error, "error")
        self.safe_update()

    def open_result(self, _):
        if self.output_result and self.output_result.exists():
            os.startfile(self.output_result)

    def safe_update(self):
        try:
            self.page.update()
        except Exception:
            pass


def main(page: ft.Page):
    RelatoriosSGLApp(page)


if __name__ == "__main__":
    ft.app(target=main)
