from __future__ import annotations

import threading
from pathlib import Path

import flet as ft

from contador_uls_v2 import abrir_arquivo, carregar_json, gerar_excel, pasta_dados, salvar_json


BG = "#FAFAF8"
SURFACE = "#FFFFFF"
SURFACE_SOFT = "#F5F4F0"
SURFACE_MUTED = "#F1EFEB"
TEXT = "#171717"
TEXT_SOFT = "#6F6C64"
TEXT_MUTED = "#A29F97"
BORDER = "#ECE8E0"
PRIMARY = "#171717"
SUCCESS = "#10B981"
SUCCESS_SOFT = "#DDF7EC"
WARNING = "#9A7B2F"
WARNING_SOFT = "#F5ECD5"
DANGER = "#B93832"


def _caps(text: str) -> ft.Text:
    return ft.Text(text.upper(), size=11, weight=ft.FontWeight.W_700, color="#A0A8B4", font_family="Montserrat")


def _ghost_button(label: str, icon: str, click) -> ft.OutlinedButton:
    return ft.OutlinedButton(
        label,
        icon=icon,
        on_click=click,
        height=44,
        style=ft.ButtonStyle(
            color=TEXT,
            side=ft.BorderSide(1, BORDER),
            bgcolor=SURFACE,
            shape=ft.RoundedRectangleBorder(radius=14),
        ),
    )


def main(page: ft.Page):
    page.title = "Contador de ULs"
    page.window.width = 1080
    page.window.height = 860
    page.window.min_width = 900
    page.window.min_height = 700
    page.bgcolor = BG
    page.padding = 0
    page.theme_mode = ft.ThemeMode.LIGHT
    page.theme = ft.Theme(font_family="Segoe UI", color_scheme_seed=SUCCESS)

    config_path = pasta_dados() / "config.json"
    config = carregar_json(config_path, {})
    cronogramas: list[Path] = [Path(p) for p in config.get("cronogramas", []) if Path(p).exists()]
    ultimo_resultado = ""

    estilo_campo = dict(
        read_only=True,
        border_color=BORDER,
        focused_border_color=BORDER,
        bgcolor=SURFACE,
        height=44,
        text_size=12,
        color=TEXT,
        expand=True,
        border_radius=14,
        content_padding=ft.padding.symmetric(horizontal=14, vertical=0),
    )
    concat_txt = ft.TextField(value=config.get("concatenado", ""), **estilo_campo)
    cronos_txt = ft.TextField(value=f"{len(cronogramas)} arquivo(s) selecionado(s)" if cronogramas else "", **estilo_campo)
    destino_txt = ft.TextField(value=config.get("destino", ""), **estilo_campo)
    ciclo = ft.Dropdown(
        value=config.get("ciclo", "Todos"),
        options=[ft.dropdown.Option(x) for x in ("Todos", "97", "98", "99")],
        width=150,
        border_color=BORDER,
        focused_border_color=BORDER,
        bgcolor=SURFACE,
        text_style=ft.TextStyle(size=12, color=TEXT),
        border_radius=14,
    )
    progresso = ft.ProgressBar(value=0, color=SUCCESS, bgcolor="#E8E4DD", height=8, bar_height=8)
    status_icon = ft.Icon(ft.Icons.INFO_OUTLINE, size=18, color=TEXT_MUTED)
    status = ft.Text("Aguardando configuração", size=15, weight=ft.FontWeight.W_600, color=TEXT)
    stat_uls = ft.Text("—", size=28, weight=ft.FontWeight.W_600, color="white")
    stat_leituras = ft.Text("—", size=28, weight=ft.FontWeight.W_600, color="white")
    stat_datas = ft.Text("—", size=28, weight=ft.FontWeight.W_600, color="white")

    def snack(texto, cor=PRIMARY):
        page.snack_bar = ft.SnackBar(ft.Text(texto, color="white"), bgcolor=cor)
        page.snack_bar.open = True
        page.update()

    def selecionou_concat(e: ft.FilePickerResultEvent):
        if e.files:
            concat_txt.value = e.files[0].path
            page.update()

    def selecionou_cronos(e: ft.FilePickerResultEvent):
        if e.files:
            selecionados = {Path(f.path).resolve() for f in e.files}
            cronogramas[:] = sorted(selecionados, key=lambda p: str(p).casefold())
            cronos_txt.value = f"{len(cronogramas)} cronograma(s) selecionado(s)"
            page.update()

    def selecionou_pasta_cronos(e: ft.FilePickerResultEvent):
        if not e.path:
            return
        pasta = Path(e.path)
        encontrados = {
            p.resolve()
            for p in pasta.rglob("*.xlsx")
            if not p.name.startswith("~$") and not p.name.upper().startswith("ACOMPANHAMENTO_ULS_")
        }
        if not encontrados:
            snack("Nenhum cronograma .xlsx foi encontrado na pasta selecionada.", WARNING)
            return
        cronogramas[:] = sorted(encontrados, key=lambda p: str(p).casefold())
        cronos_txt.value = f"{len(cronogramas)} cronograma(s) carregado(s) da pasta"
        snack(f"{len(cronogramas)} cronograma(s) carregado(s).", SUCCESS)
        page.update()

    def selecionou_destino(e: ft.FilePickerResultEvent):
        if e.path:
            destino_txt.value = e.path
            page.update()

    picker_concat = ft.FilePicker(on_result=selecionou_concat)
    picker_cronos = ft.FilePicker(on_result=selecionou_cronos)
    picker_pasta_cronos = ft.FilePicker(on_result=selecionou_pasta_cronos)
    picker_destino = ft.FilePicker(on_result=selecionou_destino)
    page.overlay.extend([picker_concat, picker_cronos, picker_pasta_cronos, picker_destino])

    def seletor(titulo, subtitulo, campo, clique, icone):
        return ft.Column(
            [
                ft.Row([ft.Icon(icone, size=16, color=TEXT_SOFT), ft.Text(titulo, size=15, weight=ft.FontWeight.W_600, color=TEXT)], spacing=8),
                ft.Text(subtitulo, size=12, color=TEXT_SOFT),
                ft.Row([campo, _ghost_button("Selecionar", ft.Icons.FOLDER_OPEN, clique)], spacing=10),
            ],
            spacing=7,
        )

    def seletor_cronogramas():
        return ft.Column(
            [
                ft.Row([ft.Icon(ft.Icons.FOLDER_OUTLINED, size=16, color=TEXT_SOFT), ft.Text("Modelos de cronograma", size=15, weight=ft.FontWeight.W_600, color=TEXT)], spacing=8),
                ft.Text("Selecione qualquer quantidade de arquivos ou carregue a pasta completa do contrato.", size=12, color=TEXT_SOFT),
                ft.Row(
                    [
                        cronos_txt,
                        _ghost_button("Arquivos", ft.Icons.INSERT_DRIVE_FILE_OUTLINED, lambda _: picker_cronos.pick_files(allow_multiple=True, allowed_extensions=["xlsx"])),
                        _ghost_button("Pasta", ft.Icons.FOLDER_OPEN, lambda _: picker_pasta_cronos.get_directory_path()),
                    ],
                    spacing=10,
                ),
            ],
            spacing=7,
        )

    abrir_btn = _ghost_button("Abrir resultado", ft.Icons.OPEN_IN_NEW, lambda _: abrir_arquivo(ultimo_resultado) if ultimo_resultado else None)
    abrir_btn.disabled = True
    gerar_btn = ft.ElevatedButton(
        "Gerar acompanhamento",
        icon=ft.Icons.PLAY_ARROW_ROUNDED,
        height=46,
        expand=True,
        style=ft.ButtonStyle(
            bgcolor=PRIMARY,
            color="white",
            shape=ft.RoundedRectangleBorder(radius=14),
        ),
    )

    def atualizar_progresso(texto, valor):
        status.value = texto
        progresso.value = valor / 100
        page.update()

    def processar(_):
        nonlocal ultimo_resultado
        if not concat_txt.value or not cronogramas or not destino_txt.value:
            snack("Selecione o concatenado, os cronogramas e a pasta de saída.", WARNING)
            return
        salvar_json(config_path, {"concatenado": concat_txt.value, "cronogramas": [str(p) for p in cronogramas], "destino": destino_txt.value, "ciclo": ciclo.value})
        gerar_btn.disabled = True
        abrir_btn.disabled = True
        progresso.value = 0
        status_icon.name = ft.Icons.SYNC
        status_icon.color = SUCCESS
        status.value = "Processamento em andamento"
        stat_uls.value = stat_leituras.value = stat_datas.value = "—"
        page.update()

        def trabalho():
            nonlocal ultimo_resultado
            try:
                resultado = gerar_excel(Path(concat_txt.value), cronogramas, Path(destino_txt.value), ciclo.value, atualizar_progresso)
                ultimo_resultado = resultado["arquivo"]
                status.value = "Relatório concluído com sucesso."
                status_icon.name = ft.Icons.CHECK_CIRCLE_OUTLINE
                status_icon.color = SUCCESS
                stat_uls.value = str(resultado["executadas"])
                stat_leituras.value = f"{resultado['leituras']:,}".replace(",", ".")
                stat_datas.value = str(resultado["datas"])
                abrir_btn.disabled = False
                snack("Relatório criado com sucesso.", SUCCESS)
            except Exception as exc:
                status.value = "Falha no processamento."
                status_icon.name = ft.Icons.ERROR_OUTLINE
                status_icon.color = DANGER
                stat_uls.value = stat_leituras.value = stat_datas.value = "—"
                snack(f"Erro: {exc}", DANGER)
            finally:
                gerar_btn.disabled = False
                page.update()

        threading.Thread(target=trabalho, daemon=True).start()

    gerar_btn.on_click = processar

    header = ft.Container(
        bgcolor=BG,
        padding=ft.padding.only(left=30, top=28, right=30, bottom=14),
        content=ft.Row(
            [
                ft.Column(
                    [
                        _caps("CONTADOR DE ULS"),
                        ft.Text("Acompanhamento operacional local", size=38, weight=ft.FontWeight.W_600, color=TEXT, font_family="Montserrat"),
                        ft.Text("Consolide cronogramas, valide leituras e gere a base final no padrão visual do Hub.", size=14, color=TEXT_SOFT),
                    ],
                    spacing=10,
                    expand=True,
                ),
                ft.Container(
                    padding=ft.padding.symmetric(horizontal=14, vertical=10),
                    border_radius=18,
                    bgcolor=SURFACE,
                    border=ft.Border.all(1, BORDER),
                    content=ft.Column(
                        [
                            _caps("Ambiente"),
                            ft.Text("Execução local", size=15, weight=ft.FontWeight.W_600, color=TEXT),
                        ],
                        spacing=4,
                    ),
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.START,
        ),
    )

    config_card = ft.Container(
        bgcolor=SURFACE,
        border_radius=24,
        border=ft.Border.all(1, BORDER),
        padding=24,
        content=ft.Column(
            [
                _caps("CONFIGURAÇÃO DO PROCESSAMENTO"),
                ft.Container(height=2),
                ft.Container(seletor("Concatenado atualizado", "Base diária utilizada para a contagem das leituras.", concat_txt, lambda _: picker_concat.pick_files(allowed_extensions=["xlsx"]), ft.Icons.STORAGE), padding=ft.padding.symmetric(vertical=14)),
                ft.Divider(height=1, color=BORDER),
                ft.Container(seletor_cronogramas(), padding=ft.padding.symmetric(vertical=14)),
                ft.Divider(height=1, color=BORDER),
                ft.Container(seletor("Pasta dos relatórios", "Local onde o acompanhamento será salvo.", destino_txt, lambda _: picker_destino.get_directory_path(), ft.Icons.DOWNLOAD_OUTLINED), padding=ft.padding.symmetric(vertical=14)),
                ft.Divider(height=1, color=BORDER),
                ft.Container(
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Ciclo a considerar", size=15, weight=ft.FontWeight.W_600, color=TEXT),
                                    ft.Text("Todos identifica automaticamente o ciclo de cada bloco.", size=12, color=TEXT_SOFT),
                                ],
                                spacing=4,
                                expand=True,
                            ),
                            ciclo,
                        ]
                    ),
                    padding=ft.padding.symmetric(vertical=14),
                ),
                ft.Row([gerar_btn, abrir_btn], spacing=12),
            ],
            spacing=0,
        ),
    )

    metric_surface = lambda titulo, valor: ft.Container(
        bgcolor="rgba(255,255,255,0.08)",
        border_radius=18,
        padding=16,
        expand=True,
        content=ft.Column([_caps(titulo), valor], spacing=8),
    )

    status_card = ft.Container(
        bgcolor=PRIMARY,
        border_radius=34,
        padding=26,
        shadow=ft.BoxShadow(blur_radius=28, color="#1A1A1A22", offset=ft.Offset(0, 14)),
        content=ft.Column(
            [
                ft.Row([ft.Text("EXECUTION SCORE", size=11, weight=ft.FontWeight.W_700, color="#8B8B86", font_family="Montserrat"), ft.Container(expand=True), ft.Icon(ft.Icons.SHIELD_OUTLINED, size=18, color=SUCCESS)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([status_icon, status], spacing=10),
                progresso,
                ft.Row(
                    [
                        metric_surface("ULS COM EXECUÇÃO", stat_uls),
                        metric_surface("LEITURAS", stat_leituras),
                        metric_surface("DATAS", stat_datas),
                    ],
                    spacing=12,
                ),
            ],
            spacing=18,
        ),
    )

    footer = ft.Row(
        [
            ft.Row([ft.Icon(ft.Icons.INFO_OUTLINE, size=15, color=TEXT_SOFT), ft.Text("Os cronogramas originais não são alterados.", size=12, color=TEXT_SOFT)], spacing=6),
            ft.Text("© Delkzo One Technology", size=12, color=TEXT_MUTED),
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
    )

    content = ft.Container(
        padding=ft.padding.only(left=30, right=30, bottom=30),
        content=ft.ResponsiveRow(
            [
                ft.Container(col={"sm": 12, "lg": 7}, content=config_card),
                ft.Container(col={"sm": 12, "lg": 5}, content=status_card),
                ft.Container(col={"sm": 12}, content=footer, padding=ft.padding.only(top=10)),
            ],
            spacing=20,
            run_spacing=20,
        ),
    )

    page.add(ft.Column([header, content], spacing=0, expand=True, scroll=ft.ScrollMode.AUTO))


if __name__ == "__main__":
    ft.app(target=main)
