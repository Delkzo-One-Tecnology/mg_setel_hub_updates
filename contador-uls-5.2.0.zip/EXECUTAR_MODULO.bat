@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PYTHON_CMD=py -3") else (set "PYTHON_CMD=python")
if not exist ".venv\Scripts\python.exe" %PYTHON_CMD% -m venv .venv || goto :erro
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements-build.txt || goto :erro
".venv\Scripts\python.exe" contador_uls_flet.py
exit /b %errorlevel%
:erro
echo Falha ao preparar o Contador de ULs.
pause
exit /b 1

