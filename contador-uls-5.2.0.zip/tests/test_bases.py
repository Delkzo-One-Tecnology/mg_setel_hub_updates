from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from contador_uls import identificar_base


def test_bases_mantiqueira_por_nome_da_aba():
    assert identificar_base("Adnilson - Barbacena") == "Barbacena"
    assert identificar_base("Reginaldo - Lafaiete") == "Lafaiete"
    assert identificar_base("Jo\u00e3o Paulo - JFBF") == "JFBF"
    assert identificar_base("JF - Centro") == "JF Centro"
    assert identificar_base("Freelancer -JFMH") == "JFMH"
    assert identificar_base("Equipe - Ouro Preto") == "Ouro Preto"
    assert identificar_base("Ponte Nova") == "Ponte Nova"
    assert identificar_base("Vi\u00e7osa") == "Vi\u00e7osa"


def test_base_generica_preserva_o_ultimo_segmento():
    assert identificar_base("Jo\u00e3o da Silva - Divin\u00f3polis") == "Divin\u00f3polis"
