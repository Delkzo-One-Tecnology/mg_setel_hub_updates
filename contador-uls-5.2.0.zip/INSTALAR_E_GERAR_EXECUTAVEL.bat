@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Instalador e Gerador - Contador de ULs V5
cd /d "%~dp0"

echo ============================================================
echo   CONTADOR DE ULS V5 - GERACAO DO EXECUTAVEL
echo ============================================================
echo.

set "PYEXE="

for /f "delims=" %%P in ('py -3.12 -c "import sys; print(sys.executable)" 2^>nul') do set "PYEXE=%%P"

if not defined PYEXE (
    if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"
)

if not defined PYEXE goto instalar_python
goto preparar

:instalar_python
echo O runtime Python 3.12 nao foi encontrado.
echo O instalador tentara instala-lo automaticamente.
echo.

where py >nul 2>&1
if not errorlevel 1 (
    echo Tentando instalar pelo Python Install Manager...
    py install 3.12
    for /f "delims=" %%P in ('py -3.12 -c "import sys; print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
    if defined PYEXE goto preparar
)

where winget >nul 2>&1
if errorlevel 1 goto sem_winget

echo Tentando instalar pelo Windows Package Manager...
winget install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto erro_python

for /f "delims=" %%P in ('py -3.12 -c "import sys; print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
if not defined PYEXE if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"

if not defined PYEXE goto erro_python

:preparar
echo Python localizado: %PYEXE%
echo.
echo Preparando o gerador do executavel...

"%PYEXE%" -m ensurepip --upgrade
if errorlevel 1 goto erro_dependencias

"%PYEXE%" -m pip install --upgrade pip
if errorlevel 1 goto erro_dependencias

"%PYEXE%" -m pip install -r requirements-build.txt
if errorlevel 1 goto erro_dependencias

echo.
echo Gerando o executavel completo. Aguarde...
set "BUILD_TEMP=%TEMP%\ContadorULs_%RANDOM%_%RANDOM%"
set "DIST_NOVO=%~dp0dist_novo"
mkdir "%BUILD_TEMP%" >nul 2>&1
mkdir "%DIST_NOVO%" >nul 2>&1

"%PYEXE%" -m PyInstaller --noconfirm --onefile --windowed --name "Contador_de_ULs_V5" --workpath "%BUILD_TEMP%\build" --specpath "%BUILD_TEMP%\spec" --distpath "%DIST_NOVO%" --collect-all flet --collect-all flet_desktop --hidden-import openpyxl contador_uls_flet.py
if errorlevel 1 goto erro_compilacao

if not exist "%DIST_NOVO%\Contador_de_ULs_V5.exe" goto erro_compilacao

echo.
echo ============================================================
echo   EXECUTAVEL CRIADO COM SUCESSO
echo ============================================================
echo.
echo O arquivo esta em:
echo %DIST_NOVO%\Contador_de_ULs_V5.exe
echo.
echo Esse arquivo pode ser copiado para outras maquinas.
echo Nessas maquinas nao sera necessario instalar Python ou bibliotecas.
echo.
start "" "%DIST_NOVO%"
pause
exit /b 0

:sem_winget
echo.
echo O Windows Package Manager ^(winget^) nao esta disponivel.
echo Instale o Python 3.12 pelo site oficial, marque Add Python to PATH
echo e execute este instalador novamente.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:erro_python
echo.
echo Nao foi possivel instalar ou localizar o Python automaticamente.
echo Verifique sua conexao, permissao da empresa ou bloqueio do winget.
pause
exit /b 1

:erro_dependencias
echo.
echo Nao foi possivel instalar as dependencias do gerador.
echo Verifique a conexao com a internet ou bloqueios da rede corporativa.
pause
exit /b 1

:erro_compilacao
echo.
echo O PyInstaller nao conseguiu gerar o executavel.
echo Verifique as mensagens apresentadas acima.
pause
exit /b 1
