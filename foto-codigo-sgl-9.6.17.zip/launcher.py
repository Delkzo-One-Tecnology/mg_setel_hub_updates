from foto_codigo.tls import configurar_certificados

configurar_certificados()

from foto_codigo.app import executar


if __name__ == "__main__":
    executar()
