@echo off
call "%~dp0gerar_executavel_completo.bat"
exit /b %errorlevel%
