@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "FLET_VERSION=0.86.5"
set "FLET_URL=https://github.com/flet-dev/flet/releases/download/v%FLET_VERSION%/flet-windows.zip"

echo ============================================================
echo  GERADOR DO EXECUTAVEL COMPLETO - VALIDADOR SGL
echo ============================================================
echo.
echo Este processo usa internet somente nesta maquina de montagem.
echo O executavel final levara Python, bibliotecas e o cliente Flet.
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [1/5] Criando ambiente de montagem...
    py -3 -m venv .venv
    if errorlevel 1 goto :erro_python
) else (
    echo [1/5] Ambiente de montagem localizado.
)

echo [2/5] Instalando dependencias fixadas...
".venv\Scripts\python.exe" -m ensurepip --upgrade >nul 2>&1
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt "pyinstaller>=6.10,<7"
if errorlevel 1 goto :erro_dependencias

set "FLET_PATH_FILE=%TEMP%\validador_sgl_flet_app_%RANDOM%.txt"
".venv\Scripts\python.exe" -c "import pathlib, flet_desktop; print(pathlib.Path(flet_desktop.__file__).resolve().parent / 'app')" > "%FLET_PATH_FILE%"
if errorlevel 1 goto :erro_flet
set /p "FLET_APP_DIR=" < "%FLET_PATH_FILE%"
del /q "%FLET_PATH_FILE%" >nul 2>&1
if not defined FLET_APP_DIR goto :erro_flet
if not exist "%FLET_APP_DIR%" mkdir "%FLET_APP_DIR%"
set "FLET_ARCHIVE=%FLET_APP_DIR%\flet-windows.zip"

if exist "%FLET_ARCHIVE%" (
    echo [3/5] Cliente visual do Flet ja esta disponivel.
) else (
    echo [3/5] Baixando o cliente visual oficial do Flet...
    powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%FLET_URL%' -OutFile '%FLET_ARCHIVE%.tmp'"
    if errorlevel 1 (
        if exist "%FLET_ARCHIVE%.tmp" del /q "%FLET_ARCHIVE%.tmp" >nul 2>&1
        echo O PowerShell nao conseguiu baixar. Tentando o curl do Windows...
        curl.exe -L --fail --retry 3 --output "%FLET_ARCHIVE%.tmp" "%FLET_URL%"
        if errorlevel 1 goto :erro_download
    )
    move /y "%FLET_ARCHIVE%.tmp" "%FLET_ARCHIVE%" >nul
)

echo [4/5] Validando o pacote visual...
".venv\Scripts\python.exe" -c "import pathlib, zipfile, flet_desktop; p=pathlib.Path(flet_desktop.__file__).parent/'app'/'flet-windows.zip'; assert p.stat().st_size > 1000000; assert zipfile.is_zipfile(p); print('Pacote Flet validado:', p.name)"
if errorlevel 1 goto :erro_flet

echo [5/5] Gerando executavel autonomo...
".venv\Scripts\pyinstaller.exe" --noconfirm --clean ValidadorFotosCodigosSGL.spec
if errorlevel 1 goto :erro_build

if not exist "dist\ValidadorFotosCodigosSGL.exe" goto :erro_build

echo.
echo ============================================================
echo  EXECUTAVEL COMPLETO GERADO COM SUCESSO
echo ============================================================
echo Arquivo: %CD%\dist\ValidadorFotosCodigosSGL.exe
echo.
echo Este arquivo pode ser copiado sozinho para outro Windows.
echo Nao e necessario instalar Python, Flet ou pacotes via pip no destino.
pause
exit /b 0

:erro_python
echo.
echo Python nao foi localizado. Instale Python 3.11, 3.12 ou 3.13 somente
echo na maquina que gera o executavel e marque a opcao de adicionar ao PATH.
goto :falha

:erro_dependencias
echo.
echo Nao foi possivel instalar as dependencias de montagem.
goto :falha

:erro_download
echo.
echo Nao foi possivel obter o cliente Flet oficial.
echo A rede pode estar bloqueando o GitHub. Execute a montagem em uma maquina
echo com acesso liberado; o computador que usara o programa nao precisara dele.
goto :falha

:erro_flet
echo.
echo O pacote do cliente Flet esta ausente ou corrompido.
goto :falha

:erro_build
echo.
echo O PyInstaller nao conseguiu gerar o executavel.

:falha
echo.
echo A geracao foi interrompida. Nenhum executavel incompleto deve ser distribuido.
pause
exit /b 1
