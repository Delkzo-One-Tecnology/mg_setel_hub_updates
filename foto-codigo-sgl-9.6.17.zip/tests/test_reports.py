import tempfile
import unittest
from unittest.mock import patch

from foto_codigo.models import RegistroBase, ResultadoAnalise, StatusAnalise
from foto_codigo.reports import GerenciadorRelatorios


class RespaldoRelatorioTest(unittest.TestCase):
    def test_bloqueio_do_excel_gera_respaldo_sem_interromper(self):
        with tempfile.TemporaryDirectory() as pasta:
            gerenciador = GerenciadorRelatorios(pasta, "08/2026")
            self.assertEqual(gerenciador.pasta.name, "ANALISE_FOTOS_08-2026")
            registro = RegistroBase("01000001", 1, "100", "3311", "A", "08/2026", "", "", "NORTE")
            resultado = ResultadoAnalise("Oeste", registro, StatusAnalise.APROVADA)
            with patch.object(gerenciador, "registrar", side_effect=PermissionError("arquivo aberto")):
                self.assertFalse(gerenciador.registrar_com_respaldo(resultado))
            conteudo = gerenciador.caminho_respaldo.read_text(encoding="utf-8")
            self.assertIn('"instalacao": "100"', conteudo)
            self.assertIn('"status": "Aprovada"', conteudo)

    def test_relatorio_final_possui_somente_colunas_operacionais(self):
        from openpyxl import load_workbook

        with tempfile.TemporaryDirectory() as pasta:
            gerenciador = GerenciadorRelatorios(pasta, "08/2026")
            wb = load_workbook(gerenciador.caminho_final, read_only=True)
            try:
                cabecalho = [celula.value for celula in wb.active[1]]
            finally:
                wb.close()
            self.assertEqual(cabecalho, [
                "Polo", "Referência", "Nome do leiturista", "Matrícula", "ID IWOS", "Centro IWOS",
                "Função", "Disponibilidade", "Razão", "UL", "Instalação", "Código", "Endereço",
                "Leitura anterior", "Leitura executada", "Resultado"
            ])
            self.assertNotIn("Contrato", cabecalho)
            self.assertNotIn("Quantidade de fotos verificadas", cabecalho)
            self.assertNotIn("Data e hora da verificação", cabecalho)

    def test_historico_consolida_leiturista_e_contrato(self):
        from openpyxl import load_workbook

        with tempfile.TemporaryDirectory() as pasta:
            gerenciador = GerenciadorRelatorios(pasta, "08/2026")
            registro = RegistroBase(
                "01000001", 1, "100", "3311", "A", "08/2026", "01/08/2026",
                "10:00:00", "NORTE", "12345", "Maria Silva", "998", "Centro A",
                "Leiturista", "01/01/2025", "Trabalhando", "100", "101",
            )
            gerenciador.registrar(ResultadoAnalise("Oeste", registro, StatusAnalise.APROVADA, 2, 2))
            gerenciador.registrar(ResultadoAnalise("Oeste", registro, StatusAnalise.REPROVADA, 2, 1))
            gerenciador.finalizar()
            wb = load_workbook(gerenciador.caminho_historico, read_only=True, data_only=True)
            try:
                self.assertEqual(wb.sheetnames, [
                    "Histórico detalhado", "Mensal por leiturista", "Mensal por contrato"
                ])
                linha_l = list(wb["Mensal por leiturista"].iter_rows(min_row=2, values_only=True))[0]
                self.assertEqual(linha_l[:11], ("Oeste", "08/2026", "Maria Silva", "12345", "998", "Centro A", "Leiturista", "01/01/2025", "Trabalhando", 1, "3311"))
                self.assertEqual(linha_l[11:18], (1, 1, 0, 0, 0, 0, 2))
                self.assertEqual(linha_l[18:20], (0.5, "NÃO"))
                linha_c = list(wb["Mensal por contrato"].iter_rows(min_row=2, values_only=True))[0]
                self.assertEqual(linha_c[:4], ("Oeste", "08/2026", 1, 1))
                self.assertEqual(linha_c[4:11], (1, 1, 0, 0, 0, 0, 2))
            finally:
                wb.close()


if __name__ == "__main__":
    unittest.main()
