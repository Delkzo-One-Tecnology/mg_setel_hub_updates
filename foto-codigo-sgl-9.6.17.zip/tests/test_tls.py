import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from foto_codigo.tls import configurar_certificados


class CertificadosTest(unittest.TestCase):
    def test_cria_bundle_e_configura_variaveis_ssl(self):
        with TemporaryDirectory() as pasta, patch.dict(os.environ, {"APPDATA": pasta}):
            caminho = configurar_certificados()
            self.assertTrue(caminho.exists())
            self.assertGreater(caminho.stat().st_size, 1000)
            self.assertEqual(os.environ["SSL_CERT_FILE"], str(caminho))
            self.assertEqual(os.environ["REQUESTS_CA_BUNDLE"], str(caminho))
            self.assertEqual(caminho.parent, Path(pasta) / "ValidadorSGL")


if __name__ == "__main__":
    unittest.main()
