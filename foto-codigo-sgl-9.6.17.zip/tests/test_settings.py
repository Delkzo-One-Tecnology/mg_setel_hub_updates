import os
import tempfile
import unittest
from unittest.mock import patch

from foto_codigo.settings import Perfil, carregar_perfil, salvar_perfil


class PerfilTest(unittest.TestCase):
    def test_salvar_e_reabrir_sem_senha(self):
        with tempfile.TemporaryDirectory() as pasta, patch.dict(os.environ, {"APPDATA": pasta}):
            perfil = Perfil("Oeste", "C:/bases/polos.xlsx", "USUARIO", "C:/relatorios", 60, "C:/bases/auxiliar.xlsx")
            salvar_perfil(perfil)
            carregado = carregar_perfil()
            self.assertEqual(carregado, perfil)
            self.assertFalse(hasattr(carregado, "senha"))
            self.assertEqual(carregado.base_iwos, "C:/bases/auxiliar.xlsx")


if __name__ == "__main__":
    unittest.main()
