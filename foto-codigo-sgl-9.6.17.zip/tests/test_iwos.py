import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook

from foto_codigo.iwos import carregar_base_iwos


class BaseIWOSTest(unittest.TestCase):
    def test_relaciona_matricula_operacional_ao_iwos(self):
        with tempfile.TemporaryDirectory() as pasta:
            caminho = Path(pasta) / "auxiliar.xlsx"
            wb = Workbook()
            ws = wb.active
            ws.title = "IWOS"
            ws.append(["ID", "Nome", "Centro", "Função", "Admissão", "Disponibilidade"])
            ws.append([5516, "Samuel de Souza", "Bom Despacho", "Leiturista", "19/08/2024", "Trabalhando"])
            mat = wb.create_sheet("MATRÍCULAS")
            mat.append(["ID", "MATRÍCULA", "NOME DO LEITURISTA", "POLO", "EXPERIÊNCIA / FUNÇÃO", "ESTATUS", "ADMISSÃO"])
            mat.append([5516, 602, "Samuel de Souza", "Bom Despacho", "Leiturista", "TRABALHANDO", "19/08/2024"])
            wb.save(caminho)
            pessoas, linhas = carregar_base_iwos(caminho)
        self.assertEqual(pessoas["602"].nome, "Samuel de Souza")
        self.assertEqual(pessoas["602"].id_iwos, "5516")
        self.assertEqual(pessoas["602"].disponibilidade, "Trabalhando")
        self.assertEqual(linhas[0][0], "ID")


if __name__ == "__main__":
    unittest.main()
