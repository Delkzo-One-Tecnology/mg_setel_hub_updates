import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from openpyxl import Workbook

from foto_codigo.data import (
    carregar_concatenado_auto, carregar_mapa_contrato, detectar_contrato_concatenado, extrair_endereco, filtrar_registros,
    normalizar_ul, opcoes_dependentes, referencia_de_data,
)
from foto_codigo.models import RegistroBase
from foto_codigo.catalog import filtrar_codigos_cemig


class RegrasDeDadosTest(unittest.TestCase):
    def test_normalizar_ul_com_sete_digitos(self):
        self.assertEqual(normalizar_ul(1315598), "01315598")

    def test_normalizar_ul_com_oito_digitos(self):
        self.assertEqual(normalizar_ul(14322891), "14322891")

    def test_referencia(self):
        self.assertEqual(referencia_de_data("07/08/2026"), "08/2026")

    def test_endereco(self):
        valor = "3000073365AJJ115015909FAZENDA ANDRADE, 999999 -  - FZ"
        self.assertEqual(
            extrair_endereco(valor, "3000073365"),
            "FAZENDA ANDRADE, 999999 -  - FZ",
        )

    def test_filtro_aceita_multiplas_razoes_e_codigos(self):
        registros = [
            RegistroBase("01000001", 1, "100", "3311", "A", "08/2026", "", "", "NORTE"),
            RegistroBase("02000001", 2, "200", "3312", "B", "08/2026", "", "", "SUL"),
            RegistroBase("03000001", 3, "300", "9999", "C", "08/2026", "", "", "LESTE"),
        ]
        resultado = filtrar_registros(registros, "08/2026", [1, 2], ["3311", "3312"])
        self.assertEqual({item.instalacao for item in resultado}, {"100", "200"})

    def test_razoes_sao_somente_as_presentes_no_concatenado(self):
        registros = [
            RegistroBase("01000001", 1, "100", "3311", "A", "08/2026", "", "", "NORTE"),
            RegistroBase("04000001", 4, "200", "3311", "B", "08/2026", "", "", "SUL"),
            RegistroBase("09000001", 9, "300", "3311", "C", "07/2026", "", "", "LESTE"),
        ]
        opcoes = opcoes_dependentes(registros, "08/2026")
        self.assertEqual(opcoes["razoes"], ["1", "4"])

    def test_catalogo_exibe_somente_codigos_cemig(self):
        self.assertEqual(filtrar_codigos_cemig(["1101", "3311", "3376", "9999"]), ["3311", "3376"])

    def test_bases_internas_dos_tres_contratos(self):
        esperados = {
            "Oeste": (8101, 5),
            "Mantiqueira": (10261, 9),
            "Triângulo": (2647, 3),
        }
        mapas = {}
        for contrato, (quantidade_uls, quantidade_polos) in esperados.items():
            mapa, polos = carregar_mapa_contrato(contrato)
            self.assertEqual(len(mapa), quantidade_uls)
            self.assertEqual(len(polos), quantidade_polos)
            mapas[contrato] = mapa
        self.assertFalse(set(mapas["Oeste"]) & set(mapas["Mantiqueira"]))
        self.assertFalse(set(mapas["Oeste"]) & set(mapas["Triângulo"]))
        self.assertFalse(set(mapas["Mantiqueira"]) & set(mapas["Triângulo"]))

    def test_detecta_contrato_pelas_uls_do_concatenado(self):
        mapa, _ = carregar_mapa_contrato("Mantiqueira")
        with TemporaryDirectory() as pasta:
            caminho = Path(pasta) / "concatenado.xlsx"
            wb = Workbook()
            ws = wb.active
            ws.append(["Unidade de Leitura"])
            for ul in list(mapa)[:12]:
                ws.append([ul])
            wb.save(caminho)
            contrato, pontuacao = detectar_contrato_concatenado(caminho)
        self.assertEqual(contrato, "Mantiqueira")
        self.assertEqual(pontuacao["Mantiqueira"], 12)
        self.assertEqual(pontuacao["Oeste"], 0)

    def test_carregamento_unico_detecta_contrato_e_polo(self):
        mapa, _ = carregar_mapa_contrato("Triângulo")
        ul, polo = next(iter(mapa.items()))
        with TemporaryDirectory() as pasta:
            caminho = Path(pasta) / "concatenado_completo.xlsx"
            wb = Workbook()
            ws = wb.active
            ws.append(["Unidade de Leitura", "Matriculas", "Leiturista", "Data", "Hora", "Código", "instalação concatenada", "Instalação"])
            ws.append([ul, "00123", "Maria Silva", "01/08/2026", "10:00:00", "3311", "1000000000ABCDEFGHIJKLENDEREÇO", "1000000000"])
            wb.save(caminho)
            registros, _, contrato, _, _, _ = carregar_concatenado_auto(caminho)
        self.assertEqual(contrato, "Triângulo")
        self.assertEqual(registros[0].polo, polo)
        self.assertEqual(registros[0].matricula_leiturista, "00123")
        self.assertEqual(registros[0].nome_leiturista, "Maria Silva")


if __name__ == "__main__":
    unittest.main()
