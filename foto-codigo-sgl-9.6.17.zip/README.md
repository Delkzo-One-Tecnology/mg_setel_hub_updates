# Validador de Fotos e Códigos — SGL · V9.6.17

Versão 9.6.17 com interface **Flet** reconstruída conforme o novo modelo visual corporativo e linguagem operacional padronizada. A aplicação identifica automaticamente contrato, polo e colaborador, consulta fotos no SGL e mantém históricos mensais por leiturista e por contrato.

## Distribuição recomendada — executável completo

O arquivo `executar.bat` da versão em código ainda cria um ambiente Python e
instala dependências na primeira utilização. Para distribuir o programa sem
essa instalação e sem o download inicial do cliente Flet:

1. Em um Windows com acesso à internet, execute `gerar_executavel_completo.bat`.
2. Aguarde as cinco etapas de montagem.
3. Distribua somente `dist\ValidadorFotosCodigosSGL.exe`.

O executável gerado incorpora o interpretador Python, Flet, cliente desktop do
Flet, Selenium, OpenPyXL, certificados e demais pacotes do projeto. Na máquina
de destino continuam necessários apenas Windows 10/11, Google Chrome e acesso
ao SGL. A geração fixa o Flet em `0.86.5` para impedir incompatibilidade entre
o pacote Python e o motor visual incorporado.

## Requisitos

- Windows 10 ou 11;
- Python 3.11 ou superior;
- Google Chrome atualizado;
- Acesso ao SGL e certificado disponível no computador;
- Internet/rede corporativa necessária para acessar o sistema.

## Como executar

1. Extraia a pasta completa.
2. Dê dois cliques em `executar.bat`.
3. Na primeira execução, aguarde a instalação automática das dependências.
4. Abra **Perfil** e informe o usuário e a pasta dos relatórios; o contrato será confirmado pelo concatenado.
5. Selecione também a planilha auxiliar que contém as abas `IWOS` e `MATRÍCULAS`.
6. Selecione o concatenado atualizado.
7. Confira mês/ano e marque uma ou mais razões e códigos.
8. Digite apenas a senha do SGL.
9. Confirme o certificado quando o Chrome solicitar.

O usuário é salvo no perfil local. A senha do SGL também pode ser reutilizada nas próximas execuções: ela é criptografada pelo Windows DPAPI e vinculada ao usuário atual do Windows. A senha não é gravada em texto aberto e não pode ser recuperada ao copiar o arquivo de credencial para outra conta ou computador.

O contrato também pode ser selecionado diretamente no cabeçalho. Ao carregar o
concatenado, o programa compara suas ULs com as bases internas e confirma ou
corrige automaticamente o contrato. Arquivos com mistura ambígua de contratos
são bloqueados para evitar classificação incorreta dos polos.

A planilha auxiliar é relida automaticamente toda vez que um concatenado é carregado. A matrícula operacional do concatenado é cruzada com a aba `MATRÍCULAS`; o nome encontrado é então complementado pela aba `IWOS` com ID, centro, função, admissão e disponibilidade. Atualizar o arquivo no mesmo caminho atualiza o cadastro na próxima importação.

Salvar usuário, pasta de resultados ou tempo de validação não recarrega o
concatenado. Quando uma base está aberta, seu contrato permanece bloqueado até
que outro arquivo seja selecionado.

O inicializador verifica e repara automaticamente ambientes sem `Flet`,
`openpyxl` ou `selenium`. Se a instalação falhar, confira a internet, exclua
somente a pasta `.venv` e execute `executar.bat` novamente.

Antes de iniciar o Flet, o programa combina os certificados públicos do
`certifi` com as autoridades confiáveis instaladas no Windows. Isso permite a
primeira preparação do cliente visual também em redes corporativas com inspeção
HTTPS. A validação SSL não é desativada.

## Regras da análise

- A meta fixa é de 20 **instalações aprovadas por polo**.
- Instalações sem foto, reprovadas ou com tempo esgotado não contam na meta.
- Se houver várias fotos, todas precisam ser aprovadas.
- Uma foto incompatível reprova imediatamente a instalação e descarta as restantes.
- O prazo é de 60 segundos por instalação.
- Zoom e rotação são feitos nos controles do próprio visualizador do SGL.
- Depois de aprovar, reprovar ou adiar, o programa clica automaticamente na
  foto para fechar o visualizador antes de continuar.
- As instalações são embaralhadas dentro de cada polo.
- O programa alterna entre polos pendentes e não segue a sequência da planilha.
- Um polo só termina com 20 aprovações ou depois que todas as suas instalações
  elegíveis forem consultadas.

## Interface

- Toda a operação fica em uma única tela.
- Concatenado, mês, razões, códigos e senha ficam no cartão de configuração.
- O cartão de análise reúne os dados, as decisões, o cronômetro circular e o encerramento.
- A cobertura por polo ocupa a coluna direita e se adapta para baixo em telas menores.
- A interface usa componentes Flet responsivos e estilo corporativo centralizado.
- A identidade visual utiliza azul-marinho e cartões claros com hierarquia corporativa.
- Nos últimos 10 segundos, o cronômetro muda para vermelho.
- Operações demoradas exibem um loading bloqueante com mensagem contextual.
- A leitura do concatenado ocorre em segundo plano, mantendo a janela responsiva.
- Detecção do contrato, classificação dos polos e importação são executadas em uma única passagem pelo Excel.
- Tarefas longas usam threads dedicadas e o loading informa a quantidade de linhas já processadas.
- Durante a abertura, o loading mostra o tempo decorrido; na leitura, mostra percentual e tempo restante estimado.
- Razões e códigos possuem seleção múltipla por caixas de marcação.
- O seletor de razões mostra somente razões realmente encontradas no concatenado para o mês/ano selecionado; o intervalo 1–18 não é preenchido artificialmente.
- O seletor de códigos exibe somente códigos atribuídos à concessionária CEMIG no catálogo de INFM.
- Quando vários códigos são escolhidos, suas instalações são misturadas aleatoriamente dentro de cada polo.
- Falhas inesperadas são registradas em `%APPDATA%\ValidadorSGL\erros_v9_6.log`.
- Se o navegador, a aba ou a rota forem alterados, a sessão é restaurada e a consulta é repetida uma vez.
- Se um relatório estiver aberto no Excel, o resultado é preservado em `RESPALDO_PENDENTE_MM-AAAA.jsonl`.

## Perfil persistente

O botão **Perfil** armazena localmente contrato, usuário do SGL, pasta dos relatórios e tempo de avaliação. A senha é protegida pelo Windows DPAPI. As bases de Oeste, Mantiqueira e Triângulo já acompanham o programa.

## Saídas

- `ANALISE_FOTOS_MM-AAAA/RELATORIO_APROVADAS_MM-AAAA.xlsx`: contém as aprovações, incluindo nome e matrícula do leiturista quando disponíveis.
- `ANALISE_FOTOS_MM-AAAA/REGISTRO_TECNICO_MM-AAAA.xlsx`: registro completo do mês, incluindo leiturista, contrato, fotos verificadas e data/hora.
- `HISTORICO_ANALISE_FOTOS.xlsx`: histórico acumulado com abas detalhada, mensal por leiturista e mensal por contrato.
- A aba `IWOS` do histórico recebe uma cópia atualizada da base usada na importação.
- `historico_analise_fotos.jsonl`: log de recuperação usado para reconstruir o histórico sem tornar a verificação mais lenta.
- `ANALISE_FOTOS_MM-AAAA/estado_MM-AAAA.json`: checkpoint simples para recuperação.

Os arquivos são atualizados após cada consulta. Uma nova execução na mesma pasta ignora instalações já registradas no histórico técnico.
O histórico consolidado é atualizado ao finalizar a análise. Relatórios mensais de versões anteriores encontrados na mesma pasta de resultados são importados automaticamente.
O registro técnico também inclui leitura anterior, leitura executada, classificação de qualidade e ação sugerida, seguindo o manual de treinamento sem preencher evidências que o sistema não coletou.

## Observações desta versão

- A migração removeu completamente as dependências de CustomTkinter e PySide6.
- A lógica de Selenium, dados, sessão e relatórios foi preservada.
- O fechamento da foto possui recuperação em múltiplas etapas e restaura a consulta caso o modal do SGL não responda.
- Os seletores do SGL foram baseados no script anterior e nas telas fornecidas.
- A confirmação do certificado permanece manual.
- O SGL não pôde ser acessado no ambiente de desenvolvimento; o primeiro teste real pode exigir ajuste pontual no seletor dos links ou do modal de fotos.
- Não coloque usuário ou senha dentro dos arquivos do projeto.
