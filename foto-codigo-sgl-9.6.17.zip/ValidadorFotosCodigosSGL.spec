# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [
    ('src/foto_codigo/resources/*.json', 'foto_codigo/resources'),
]
binaries = []
hiddenimports = []
flet_data, flet_bins, flet_hidden = collect_all('flet')
datas += flet_data
binaries += flet_bins
hiddenimports += flet_hidden

# O cliente desktop do Flet e o arquivo flet-windows.zip sao preparados por
# gerar_executavel_completo.bat antes do PyInstaller. Inclui-los aqui impede
# qualquer download do motor visual na primeira execucao do programa final.
desktop_data, desktop_bins, desktop_hidden = collect_all('flet_desktop')
datas += desktop_data
binaries += desktop_bins
hiddenimports += desktop_hidden


a = Analysis(
    ['launcher.py'],
    pathex=['src'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='ValidadorFotosCodigosSGL',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
