# Versão 9.0.0

- Interface migrada integralmente de CustomTkinter para PySide6.
- Identidade visual separada da lógica no arquivo `styles.qss`.
- Layout corporativo responsivo com filtros, registro, ações, timer e polos em uma única página.
- Loading modal bloqueante durante leitura do concatenado, acesso ao SGL e finalização dos relatórios.
- Cinco ou mais polos distribuídos automaticamente em duas colunas.
- Botões de aprovação e reprovação com cores menos saturadas e estados desabilitados claros.
- Perfil persistente para contrato, base de polos, usuário, relatórios e tempo de validação.
- Timer atualizado imediatamente quando o perfil é salvo.
- Removidos textos redundantes sobre abertura da foto e verificação posterior.
- Rodapé identificado como Delkzo One Technology.
- Inicializador e empacotamento atualizados para instalar e incluir PySide6 e QSS.
- Núcleo Selenium, dados, sessão e relatórios preservado.

# Versão 9.1.0

- Seleção múltipla de razões e códigos com caixas de marcação.
- Filtros, retomada de sessão e contagem de aprovações compatíveis com combinações de filtros.
- Fechamento da foto reforçado com clique físico, evento JavaScript, botão, Escape e recuperação por atualização da consulta.
- Detecção preventiva de overlays residuais antes de cada nova consulta.
- Tratamento de falhas da interface com retorno a um estado seguro.
- Log persistente de erros inesperados em `%APPDATA%\ValidadorSGL\erros_v9_1.log`.

# Versão 9.1.1

- Corrigido o resumo visual dos seletores múltiplos de razões e códigos.
- Até três opções são exibidas diretamente; acima disso, o campo mostra a quantidade selecionada.
- A lista completa das escolhas permanece disponível ao posicionar o cursor sobre o seletor.

# Versão 9.1.2

- Adicionado resumo permanente e independente dos componentes nativos do Qt.
- Razões e códigos selecionados ficam visíveis no formato `Razão: 1; 2    Código: 3311; 3370`.
- O resumo é atualizado imediatamente ao marcar ou desmarcar qualquer opção.

# Versão 9.1.3

- Corrigida a leitura do estado marcado dos itens no PySide6 para Windows.
- O resumo e os filtros agora reconhecem as opções que aparecem visualmente com ✓.
- Eliminada a comparação incompatível entre o inteiro retornado pelo Qt e `Qt.CheckState.Checked`.

# Versão 9.1.4

- Fechamento da fotografia tornado determinístico após Aprovar ou Reprovar.
- A página de consulta é restaurada após cada decisão, eliminando overlays presos do visualizador.
- Em instalações com várias fotos, o resultado é reconstruído automaticamente antes de abrir a próxima.
- Removida a confirmação baseada apenas na visibilidade da imagem, que podia produzir falso positivo.

# Versão 9.1.5

- Criada recuperação automática para intervenção externa no navegador, aba ou rota do SGL.
- Consultas e abertura de fotos são repetidas uma vez depois da restauração da sessão.
- Navegador é reaberto e autenticado novamente quando fechado ou tornado indisponível.
- Logs irrelevantes de GCM, DevTools e serviços de segundo plano do Chrome foram reduzidos.
- Relatórios bloqueados pelo Excel não encerram mais a análise; os dados são preservados em JSONL.

# Versão 9.2.0

- Catálogo de INFM integrado com filtro exclusivo dos códigos de responsabilidade CEMIG.
- O seletor mostra apenas códigos CEMIG que também existem no concatenado e nos filtros atuais.
- Instalações de múltiplos códigos são embaralhadas conjuntamente dentro de cada polo.
- Relatório de aprovadas reduzido para Polo, Referência, Razão, UL, Instalação, Código, Endereço e Resultado.
- Contrato, quantidade de fotos e data/hora permanecem exclusivamente no registro técnico.
- Todos os arquivos de saída são organizados em `ANALISE_FOTOS_MM-AAAA`.

# Versão 9.3.0

- Bases de identificação de Oeste, Mantiqueira e Triângulo incorporadas ao pacote.
- Removida a seleção manual da planilha de identificação de polos.
- Perfil passa a oferecer uma lista fixa de contratos.
- Trocar o contrato carrega automaticamente suas ULs e polos.
- Perfis antigos continuam compatíveis; o caminho externo anteriormente salvo é ignorado.

# Versão 9.4.0

- Camada visual integralmente refatorada de PySide6/QSS para Flet.
- Copy revisada para auditoria fotográfica, validação e controle de leituras.
- Seleções múltiplas passam a usar modal com caixas de marcação e resumo permanente.
- Layout responsivo para diferentes resoluções do Windows.
- Núcleo Selenium, bases internas, filtros CEMIG, relatórios e recuperação preservados.

# Versão 9.5.0

- Interface refeita fielmente a partir do novo layout de referência.
- Nova identidade em azul-marinho e dourado, com cartões claros e hierarquia visual mais compacta.
- Cabeçalho, configuração, status, registro, ações e rodapé reorganizados conforme o protótipo.
- Timer circular com progresso proporcional ao tempo configurado e alerta visual nos segundos finais.
- Cobertura por polo movida para uma seção em largura total, com até quatro cartões por linha.
- Estados de aprovação e reprovação mantidos em tons suaves, com bordas de confirmação.
- Copies operacionais atualizadas para “Auditoria Operacional · Leituras e Evidências”.
- Fluxo Selenium, relatórios, filtros múltiplos, bases internas e recuperação automática preservados.

# Versão 9.5.1

- Loading reduzido para um modal compacto e centralizado.
- Campo de senha reduzido e botão de visibilidade separado por divisor vertical.
- Divisor inserido entre os grupos de códigos e senha.
- Mês/ano, razões e códigos padronizados visualmente.
- Razões e códigos selecionados agora aparecem diretamente nos respectivos campos.
- Removido o resumo duplicado de filtros abaixo da configuração.

# Versão 9.5.2

- Corrigido o conflito de argumentos `bgcolor` ao construir o campo de senha.
- O componente-base de campos agora aceita sobrescritas de estilo sem duplicar parâmetros no Flet.
- Inicialização completa da interface validada com Flet 0.86.5.

# Versão 9.5.3

- Corrigido o argumento incompatível `size` do botão de exibição da senha.
- O `IconButton` agora utiliza `icon_size`, conforme a API do Flet 0.86.5.
- Inicialização completa revisada sem erros de runtime.

# Versão 9.6.0

- Interface reconstruída fielmente a partir do novo modelo HTML fornecido.
- Cartão de análise passa a reunir dados, decisões, cronômetro e encerramento.
- Cobertura por polo reposicionada na coluna direita, com adaptação responsiva.
- Campos compactos recebem superfícies suaves, bordas refinadas e áreas de seta destacadas.
- Campo de senha reduzido e alinhado à direita, preservando os divisores visuais.
- Metadados do concatenado movidos para a faixa de status.
- Cabeçalho e seletor visual de contrato refinados com acabamento em azul-marinho e dourado.
- Loading compacto, filtros múltiplos e todo o fluxo operacional foram preservados.

# Versão 9.6.1

- Seletor de contrato do cabeçalho integrado ao funcionamento da aplicação.
- Contrato detectado automaticamente pelas ULs existentes no concatenado.
- Seleção manual é confirmada ou corrigida pela validação da base carregada.
- Arquivos com ULs distribuídas de forma ambígua entre contratos são bloqueados.
- Contrato identificado é salvo no perfil e usado imediatamente para classificar os polos.
- Validação confirmada no concatenado de referência: Oeste, com 1.228 ULs correspondentes.

# Versão 9.6.2

- Eliminada a leitura duplicada do concatenado introduzida pela detecção automática do contrato.
- Contrato, polos e registros agora são resolvidos em uma única passagem pelo arquivo Excel.
- No concatenado de referência com 133.386 registros, o carregamento caiu de 17,29 s para 9,64 s.
- Redução medida de aproximadamente 44% no tempo de importação.
- O filtro de códigos CEMIG permanece em memória e não interfere de forma relevante no carregamento.

# Versão 9.6.3

- Removido o reprocessamento integral do concatenado ao salvar configurações.
- Usuário, pasta de relatórios e tempo agora são aplicados imediatamente.
- Contrato detectado pelo concatenado fica bloqueado enquanto a base estiver carregada.
- Trocas incompatíveis de contrato exibem orientação para selecionar o arquivo correspondente.
- Salvamento isolado do perfil medido em menos de 1 ms no ambiente de teste.

# Versão 9.6.4

- Leitura do concatenado removida do executor interno compartilhado do Flet.
- Importação, monitor de eventos e sessão SGL passam a usar threads dedicadas.
- Eliminado o risco de a leitura ficar indefinidamente aguardando uma vaga no executor.
- Loading agora informa o progresso a cada 25 mil linhas processadas.
- Tempo total de carregamento passa a aparecer na faixa de status.
- Concatenado de referência validado novamente em 9,69 s.

# Versão 9.6.5

- Adicionado contador iniciado no momento da seleção do concatenado.
- Fase de preparação exibe o tempo decorrido antes do início da leitura das linhas.
- Após abrir o workbook, a interface mostra total de linhas, percentual e tempo restante estimado.
- Estimativa recalculada continuamente pela velocidade real observada no computador do usuário.
- Progresso interno atualizado a cada 5 mil linhas para dar retorno mais frequente.

# Versão 9.6.6

- Loading do concatenado alterado de animação indeterminada para progresso determinado.
- Reduzido o consumo de renderização da interface enquanto a janela permanece em foco.
- Removida uma atualização duplicada da página em cada avanço do contador.
- Processamento do Excel deixa de competir com animações contínuas do Flet.
- Outros loadings curtos do SGL continuam utilizando indicação indeterminada normalmente.

# Versão 9.6.7

- Revisão completa das copies e mensagens operacionais.
- “Concatenado” passa a ser o termo único para o arquivo de origem.
- “Análise” passa a ser o termo único para o processo completo.
- Campos do registro simplificados para Polo, UL, Razão e Código.
- Modal renomeado para “Perfil e configurações fixas”.
- Labels revisados para Usuário SGL, Pasta dos relatórios e Tempo por instalação.
- Alertas, loading, encerramento e conclusão padronizados com a mesma linguagem.

# Versão 9.6.8

- Corrigida a falha `CERTIFICATE_VERIFY_FAILED` na preparação inicial do Flet.
- Bootstrap TLS executado antes de qualquer importação do cliente visual.
- Bundle combina certificados públicos do `certifi` com o repositório ROOT do Windows.
- Compatibilidade ampliada para redes corporativas com inspeção HTTPS.
- Validação de certificados permanece obrigatória; nenhuma conexão insegura foi habilitada.
- Mensagem específica orienta a instalação do certificado corporativo caso a rede ainda não seja reconhecida.

# V9.6.9

- Adicionada geração de executável autônomo com todas as dependências Python.
- Cliente desktop oficial do Flet incorporado ao pacote do PyInstaller.
- Removido o download do motor visual na primeira execução do executável final.
- Flet fixado na versão 0.86.5 para manter o runtime empacotado compatível.
- Montagem valida o arquivo `flet-windows.zip` antes de criar o executável.
- `build_exe.bat` agora encaminha para o gerador completo.

# V9.6.10

- Corrigida a captura do diretório de `flet_desktop` no gerador para Windows.
- Removido o comando aninhado em `for /f` que quebrava ao interpretar aspas.
- O caminho do cliente Flet agora é transferido por arquivo temporário seguro.

# V9.6.11

- Corrigido o congelamento visual durante consultas e verificações de fotos.
- Eventos do Selenium e da leitura do Excel agora atualizam controles somente pelo loop assíncrono do Flet.
- Removida a atualização da interface a partir de uma thread Python independente.
- Fila de eventos processada em pequenos lotes a cada 50 ms, mantendo cronômetro, loading e botões responsivos.

# V9.6.12

- Padronizadas as alturas, bordas e raios dos campos de configuração.
- Corrigido o recorte das áreas internas de ações, eliminando cantos quadrados sobre campos arredondados.
- Campo de senha alinhado à mesma grade e largura dos demais filtros.
- Seletor de mês/ano recebeu o mesmo contêiner visual de razões e códigos.
- Botões internos e separadores agora seguem dimensões consistentes.

# V9.6.13

- Conteúdo textual dos campos centralizado verticalmente.
- Contraste dos textos auxiliares e valores selecionados ampliado.
- Seletores de razões e códigos deixaram de usar a camada visual cinza do componente Button.
- Setas substituídas por ícones vetoriais centralizados.
- Ícone de exibição da senha recebeu largura, altura e padding explícitos.
- Alinhamento interno do seletor de referência e do campo de senha padronizado.

# V9.6.14

- Arquivo selecionado passou a usar texto centralizado geometricamente, sem baseline de TextField.
- Mês/ano substituído por seletor visual próprio com menu de referências.
- Seta do contrato substituída por ícone vetorial centralizado.
- Campo de senha recebeu compensação vertical específica para o texto editável.
- Removida a dependência do alinhamento vertical dos campos nativos nos elementos somente de seleção.

# V9.6.15

- Razões limitadas aos valores realmente presentes no concatenado e na referência selecionada.
- Adicionado armazenamento persistente da senha do SGL.
- Senha protegida pelo Windows DPAPI e vinculada ao usuário atual do Windows.
- Credencial não é gravada em texto aberto no perfil nem pode ser reutilizada em outra conta do Windows.

# V9.6.16

- Nome e matrícula do leiturista adicionados aos registros técnicos e às aprovações.
- Matrícula extraída da coluna `Matriculas`; nome reconhecido por aliases quando disponível.
- Criado histórico acumulado com detalhe completo, resumo mensal por leiturista e resumo mensal por contrato.
- Resumo do leiturista separado por razão e código, com aprovadas, reprovadas e demais resultados.
- Relatórios antigos são migrados e importados automaticamente sem apagar meses anteriores.
- Eventos históricos são gravados em log leve durante a análise e consolidados ao finalizar.

# V9.6.17

- Adicionada seleção persistente da planilha auxiliar com abas IWOS e MATRÍCULAS.
- A base de colaboradores é relida automaticamente a cada importação do concatenado.
- Matrícula operacional vinculada ao nome, ID IWOS, centro, função, admissão e disponibilidade.
- Aba IWOS atualizada incluída no histórico consolidado.
- Leitura anterior e leitura executada incorporadas aos relatórios.
- Classificação de qualidade e ação sugerida adicionadas conforme o manual de treinamento.
- Resumos mensais agora incluem taxa de reprovação e indicação de reincidência.
