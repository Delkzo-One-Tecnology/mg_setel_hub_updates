from __future__ import annotations

# Fonte: CONTROLE DE INFM.xlsx, aba CÓDIGOS INFM, coluna Responsabilidade=CEMIG.
# Identificadores são texto para preservar comparações com o concatenado.
CODIGOS_CONCESSIONARIA_CEMIG = frozenset({
    "1208", "1209", "1234", "1300", "1600", "1801", "1818", "1819",
    "1841", "2000", "3311", "3376", "3804", "3867", "3894", "3895",
})


def filtrar_codigos_cemig(codigos: list[str]) -> list[str]:
    return [str(codigo) for codigo in codigos if str(codigo) in CODIGOS_CONCESSIONARIA_CEMIG]
