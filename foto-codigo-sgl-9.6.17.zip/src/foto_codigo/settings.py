from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(slots=True)
class Perfil:
    contrato: str = "Oeste"
    base_polos: str = ""  # legado; as bases passaram a ser internas na V9.3
    usuario_sgl: str = ""
    pasta_relatorios: str = ""
    tempo_limite: int = 60
    base_iwos: str = ""


def caminho_configuracao() -> Path:
    raiz = Path(os.environ.get("APPDATA") or Path.home())
    return raiz / "ValidadorSGL" / "config.json"


def carregar_perfil() -> Perfil:
    caminho = caminho_configuracao()
    if not caminho.exists():
        return Perfil()
    try:
        dados = json.loads(caminho.read_text(encoding="utf-8"))
        permitidos = {campo for campo in Perfil.__dataclass_fields__}
        return Perfil(**{k: v for k, v in dados.items() if k in permitidos})
    except (OSError, ValueError, TypeError):
        return Perfil()


def salvar_perfil(perfil: Perfil) -> None:
    caminho = caminho_configuracao()
    caminho.parent.mkdir(parents=True, exist_ok=True)
    temporario = caminho.with_suffix(".tmp")
    temporario.write_text(
        json.dumps(asdict(perfil), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporario.replace(caminho)
