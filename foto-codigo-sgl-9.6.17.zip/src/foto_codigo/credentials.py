from __future__ import annotations

import base64
import ctypes
import json
import os
from ctypes import wintypes
from pathlib import Path


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _caminho_credencial() -> Path:
    raiz = Path(os.environ.get("APPDATA") or Path.home()) / "ValidadorSGL"
    return raiz / "credencial_sgl.json"


def _proteger(texto: str) -> bytes:
    if os.name != "nt":
        raise OSError("O armazenamento seguro de senha requer o Windows.")
    bruto = texto.encode("utf-8")
    buffer = ctypes.create_string_buffer(bruto)
    entrada = _DataBlob(len(bruto), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    saida = _DataBlob()
    crypt32 = ctypes.windll.crypt32
    crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_DataBlob), wintypes.LPCWSTR, ctypes.POINTER(_DataBlob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
    crypt32.CryptProtectData.restype = wintypes.BOOL
    if not crypt32.CryptProtectData(ctypes.byref(entrada), ctypes.c_wchar_p("Validador SGL"), None, None, None, 0x1, ctypes.byref(saida)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(saida.pbData, saida.cbData)
    finally:
        local_free = ctypes.windll.kernel32.LocalFree
        local_free.argtypes = [ctypes.c_void_p]
        local_free.restype = ctypes.c_void_p
        local_free(ctypes.cast(saida.pbData, ctypes.c_void_p))


def _desproteger(dados: bytes) -> str:
    if os.name != "nt":
        raise OSError("O armazenamento seguro de senha requer o Windows.")
    buffer = ctypes.create_string_buffer(dados)
    entrada = _DataBlob(len(dados), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    saida = _DataBlob()
    crypt32 = ctypes.windll.crypt32
    crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_DataBlob), ctypes.POINTER(ctypes.c_wchar_p), ctypes.POINTER(_DataBlob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    if not crypt32.CryptUnprotectData(ctypes.byref(entrada), None, None, None, None, 0x1, ctypes.byref(saida)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(saida.pbData, saida.cbData).decode("utf-8")
    finally:
        local_free = ctypes.windll.kernel32.LocalFree
        local_free.argtypes = [ctypes.c_void_p]
        local_free.restype = ctypes.c_void_p
        local_free(ctypes.cast(saida.pbData, ctypes.c_void_p))


def salvar_senha(usuario: str, senha: str) -> bool:
    """Salva a senha protegida pelo perfil atual do Windows (DPAPI)."""
    if not usuario.strip() or not senha:
        return False
    try:
        caminho = _caminho_credencial()
        caminho.parent.mkdir(parents=True, exist_ok=True)
        conteudo = {
            "usuario": usuario.strip(),
            "senha_protegida": base64.b64encode(_proteger(senha)).decode("ascii"),
        }
        temporario = caminho.with_suffix(".tmp")
        temporario.write_text(json.dumps(conteudo, ensure_ascii=False), encoding="utf-8")
        temporario.replace(caminho)
        return True
    except (OSError, ValueError, TypeError):
        return False


def carregar_senha(usuario: str) -> str:
    """Recupera a senha somente para o mesmo usuário SGL e usuário Windows."""
    try:
        caminho = _caminho_credencial()
        if not caminho.exists():
            return ""
        conteudo = json.loads(caminho.read_text(encoding="utf-8"))
        if str(conteudo.get("usuario", "")).casefold() != usuario.strip().casefold():
            return ""
        protegido = base64.b64decode(conteudo["senha_protegida"], validate=True)
        return _desproteger(protegido)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return ""
