from __future__ import annotations

from collections import Counter
from dataclasses import replace
from datetime import date, datetime, time
from pathlib import Path
import json
import sys
from typing import Callable, Iterable

from openpyxl import load_workbook

from .models import RegistroBase


CONTRATOS_INTERNOS = ("Oeste", "Mantiqueira", "Triângulo")
ARQUIVOS_CONTRATO = {
    "Oeste": "oeste.json",
    "Mantiqueira": "mantiqueira.json",
    "Triângulo": "triangulo.json",
}


def _pasta_recursos() -> Path:
    raiz_empacotada = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    candidatos = (
        raiz_empacotada / "foto_codigo" / "resources",
        raiz_empacotada / "resources",
        Path(__file__).resolve().parent / "resources",
    )
    for pasta in candidatos:
        if pasta.exists():
            return pasta
    raise FileNotFoundError("As bases internas de contratos não foram encontradas no pacote.")


def carregar_mapa_contrato(contrato: str) -> tuple[dict[str, str], list[str]]:
    normalizado = str(contrato or "").strip().casefold()
    canonico = next((item for item in CONTRATOS_INTERNOS if item.casefold() == normalizado), None)
    if not canonico:
        raise ValueError(f"Contrato inválido: {contrato!r}.")
    caminho = _pasta_recursos() / ARQUIVOS_CONTRATO[canonico]
    mapa = json.loads(caminho.read_text(encoding="utf-8"))
    return mapa, sorted(set(mapa.values()))


def _resolver_contrato(
    uls: set[str], mapas: dict[str, dict[str, str]] | None = None
) -> tuple[str, dict[str, int]]:
    mapas = mapas or {
        contrato: carregar_mapa_contrato(contrato)[0]
        for contrato in CONTRATOS_INTERNOS
    }
    pontuacao = {
        contrato: len(uls.intersection(mapa)) for contrato, mapa in mapas.items()
    }
    ranking = sorted(pontuacao.items(), key=lambda item: item[1], reverse=True)
    melhor, acertos = ranking[0]
    segundo = ranking[1][1]
    total_identificado = sum(pontuacao.values())
    if acertos == 0:
        raise ValueError(
            "Nenhuma UL do concatenado foi encontrada nas bases internas de contratos."
        )
    confianca = acertos / total_identificado
    if segundo > 0 and confianca < 0.85:
        detalhes = ", ".join(f"{nome}: {qtd}" for nome, qtd in ranking)
        raise ValueError(
            "O concatenado contém ULs de mais de um contrato e a identificação "
            f"ficou ambígua ({detalhes})."
        )
    return melhor, pontuacao


def detectar_contrato_concatenado(caminho: str | Path) -> tuple[str, dict[str, int]]:
    """Identifica o contrato pelas ULs do concatenado e pelas bases internas.

    As bases são disjuntas. Um arquivo que possua ULs relevantes de mais de um
    contrato é tratado como ambíguo para impedir classificação silenciosa no
    contrato errado.
    """
    wb = load_workbook(caminho, read_only=True, data_only=True)
    try:
        ws = wb.active
        linhas = ws.iter_rows(values_only=True)
        cabecalho = tuple(str(v or "").strip() for v in next(linhas))
        if "Unidade de Leitura" not in cabecalho:
            raise ValueError("O concatenado não possui a coluna Unidade de Leitura.")
        indice_ul = cabecalho.index("Unidade de Leitura")
        uls: set[str] = set()
        for linha in linhas:
            try:
                uls.add(normalizar_ul(linha[indice_ul]))
            except (ValueError, IndexError):
                continue
    finally:
        wb.close()

    if not uls:
        raise ValueError("Não foi possível identificar ULs válidas no concatenado.")

    return _resolver_contrato(uls)


COLUNAS_OBRIGATORIAS = {
    "Unidade de Leitura",
    "Data",
    "Hora",
    "Código",
    "instalação concatenada",
    "Instalação",
}

COLUNAS_MATRICULA = ("Matriculas", "Matrículas", "Matrícula", "Matricula")
COLUNAS_NOME_LEITURISTA = (
    "Nome do leiturista", "Nome do Leiturista", "Leiturista", "Nome", "Colaborador",
)
COLUNAS_LEITURA_ANTERIOR = ("Leitura Anterior", "Leitura anterior")
COLUNAS_LEITURA_EXECUTADA = ("Leitura Executada", "Leitura executada", "Leitura")


def _indice_opcional(cabecalho: tuple[str, ...], aliases: tuple[str, ...]) -> int | None:
    normalizado = {nome.casefold(): indice for indice, nome in enumerate(cabecalho)}
    return next((normalizado[nome.casefold()] for nome in aliases if nome.casefold() in normalizado), None)


def normalizar_identificador(valor: object, largura: int | None = None) -> str:
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        texto = str(int(valor))
    else:
        texto = str(valor).strip()
        if texto.endswith(".0") and texto[:-2].isdigit():
            texto = texto[:-2]
    return texto.zfill(largura) if largura else texto


def normalizar_ul(valor: object) -> str:
    texto = normalizar_identificador(valor)
    if not texto.isdigit() or len(texto) not in (7, 8):
        raise ValueError(f"UL inválida: {valor!r}")
    return texto.zfill(8)


def referencia_de_data(valor: object) -> str:
    if isinstance(valor, datetime):
        return valor.strftime("%m/%Y")
    if isinstance(valor, date):
        return valor.strftime("%m/%Y")
    texto = str(valor).strip()
    for formato in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(texto[:10], formato).strftime("%m/%Y")
        except ValueError:
            pass
    raise ValueError(f"Data inválida: {valor!r}")


def formatar_data(valor: object) -> str:
    return valor.strftime("%d/%m/%Y") if isinstance(valor, (date, datetime)) else str(valor or "")


def formatar_hora(valor: object) -> str:
    if isinstance(valor, (time, datetime)):
        return valor.strftime("%H:%M:%S")
    return str(valor or "")


def extrair_endereco(concatenado: object, instalacao: str) -> str:
    texto = str(concatenado or "").strip()
    if texto.startswith(instalacao) and len(texto) > len(instalacao) + 12:
        # Padrão observado: IN (10) + código alfanumérico (12) + endereço.
        return texto[len(instalacao) + 12 :].strip()
    return texto


def carregar_mapa_polos(caminho: str | Path) -> tuple[dict[str, str], list[str]]:
    wb = load_workbook(caminho, read_only=True, data_only=True)
    try:
        ws = wb.active
        cabecalho = [str(c.value or "").strip() for c in next(ws.iter_rows())]
        try:
            indice_ul = cabecalho.index("UL")
            indice_polo = cabecalho.index("SUPERVISÃO")
        except ValueError as exc:
            raise ValueError("A base de polos precisa das colunas UL e SUPERVISÃO.") from exc

        mapa: dict[str, str] = {}
        for linha in ws.iter_rows(min_row=2, values_only=True):
            if linha[indice_ul] is None:
                continue
            ul = normalizar_ul(linha[indice_ul])
            polo = str(linha[indice_polo] or "").strip().upper()
            if not polo:
                continue
            anterior = mapa.get(ul)
            if anterior and anterior != polo:
                raise ValueError(f"UL {ul} associada a dois polos: {anterior} e {polo}.")
            mapa[ul] = polo
        return mapa, sorted(set(mapa.values()))
    finally:
        wb.close()


def carregar_concatenado(
    caminho: str | Path,
    mapa_polos: dict[str, str],
    progresso: Callable[[int, int, str], None] | None = None,
) -> tuple[list[RegistroBase], dict[str, object]]:
    if progresso:
        progresso(0, 0, "abrindo")
    wb = load_workbook(caminho, read_only=True, data_only=True)
    try:
        ws = wb.active
        total_linhas = max(0, int(ws.max_row or 1) - 1)
        if progresso:
            progresso(0, total_linhas, "lendo")
        linhas = ws.iter_rows(values_only=True)
        cabecalho = tuple(str(v or "").strip() for v in next(linhas))
        ausentes = COLUNAS_OBRIGATORIAS - set(cabecalho)
        if ausentes:
            raise ValueError("Colunas ausentes no concatenado: " + ", ".join(sorted(ausentes)))
        idx = {nome: cabecalho.index(nome) for nome in COLUNAS_OBRIGATORIAS}
        idx_matricula = _indice_opcional(cabecalho, COLUNAS_MATRICULA)
        idx_nome = _indice_opcional(cabecalho, COLUNAS_NOME_LEITURISTA)
        idx_leitura_anterior = _indice_opcional(cabecalho, COLUNAS_LEITURA_ANTERIOR)
        idx_leitura_executada = _indice_opcional(cabecalho, COLUNAS_LEITURA_EXECUTADA)
        registros: list[RegistroBase] = []
        datas_validas: list[date] = []
        erros_ul = 0
        for numero_linha, linha in enumerate(linhas, start=1):
            if progresso and numero_linha % 5000 == 0:
                progresso(numero_linha, total_linhas, "lendo")
            try:
                ul = normalizar_ul(linha[idx["Unidade de Leitura"]])
            except ValueError:
                erros_ul += 1
                continue
            instalacao = normalizar_identificador(linha[idx["Instalação"]])
            codigo = normalizar_identificador(linha[idx["Código"]])
            data_valor = linha[idx["Data"]]
            try:
                referencia = referencia_de_data(data_valor)
            except ValueError:
                continue
            if isinstance(data_valor, datetime):
                datas_validas.append(data_valor.date())
            elif isinstance(data_valor, date):
                datas_validas.append(data_valor)
            registros.append(
                RegistroBase(
                    ul=ul,
                    razao=int(ul[:2]),
                    instalacao=instalacao,
                    codigo=codigo,
                    endereco=extrair_endereco(
                        linha[idx["instalação concatenada"]], instalacao
                    ),
                    referencia=referencia,
                    data_origem=formatar_data(data_valor),
                    hora_origem=formatar_hora(linha[idx["Hora"]]),
                    polo=mapa_polos.get(ul, "NÃO IDENTIFICADO"),
                    matricula_leiturista=(
                        normalizar_identificador(linha[idx_matricula])
                        if idx_matricula is not None else ""
                    ),
                    nome_leiturista=(
                        str(linha[idx_nome] or "").strip() or "NÃO INFORMADO"
                        if idx_nome is not None else "NÃO INFORMADO"
                    ),
                    leitura_anterior=(normalizar_identificador(linha[idx_leitura_anterior]) if idx_leitura_anterior is not None else ""),
                    leitura_executada=(normalizar_identificador(linha[idx_leitura_executada]) if idx_leitura_executada is not None else ""),
                )
            )
        referencias = Counter(r.referencia for r in registros)
        return registros, {
            "total": len(registros),
            "referencias": dict(sorted(referencias.items())),
            "data_mais_recente": max(datas_validas).strftime("%d/%m/%Y") if datas_validas else "",
            "uls_sem_polo": len({r.ul for r in registros if r.polo == "NÃO IDENTIFICADO"}),
            "erros_ul": erros_ul,
        }
    finally:
        wb.close()


def carregar_concatenado_auto(
    caminho: str | Path,
    progresso: Callable[[int, int, str], None] | None = None,
) -> tuple[
    list[RegistroBase], dict[str, object], str, dict[str, int], dict[str, str], list[str]
]:
    """Carrega o Excel uma única vez e identifica contrato e polos na memória."""
    mapas = {
        contrato: carregar_mapa_contrato(contrato)[0]
        for contrato in CONTRATOS_INTERNOS
    }
    mapa_unificado: dict[str, str] = {}
    proprietario: dict[str, str] = {}
    for contrato, mapa in mapas.items():
        mapa_unificado.update(mapa)
        proprietario.update({ul: contrato for ul in mapa})

    registros, resumo = carregar_concatenado(caminho, mapa_unificado, progresso)
    contrato, pontuacao = _resolver_contrato({r.ul for r in registros}, mapas)
    registros = [
        r if proprietario.get(r.ul) == contrato else replace(r, polo="NÃO IDENTIFICADO")
        for r in registros
    ]
    resumo["uls_sem_polo"] = len(
        {r.ul for r in registros if r.polo == "NÃO IDENTIFICADO"}
    )
    mapa = mapas[contrato]
    return registros, resumo, contrato, pontuacao, mapa, sorted(set(mapa.values()))


def filtrar_registros(
    registros: Iterable[RegistroBase],
    referencia: str,
    razao: int | Iterable[int],
    codigo: str | Iterable[str],
    polo: str | None = None,
) -> list[RegistroBase]:
    razoes = {razao} if isinstance(razao, int) else {int(item) for item in razao}
    codigos = {str(codigo)} if isinstance(codigo, str) else {str(item) for item in codigo}
    # Uma instalação pode aparecer mais de uma vez. Mantém a ocorrência mais recente.
    unicos: dict[str, RegistroBase] = {}
    for registro in registros:
        if (
            registro.referencia == referencia
            and (polo is None or registro.polo == polo)
            and registro.razao in razoes
            and registro.codigo in codigos
            and registro.instalacao
        ):
            unicos[registro.instalacao] = registro
    return list(unicos.values())


def opcoes_dependentes(
    registros: Iterable[RegistroBase], referencia: str = "", polo: str = "",
    razao: int | Iterable[int] | None = None,
) -> dict[str, list[str]]:
    selecionados = [r for r in registros if not referencia or r.referencia == referencia]
    polos = sorted({r.polo for r in selecionados})
    if polo:
        selecionados = [r for r in selecionados if r.polo == polo]
    # Não completa artificialmente o intervalo 1..18: oferece somente razões
    # efetivamente encontradas nas linhas do concatenado para a referência/polo.
    razoes = sorted({str(r.razao) for r in selecionados if 1 <= int(r.razao) <= 18}, key=int)
    if razao is not None:
        razoes_filtro = {razao} if isinstance(razao, int) else {int(item) for item in razao}
        selecionados = [r for r in selecionados if r.razao in razoes_filtro]
    codigos = sorted({r.codigo for r in selecionados}, key=lambda x: (not x.isdigit(), int(x) if x.isdigit() else x))
    return {"polos": polos, "razoes": razoes, "codigos": codigos}
