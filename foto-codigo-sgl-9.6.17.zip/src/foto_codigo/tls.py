from __future__ import annotations

import os
import ssl
from pathlib import Path

import certifi


def configurar_certificados() -> Path:
    """Combina as autoridades públicas com o repositório confiável do Windows."""
    raiz = Path(os.environ.get("APPDATA") or Path.home()) / "ValidadorSGL"
    raiz.mkdir(parents=True, exist_ok=True)
    destino = raiz / "certificados_confiaveis.pem"

    partes = [Path(certifi.where()).read_text(encoding="ascii")]
    enum_certificados = getattr(ssl, "enum_certificates", None)
    if enum_certificados:
        try:
            for certificado, formato, confianca in enum_certificados("ROOT"):
                if formato == "x509_asn":
                    partes.append(ssl.DER_cert_to_PEM_cert(certificado))
        except OSError:
            # O bundle público continua válido mesmo se o Windows negar a leitura.
            pass

    temporario = destino.with_suffix(".tmp")
    temporario.write_text("\n".join(partes), encoding="ascii")
    temporario.replace(destino)
    os.environ["SSL_CERT_FILE"] = str(destino)
    os.environ["REQUESTS_CA_BUNDLE"] = str(destino)
    return destino
