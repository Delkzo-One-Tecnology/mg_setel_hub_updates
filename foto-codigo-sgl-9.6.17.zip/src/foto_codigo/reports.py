from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from threading import Lock

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo

from .models import ResultadoAnalise, StatusAnalise


CABECALHO_TECNICO = [
    "Contrato", "Polo", "Referência", "Nome do leiturista", "Matrícula", "ID IWOS",
    "Centro IWOS", "Função", "Admissão", "Disponibilidade", "Razão", "UL", "Instalação", "Código",
    "Endereço", "Data origem", "Hora origem", "Leitura anterior", "Leitura executada", "Status",
    "Classificação de qualidade", "Ação sugerida", "Total de fotos",
    "Fotos verificadas", "Foto reprovada", "Duração (s)", "Observação", "Analisado em",
]
CABECALHO_FINAL = [
    "Polo", "Referência", "Nome do leiturista", "Matrícula", "ID IWOS", "Centro IWOS",
    "Função", "Disponibilidade", "Razão", "UL", "Instalação", "Código", "Endereço",
    "Leitura anterior", "Leitura executada", "Resultado",
]

CABECALHO_HISTORICO_LEITURISTA = [
    "Contrato", "Referência", "Nome do leiturista", "Matrícula", "ID IWOS", "Centro IWOS",
    "Função", "Admissão", "Disponibilidade", "Razão", "Código",
    "Aprovadas", "Reprovadas", "Verificações", "Sem foto", "Erros", "Interrompidas",
    "Total analisado", "Taxa de reprovação", "Reincidência", "Fotos disponíveis", "Fotos verificadas", "Duração total (s)",
]
CABECALHO_HISTORICO_CONTRATO = [
    "Contrato", "Referência", "Leituristas", "ULs analisadas", "Aprovadas", "Reprovadas",
    "Verificações", "Sem foto", "Erros", "Interrompidas", "Total analisado",
    "Taxa de reprovação", "Fotos disponíveis", "Fotos verificadas", "Duração total (s)", "Duração média (s)",
]


class GerenciadorRelatorios:
    def __init__(self, pasta: str | Path, referencia: str, linhas_iwos: list[list[object]] | None = None) -> None:
        raiz = Path(pasta)
        sufixo = referencia.replace("/", "-")
        self.pasta = raiz / f"ANALISE_FOTOS_{sufixo}"
        self.pasta.mkdir(parents=True, exist_ok=True)
        self.caminho_tecnico = self.pasta / f"REGISTRO_TECNICO_{sufixo}.xlsx"
        self.caminho_final = self.pasta / f"RELATORIO_APROVADAS_{sufixo}.xlsx"
        self.caminho_estado = self.pasta / f"estado_{sufixo}.json"
        self.caminho_respaldo = self.pasta / f"RESPALDO_PENDENTE_{sufixo}.jsonl"
        self.caminho_historico = raiz / "HISTORICO_ANALISE_FOTOS.xlsx"
        self.caminho_eventos_historico = raiz / "historico_analise_fotos.jsonl"
        self._lock = Lock()
        self.linhas_iwos = linhas_iwos or []
        self._garantir_arquivo(self.caminho_tecnico, "Registro técnico", CABECALHO_TECNICO)
        self._garantir_arquivo(self.caminho_final, "Aprovadas", CABECALHO_FINAL)
        self._importar_historico_existente()

    @staticmethod
    def _garantir_arquivo(caminho: Path, aba: str, cabecalho: list[str]) -> None:
        if caminho.exists():
            wb_antigo = load_workbook(caminho)
            ws_antigo = wb_antigo.active
            atual = [str(c.value or "") for c in ws_antigo[1]]
            if atual == cabecalho:
                wb_antigo.close()
                return
            linhas = list(ws_antigo.iter_rows(min_row=2, values_only=True))
            wb_antigo.close()
            mapa = {nome: indice for indice, nome in enumerate(atual)}
            wb = Workbook()
            ws = wb.active
            ws.title = aba
            ws.append(cabecalho)
            for linha in linhas:
                ws.append([
                    linha[mapa[nome]] if nome in mapa and mapa[nome] < len(linha)
                    else ("NÃO INFORMADO" if nome == "Nome do leiturista" else "")
                    for nome in cabecalho
                ])
            ws.freeze_panes = "A2"
            for celula in ws[1]:
                celula.font = Font(bold=True, color="FFFFFF")
                celula.fill = PatternFill("solid", fgColor="007F73")
                celula.alignment = Alignment(horizontal="center")
            wb.save(caminho)
            return
        wb = Workbook()
        ws = wb.active
        ws.title = aba
        ws.append(cabecalho)
        ws.freeze_panes = "A2"
        for celula in ws[1]:
            celula.font = Font(bold=True, color="FFFFFF")
            celula.fill = PatternFill("solid", fgColor="007F73")
            celula.alignment = Alignment(horizontal="center")
        wb.save(caminho)

    def _importar_historico_existente(self) -> None:
        """Inicializa o histórico com relatórios mensais criados em versões anteriores."""
        if self.caminho_eventos_historico.exists():
            return
        eventos: list[dict[str, object]] = []
        for caminho in sorted(self.pasta.parent.glob("ANALISE_FOTOS_*/REGISTRO_TECNICO_*.xlsx")):
            wb = load_workbook(caminho, read_only=True, data_only=True)
            try:
                ws = wb.active
                cabecalho = [str(c.value or "") for c in ws[1]]
                idx = {nome: indice for indice, nome in enumerate(cabecalho)}
                for linha in ws.iter_rows(min_row=2, values_only=True):
                    if not any(valor not in (None, "") for valor in linha):
                        continue
                    def valor(nome: str, padrao: object = "") -> object:
                        indice = idx.get(nome)
                        return linha[indice] if indice is not None and indice < len(linha) else padrao
                    eventos.append({
                        "contrato": valor("Contrato"), "polo": valor("Polo"),
                        "referencia": valor("Referência"),
                        "nome_leiturista": valor("Nome do leiturista", "NÃO INFORMADO"),
                        "matricula_leiturista": valor("Matrícula"), "razao": valor("Razão"),
                        "id_iwos": valor("ID IWOS"), "centro_iwos": valor("Centro IWOS"),
                        "funcao_iwos": valor("Função"), "admissao_iwos": valor("Admissão"),
                        "disponibilidade_iwos": valor("Disponibilidade"),
                        "ul": valor("UL"), "instalacao": valor("Instalação"),
                        "codigo": valor("Código"), "endereco": valor("Endereço"),
                        "data_origem": valor("Data origem"), "hora_origem": valor("Hora origem"),
                        "leitura_anterior": valor("Leitura anterior"),
                        "leitura_executada": valor("Leitura executada"),
                        "status": valor("Status"), "total_fotos": valor("Total de fotos", 0),
                        "classificacao_qualidade": valor("Classificação de qualidade"),
                        "acao_sugerida": valor("Ação sugerida"),
                        "fotos_verificadas": valor("Fotos verificadas", 0),
                        "foto_reprovada": valor("Foto reprovada"),
                        "duracao_segundos": valor("Duração (s)", 0),
                        "observacao": valor("Observação"), "analisado_em": valor("Analisado em"),
                    })
            finally:
                wb.close()
        if eventos:
            with self.caminho_eventos_historico.open("w", encoding="utf-8") as arquivo:
                for evento in eventos:
                    arquivo.write(json.dumps(evento, ensure_ascii=False) + "\n")

    @staticmethod
    def _qualidade(status: StatusAnalise | str) -> tuple[str, str]:
        return {
            str(StatusAnalise.APROVADA): ("CONFORME", "SEM AÇÃO"),
            str(StatusAnalise.REPROVADA): ("INCONSISTENTE", "VALIDAR E ORIENTAR / AÇÃO CORRETIVA"),
            str(StatusAnalise.VERIFICACAO): ("PENDENTE", "REVISAR EVIDÊNCIA"),
            str(StatusAnalise.SEM_FOTO): ("FOTO INSUFICIENTE", "VALIDAR RETORNO AO IMÓVEL"),
            str(StatusAnalise.ERRO): ("PENDENTE", "REPROCESSAR CONSULTA"),
            str(StatusAnalise.INTERROMPIDA): ("PENDENTE", "RETOMAR ANÁLISE"),
        }.get(str(status), ("PENDENTE", "REVISAR"))

    @staticmethod
    def _linha_tecnica(resultado: ResultadoAnalise) -> list[object]:
        r = resultado.registro
        classificacao, acao = GerenciadorRelatorios._qualidade(resultado.status)
        return [
            resultado.contrato, r.polo, r.referencia, r.nome_leiturista,
            r.matricula_leiturista, r.id_iwos, r.centro_iwos, r.funcao_iwos,
            r.admissao_iwos, r.disponibilidade_iwos, r.razao, r.ul, r.instalacao,
            r.codigo, r.endereco, r.data_origem, r.hora_origem, r.leitura_anterior,
            r.leitura_executada, str(resultado.status), classificacao, acao,
            resultado.total_fotos, resultado.fotos_verificadas,
            resultado.foto_reprovada or "", resultado.duracao_segundos,
            resultado.observacao, resultado.analisado_em,
        ]

    @staticmethod
    def _linha_final(resultado: ResultadoAnalise) -> list[object]:
        r = resultado.registro
        return [
            r.polo, r.referencia, r.nome_leiturista, r.matricula_leiturista, r.id_iwos,
            r.centro_iwos, r.funcao_iwos, r.disponibilidade_iwos, r.razao, r.ul,
            r.instalacao, r.codigo, r.endereco, r.leitura_anterior, r.leitura_executada, "Aprovada",
        ]

    def registrar(self, resultado: ResultadoAnalise) -> None:
        with self._lock:
            self._anexar(self.caminho_tecnico, self._linha_tecnica(resultado))
            if resultado.status == StatusAnalise.APROVADA:
                self._anexar(self.caminho_final, self._linha_final(resultado))
            with self.caminho_eventos_historico.open("a", encoding="utf-8") as arquivo:
                arquivo.write(json.dumps(resultado.linha_tecnica(), ensure_ascii=False) + "\n")

    def registrar_com_respaldo(self, resultado: ResultadoAnalise) -> bool:
        """Registra no Excel ou preserva integralmente em JSONL se estiver bloqueado."""
        try:
            self.registrar(resultado)
            return True
        except (PermissionError, OSError):
            with self._lock:
                with self.caminho_respaldo.open("a", encoding="utf-8") as arquivo:
                    arquivo.write(json.dumps(resultado.linha_tecnica(), ensure_ascii=False) + "\n")
            return False

    @staticmethod
    def _anexar(caminho: Path, linha: list[object]) -> None:
        wb = load_workbook(caminho)
        ws = wb.active
        ws.append(linha)
        for coluna in range(1, ws.max_column + 1):
            ws.column_dimensions[ws.cell(1, coluna).column_letter].width = min(
                55, max(12, len(str(ws.cell(1, coluna).value)) + 2)
            )
        wb.save(caminho)

    def processadas(
        self, contrato: str | None = None, referencia: str | None = None,
        razao: int | set[int] | tuple[int, ...] | None = None,
        codigo: str | set[str] | tuple[str, ...] | None = None,
    ) -> set[str]:
        razoes = None if razao is None else ({razao} if isinstance(razao, int) else {int(v) for v in razao})
        codigos = None if codigo is None else ({codigo} if isinstance(codigo, str) else {str(v) for v in codigo})
        wb = load_workbook(self.caminho_tecnico, read_only=True, data_only=True)
        try:
            ws = wb.active
            cab = {str(c.value): i for i, c in enumerate(ws[1])}
            return {
                str(linha[cab["Instalação"]])
                for linha in ws.iter_rows(min_row=2, values_only=True)
                if linha[cab["Instalação"]] not in (None, "")
                and (contrato is None or linha[cab["Contrato"]] == contrato)
                and (referencia is None or linha[cab["Referência"]] == referencia)
                and (razoes is None or int(linha[cab["Razão"]]) in razoes)
                and (codigos is None or str(linha[cab["Código"]]) in codigos)
            }
        finally:
            wb.close()

    def aprovadas_por_polo(
        self, contrato: str, referencia: str,
        razao: int | set[int] | tuple[int, ...],
        codigo: str | set[str] | tuple[str, ...],
    ) -> dict[str, int]:
        razoes = {razao} if isinstance(razao, int) else {int(v) for v in razao}
        codigos = {codigo} if isinstance(codigo, str) else {str(v) for v in codigo}
        contagem: dict[str, int] = {}
        wb = load_workbook(self.caminho_tecnico, read_only=True, data_only=True)
        try:
            ws = wb.active
            cab = {str(c.value): i for i, c in enumerate(ws[1])}
            for linha in ws.iter_rows(min_row=2, values_only=True):
                if (
                    linha[cab["Contrato"]] == contrato and linha[cab["Referência"]] == referencia
                    and int(linha[cab["Razão"]]) in razoes and str(linha[cab["Código"]]) in codigos
                    and linha[cab["Status"]] == str(StatusAnalise.APROVADA)
                ):
                    polo = str(linha[cab["Polo"]])
                    contagem[polo] = contagem.get(polo, 0) + 1
            return contagem
        finally:
            wb.close()

    def salvar_estado(self, dados: dict[str, object]) -> None:
        temporario = self.caminho_estado.with_suffix(".tmp")
        temporario.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
        temporario.replace(self.caminho_estado)

    def finalizar(self) -> None:
        with self._lock:
            self._formatar(self.caminho_tecnico, "TabelaRegistro")
            self._formatar(self.caminho_final, "TabelaAprovadas")
            self._gerar_historico()

    def _gerar_historico(self) -> None:
        """Reconstrói o histórico acumulado a partir do log durável de eventos."""
        eventos: list[dict[str, object]] = []
        if self.caminho_eventos_historico.exists():
            for linha in self.caminho_eventos_historico.read_text(encoding="utf-8").splitlines():
                try:
                    eventos.append(json.loads(linha))
                except (json.JSONDecodeError, TypeError):
                    continue

        wb = Workbook()
        ws_detalhe = wb.active
        ws_detalhe.title = "Histórico detalhado"
        ws_detalhe.append(CABECALHO_TECNICO)
        por_leiturista: dict[tuple[object, ...], list[int]] = defaultdict(lambda: [0] * 10)
        por_contrato: dict[tuple[str, str], dict[str, object]] = {}
        mapa_status = {
            str(StatusAnalise.APROVADA): 0, str(StatusAnalise.REPROVADA): 1,
            str(StatusAnalise.VERIFICACAO): 2, str(StatusAnalise.SEM_FOTO): 3,
            str(StatusAnalise.ERRO): 4, str(StatusAnalise.INTERROMPIDA): 5,
        }
        for e in eventos:
            classificacao, acao = self._qualidade(str(e.get("status", "")))
            ws_detalhe.append([
                e.get("contrato", ""), e.get("polo", ""), e.get("referencia", ""),
                e.get("nome_leiturista", "NÃO INFORMADO"), e.get("matricula_leiturista", ""),
                e.get("id_iwos", ""), e.get("centro_iwos", ""), e.get("funcao_iwos", ""),
                e.get("admissao_iwos", ""), e.get("disponibilidade_iwos", ""),
                e.get("razao", ""), e.get("ul", ""), e.get("instalacao", ""), e.get("codigo", ""),
                e.get("endereco", ""), e.get("data_origem", ""), e.get("hora_origem", ""),
                e.get("leitura_anterior", ""), e.get("leitura_executada", ""),
                e.get("status", ""), e.get("classificacao_qualidade") or classificacao,
                e.get("acao_sugerida") or acao, e.get("total_fotos", 0), e.get("fotos_verificadas", 0),
                e.get("foto_reprovada", ""), e.get("duracao_segundos", 0),
                e.get("observacao", ""), e.get("analisado_em", ""),
            ])
            chave_l = (e.get("contrato", ""), e.get("referencia", ""),
                       e.get("nome_leiturista", "NÃO INFORMADO"), e.get("matricula_leiturista", ""),
                       e.get("id_iwos", ""), e.get("centro_iwos", ""), e.get("funcao_iwos", ""),
                       e.get("admissao_iwos", ""), e.get("disponibilidade_iwos", ""),
                       e.get("razao", ""), e.get("codigo", ""))
            agg = por_leiturista[chave_l]
            indice = mapa_status.get(str(e.get("status", "")))
            if indice is not None:
                agg[indice] += 1
            agg[6] += 1
            agg[7] += int(e.get("total_fotos", 0) or 0)
            agg[8] += int(e.get("fotos_verificadas", 0) or 0)
            agg[9] += int(e.get("duracao_segundos", 0) or 0)

            chave_c = (str(e.get("contrato", "")), str(e.get("referencia", "")))
            c = por_contrato.setdefault(chave_c, {
                "leituristas": set(), "uls": set(), "status": [0] * 6,
                "total": 0, "fotos": 0, "verificadas": 0, "duracao": 0,
            })
            identificador = str(e.get("matricula_leiturista", "") or e.get("nome_leiturista", ""))
            if identificador:
                c["leituristas"].add(identificador)
            if e.get("ul"):
                c["uls"].add(str(e["ul"]))
            if indice is not None:
                c["status"][indice] += 1
            c["total"] += 1
            c["fotos"] += int(e.get("total_fotos", 0) or 0)
            c["verificadas"] += int(e.get("fotos_verificadas", 0) or 0)
            c["duracao"] += int(e.get("duracao_segundos", 0) or 0)

        ws_l = wb.create_sheet("Mensal por leiturista")
        ws_l.append(CABECALHO_HISTORICO_LEITURISTA)
        for chave, valores in sorted(por_leiturista.items(), key=lambda item: tuple(map(str, item[0]))):
            taxa = valores[1] / valores[6] if valores[6] else 0
            reincidencia = "SIM" if valores[1] >= 2 else "NÃO"
            ws_l.append([*chave, *valores[:7], taxa, reincidencia, *valores[7:]])

        ws_c = wb.create_sheet("Mensal por contrato")
        ws_c.append(CABECALHO_HISTORICO_CONTRATO)
        for chave, c in sorted(por_contrato.items()):
            media = round(c["duracao"] / c["total"], 2) if c["total"] else 0
            taxa = c["status"][1] / c["total"] if c["total"] else 0
            ws_c.append([*chave, len(c["leituristas"]), len(c["uls"]), *c["status"],
                         c["total"], taxa, c["fotos"], c["verificadas"], c["duracao"], media])

        if self.linhas_iwos:
            ws_i = wb.create_sheet("IWOS")
            for linha in self.linhas_iwos:
                ws_i.append(linha)

        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            for celula in ws[1]:
                celula.font = Font(bold=True, color="FFFFFF")
                celula.fill = PatternFill("solid", fgColor="007F73")
                celula.alignment = Alignment(horizontal="center")
            for coluna in range(1, ws.max_column + 1):
                maior = max(
                    (len(str(ws.cell(linha, coluna).value or "")) for linha in range(1, min(ws.max_row, 250) + 1)),
                    default=10,
                )
                ws.column_dimensions[ws.cell(1, coluna).column_letter].width = min(38, max(12, maior + 2))
                if str(ws.cell(1, coluna).value) == "Taxa de reprovação":
                    for celula in ws.iter_cols(min_col=coluna, max_col=coluna, min_row=2):
                        for item in celula:
                            item.number_format = "0.0%"
                if ws.title == "IWOS" and str(ws.cell(1, coluna).value) == "Admissão":
                    for celula in ws.iter_cols(min_col=coluna, max_col=coluna, min_row=2):
                        for item in celula:
                            item.number_format = "dd/mm/yyyy"
            if ws.max_row >= 2:
                nome = {"Histórico detalhado": "TabelaHistorico", "Mensal por leiturista": "TabelaLeiturista",
                        "Mensal por contrato": "TabelaContrato", "IWOS": "TabelaIWOS"}[ws.title]
                tabela = Table(displayName=nome, ref=f"A1:{ws.cell(ws.max_row, ws.max_column).coordinate}")
                tabela.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
                ws.add_table(tabela)
        wb.save(self.caminho_historico)

    @staticmethod
    def _formatar(caminho: Path, nome_tabela: str) -> None:
        wb = load_workbook(caminho)
        ws = wb.active
        if ws.max_row >= 2:
            referencia = f"A1:{ws.cell(ws.max_row, ws.max_column).coordinate}"
            if ws.tables:
                next(iter(ws.tables.values())).ref = referencia
            else:
                tabela = Table(displayName=nome_tabela, ref=referencia)
                tabela.tableStyleInfo = TableStyleInfo(
                    name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False,
                    showRowStripes=True, showColumnStripes=False,
                )
                ws.add_table(tabela)
        ws.auto_filter.ref = ws.dimensions
        wb.save(caminho)
