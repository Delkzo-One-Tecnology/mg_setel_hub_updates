from __future__ import annotations

import asyncio, os, queue, threading, time, traceback
from dataclasses import replace
from pathlib import Path
import flet as ft

from .catalog import filtrar_codigos_cemig
from .credentials import carregar_senha, salvar_senha
from .data import CONTRATOS_INTERNOS, carregar_concatenado_auto, carregar_mapa_contrato, filtrar_registros, opcoes_dependentes
from .models import RegistroBase
from .iwos import carregar_base_iwos
from .reports import GerenciadorRelatorios
from .session import ConfiguracaoSessao, SessaoAnalise
from .settings import Perfil, carregar_perfil, salvar_perfil

NAVY="#1B3350"; NAVY_INK="#0F2038"; INK="#12151C"; SLATE="#63697A"; MUTED="#9AA0AE"; BORDER="#E1E4EA"
PAPER="#F3F4F7"; WHITE="#FFFFFF"; SURFACE="#FAFBFC"; GREEN="#1F7A4C"; RED="#B23A34"; BRASS="#A9762F"; AMBER=BRASS
FIELD_TEXT="#27364A"; FIELD_HINT="#667085"; FIELD_ACTION="#EAF0F6"
FIELD_HEIGHT=42; FIELD_RADIUS=8; ACTION_WIDTH=116; SELECT_ACTION_WIDTH=44

def diagnostico(texto: str) -> Path:
    raiz=Path(os.environ.get("APPDATA") or Path.home())/"ValidadorSGL"; raiz.mkdir(parents=True,exist_ok=True)
    caminho=raiz/"erros_v9_6.log"
    with caminho.open("a",encoding="utf-8") as arq: arq.write("\n"+"="*72+"\n"+texto.rstrip()+"\n")
    return caminho

class App:
    def __init__(self,page:ft.Page):
        self.page=page; self.perfil=carregar_perfil(); self.registros=[]; self.mapa_polos={}; self.linhas_iwos=[]; self.caminho="";self.contrato_detectado=None;self.leitura_estado={};self.leitura_parar=None
        self.razoes=[]; self.codigos=[]; self.sel_razoes=set(); self.sel_codigos=set(); self.fila=queue.Queue(); self.sessao=None; self.fechada=False
        self._configurar(); self._montar(); self._carregar_perfil(); self.page.run_task(self._eventos)

    def _thread(self,alvo,nome):
        thread=threading.Thread(target=alvo,name=f"sgl-{nome}",daemon=True);thread.start();return thread

    def _configurar(self):
        p=self.page; p.title="Validador de Fotos e Códigos — SGL"; p.bgcolor=PAPER; p.padding=0; p.theme_mode=ft.ThemeMode.LIGHT
        p.theme=ft.Theme(font_family="Inter",color_scheme=ft.ColorScheme(primary=NAVY,secondary=BRASS,surface=WHITE))
        p.window.width=1280; p.window.height=900; p.window.min_width=1040; p.window.min_height=700; p.on_close=self._fechar

    def card(self,content,padding=18,**kw):
        return ft.Container(content=content,bgcolor=WHITE,border=ft.Border.all(1,BORDER),border_radius=10,padding=padding,shadow=ft.BoxShadow(blur_radius=12,color="#0812151C",offset=ft.Offset(0,1)),**kw)
    def label(self,s): return ft.Text(s.upper(),size=10,weight=ft.FontWeight.W_600,color=SLATE)
    def campo(self,**kw):
        padroes={"height":FIELD_HEIGHT,"text_size":12,"color":FIELD_TEXT,"hint_style":ft.TextStyle(size=12,color=FIELD_HINT),"border_color":BORDER,"focused_border_color":BRASS,"border_radius":FIELD_RADIUS,"content_padding":ft.Padding.only(left=12,right=12,top=0,bottom=2),"bgcolor":SURFACE}
        padroes.update(kw)
        return ft.TextField(**padroes)
    def botao(self,s,fn,secondary=False,disabled=False):
        return ft.Button(content=s,on_click=fn,disabled=disabled,height=42,bgcolor=WHITE if secondary else NAVY,color=SLATE if secondary else WHITE,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=7),side=ft.BorderSide(1,BORDER if secondary else NAVY),elevation=0))

    def _montar(self):
        self.txt_contrato=ft.Text("—",size=12,color=WHITE,weight=ft.FontWeight.W_700)
        self.txt_usuario=ft.Text("Configurações",size=12,color=WHITE,weight=ft.FontWeight.W_500)
        marca=ft.Row([ft.Container(width=38,height=38,border_radius=8,bgcolor=BRASS,alignment=ft.Alignment.CENTER,content=ft.Text("SGL",color=NAVY_INK,weight=ft.FontWeight.BOLD,size=12)),ft.Column([ft.Text("Validador de Fotos e Códigos",size=17,color=WHITE,weight=ft.FontWeight.W_600),ft.Text("Auditoria Operacional · Leituras e Evidências",size=11,color="#B9C4D3")],spacing=1)],spacing=14)
        contrato_chip=ft.Container(content=ft.Row([ft.Text("Contrato",size=11,color="#B9C4D3"),ft.Container(width=1,height=16,bgcolor="#55FFFFFF"),self.txt_contrato,ft.Container(width=31,height=31,border_radius=9,bgcolor="#70A9762F",border=ft.Border.all(1,"#5CF4E9D8"),alignment=ft.Alignment.CENTER,content=ft.Icon(ft.Icons.KEYBOARD_ARROW_DOWN,size=18,color="#FFF8EE"))],spacing=9,vertical_alignment=ft.CrossAxisAlignment.CENTER),bgcolor="#14FFFFFF",border=ft.Border.all(1,"#29FFFFFF"),border_radius=8,padding=ft.Padding.only(left=14,right=8,top=4,bottom=4))
        self.menu_contrato=ft.PopupMenuButton(content=contrato_chip,tooltip="Selecionar contrato",items=[ft.PopupMenuItem(content=ft.Text(nome),on_click=lambda _, contrato=nome:self._trocar_contrato(contrato)) for nome in CONTRATOS_INTERNOS])
        usuario_chip=ft.Button(content=self.txt_usuario,icon=ft.Icons.SETTINGS,on_click=self._perfil,bgcolor="#14FFFFFF",color=WHITE,height=38,style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8),side=ft.BorderSide(1,"#24FFFFFF")))
        topo=ft.Container(bgcolor=NAVY,padding=ft.Padding.symmetric(horizontal=28,vertical=20),content=ft.Row([marca,ft.Container(expand=True),self.menu_contrato,usuario_chip]))
        self.arquivo=ft.Text("Nenhum arquivo selecionado",size=12,color=FIELD_TEXT,no_wrap=True,overflow=ft.TextOverflow.ELLIPSIS)
        self.arquivo_area=ft.Container(content=self.arquivo,expand=True,height=FIELD_HEIGHT,alignment=ft.Alignment.CENTER_LEFT,padding=ft.Padding.only(left=12,right=12))
        self.btn_arquivo=ft.Button(content="Selecionar",on_click=self._selecionar,width=ACTION_WIDTH,height=FIELD_HEIGHT,bgcolor="#F1F4F8",color=NAVY,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=0),side=ft.BorderSide(0,ft.Colors.TRANSPARENT),padding=0,elevation=0))
        self.arquivo_box=ft.Container(height=FIELD_HEIGHT,bgcolor=SURFACE,border=ft.Border.all(1,BORDER),border_radius=FIELD_RADIUS,clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            content=ft.Row([self.arquivo_area,ft.Container(width=1,height=FIELD_HEIGHT,bgcolor=BORDER),self.btn_arquivo],spacing=0,vertical_alignment=ft.CrossAxisAlignment.CENTER))
        self.referencia_valor=None
        self.txt_referencia=ft.Text("Selecione",size=12,color=FIELD_HINT,no_wrap=True,overflow=ft.TextOverflow.ELLIPSIS)
        referencia_conteudo=ft.Container(height=FIELD_HEIGHT,expand=True,padding=ft.Padding.only(left=12,right=10),alignment=ft.Alignment.CENTER,
            content=ft.Row([self.txt_referencia,ft.Container(expand=True),ft.Icon(ft.Icons.KEYBOARD_ARROW_DOWN,size=18,color="#465468")],vertical_alignment=ft.CrossAxisAlignment.CENTER,spacing=8))
        self.referencia=ft.PopupMenuButton(content=referencia_conteudo,items=[],expand=True,tooltip="Selecionar mês e ano")
        self.referencia_box=ft.Container(height=FIELD_HEIGHT,bgcolor=SURFACE,border=ft.Border.all(1,BORDER),border_radius=FIELD_RADIUS,clip_behavior=ft.ClipBehavior.ANTI_ALIAS,content=self.referencia)
        self.txt_razao=ft.Text("Selecione um ou mais",size=12,color=FIELD_HINT,no_wrap=True,overflow=ft.TextOverflow.ELLIPSIS)
        self.txt_codigo=ft.Text("Selecione um ou mais",size=12,color=FIELD_HINT,no_wrap=True,overflow=ft.TextOverflow.ELLIPSIS)
        def seletor(texto,acao):
            conteudo=ft.Row([ft.Container(content=texto,expand=True,height=FIELD_HEIGHT,padding=ft.Padding.only(left=12,right=8),alignment=ft.Alignment.CENTER_LEFT),ft.Container(width=1,height=FIELD_HEIGHT,bgcolor=BORDER),ft.Container(width=SELECT_ACTION_WIDTH,height=FIELD_HEIGHT,alignment=ft.Alignment.CENTER,bgcolor=FIELD_ACTION,content=ft.Icon(ft.Icons.KEYBOARD_ARROW_DOWN,size=18,color=NAVY))],spacing=0,vertical_alignment=ft.CrossAxisAlignment.CENTER)
            return ft.Container(height=FIELD_HEIGHT,bgcolor=SURFACE,border=ft.Border.all(1,BORDER),border_radius=FIELD_RADIUS,clip_behavior=ft.ClipBehavior.ANTI_ALIAS,content=conteudo,on_click=acao)
        self.btn_razao=seletor(self.txt_razao,lambda _:self._seletor("razao"));self.btn_codigo=seletor(self.txt_codigo,lambda _:self._seletor("codigo"))
        self.senha=self.campo(password=True,can_reveal_password=False,hint_text="Senha SGL",height=FIELD_HEIGHT,border=ft.InputBorder.NONE,bgcolor=ft.Colors.TRANSPARENT,expand=True,content_padding=ft.Padding.only(left=12,right=12,top=0,bottom=5))
        self.olho_senha=ft.IconButton(icon=ft.Icons.VISIBILITY,icon_size=19,icon_color="#465468",tooltip="Exibir senha",on_click=self._alternar_senha,width=SELECT_ACTION_WIDTH,height=FIELD_HEIGHT,padding=0)
        self.senha_box=ft.Container(height=FIELD_HEIGHT,bgcolor=SURFACE,border=ft.Border.all(1,BORDER),border_radius=FIELD_RADIUS,clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            content=ft.Row([self.senha,ft.Container(width=1,height=FIELD_HEIGHT,bgcolor=BORDER),ft.Container(width=SELECT_ACTION_WIDTH,height=FIELD_HEIGHT,alignment=ft.Alignment.CENTER,bgcolor=SURFACE,content=self.olho_senha)],spacing=0,vertical_alignment=ft.CrossAxisAlignment.CENTER))
        self.resumo=ft.Text("Razões: —    Códigos: —",size=10,color=SLATE,font_family="Consolas")
        self.resumo_base=ft.Text("Aguardando o concatenado",size=10,color=SLATE)
        filtros=self.card(ft.ResponsiveRow(spacing=16,controls=[
            ft.Column(col={"sm":12,"md":4},controls=[self.label("Concatenado atualizado"),self.arquivo_box],spacing=7),
            ft.Column(col={"sm":6,"md":2},controls=[self.label("Mês / ano"),self.referencia_box],spacing=7),
            ft.Column(col={"sm":6,"md":2},controls=[self.label("Razões"),self.btn_razao],spacing=7),
            ft.Column(col={"sm":6,"md":2},controls=[self.label("Códigos"),self.btn_codigo],spacing=7),
            ft.Container(col={"sm":6,"md":2},border=ft.Border.only(left=ft.BorderSide(1,BORDER)),padding=ft.Padding.only(left=16),content=ft.Column([self.label("Senha SGL"),self.senha_box],spacing=7,horizontal_alignment=ft.CrossAxisAlignment.STRETCH))]),padding=20)
        self.badge=ft.Text("AGUARDANDO",size=9,weight=ft.FontWeight.W_600,color=BRASS); self.status=ft.Text("Selecione o concatenado atualizado para começar.",size=13,color=INK)
        faixa=ft.Container(content=ft.Row([ft.Container(content=self.badge,bgcolor="#F4E9D8",border=ft.Border.all(1,"#E7D2AC"),border_radius=20,padding=ft.Padding.symmetric(horizontal=11,vertical=6)),self.status,ft.Container(expand=True),ft.Container(content=ft.Row([ft.Container(width=5,height=5,border_radius=3,bgcolor=NAVY),self.resumo_base],spacing=8),bgcolor=SURFACE,border=ft.Border.all(1,BORDER),border_radius=7,padding=ft.Padding.symmetric(horizontal=13,vertical=8))]),padding=ft.Padding.symmetric(vertical=2))
        self.valores={k:ft.Text("—",size=20,weight=ft.FontWeight.W_600,color=MUTED,font_family="Consolas") for k in ("Polo","UL","Razão","Código")}
        infos=ft.ResponsiveRow([ft.Column(col=6,controls=[self.label(k),v],spacing=8) for k,v in self.valores.items()],spacing=28,run_spacing=22)
        self.iniciar=self.botao("▶  Iniciar análise",self._iniciar,disabled=True)
        self.aprovar=ft.Button(content="✓  Foto coerente",on_click=lambda _:self._decidir("aprovar"),disabled=True,height=46,bgcolor="#E5F3EA",color=GREEN,style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8),side=ft.BorderSide(1,"#CBE6D4")))
        self.reprovar=ft.Button(content="✕  Foto reprovada",on_click=lambda _:self._decidir("reprovar"),disabled=True,height=46,bgcolor="#FBEAE9",color=RED,style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8),side=ft.BorderSide(1,"#F3D2D0")))
        self.timer=ft.Text(self._tempo(self.perfil.tempo_limite),size=23,color=INK,weight=ft.FontWeight.W_600,font_family="Consolas")
        self.timer_ring=ft.ProgressRing(value=1,width=132,height=132,stroke_width=8,color=BRASS,bgcolor="#EEE1CB")
        self.encerrar=self.botao("Encerrar análise",self._encerrar,True,True)
        analise_principal=ft.Column([ft.Container(content=infos,padding=ft.Padding.only(bottom=22)),ft.Container(height=1,bgcolor="#EBEDF1"),ft.Column([self.iniciar,ft.Row([self.aprovar,self.reprovar],spacing=10)],spacing=10)],spacing=18,expand=True)
        analise_lateral=ft.Container(border=ft.Border.only(left=ft.BorderSide(1,"#EBEDF1")),padding=ft.Padding.only(left=22),content=ft.Column([ft.Column([self.label("Tempo restante"),ft.Container(width=132,height=132,content=ft.Stack([self.timer_ring,ft.Container(content=self.timer,alignment=ft.Alignment.CENTER)]))],horizontal_alignment=ft.CrossAxisAlignment.CENTER,spacing=15),self.encerrar],alignment=ft.MainAxisAlignment.SPACE_BETWEEN,horizontal_alignment=ft.CrossAxisAlignment.STRETCH),height=280)
        registro=self.card(ft.ResponsiveRow([ft.Container(col={"sm":12,"md":8},content=analise_principal),ft.Container(col={"sm":12,"md":4},content=analise_lateral)],spacing=22),padding=24,expand=True)
        self.total_polos=ft.Text("0 / 0 concluídos",size=11,color=SLATE,font_family="Consolas"); self.polos=ft.ResponsiveRow(spacing=16,run_spacing=16)
        self.cobertura_vazia=ft.Container(content=ft.Text("A cobertura aparece aqui quando a análise for iniciada",size=11,color=MUTED),alignment=ft.Alignment.CENTER,padding=28,bgcolor=SURFACE,border=ft.Border.all(1,BORDER),border_radius=8)
        progresso=self.card(ft.Column([ft.Row([self.label("Cobertura por polo"),ft.Container(expand=True),self.total_polos]),self.cobertura_vazia,self.polos],spacing=16),padding=22,expand=True)
        centro=ft.ResponsiveRow([ft.Container(col={"sm":12,"lg":7},content=registro),ft.Container(col={"sm":12,"lg":5},content=progresso)],spacing=20,run_spacing=20)
        self.load_title=ft.Text("Processando…",size=16,weight=ft.FontWeight.BOLD); self.load_detail=ft.Text("Aguarde um momento.",size=11,color=MUTED)
        self.load_ring=ft.ProgressRing(value=None,width=24,height=24,color=NAVY,bgcolor="#E1E7EF",stroke_width=4);self.load_bar=ft.ProgressBar(value=None,color=BRASS,bgcolor="#EEE1CB",bar_height=4)
        self.loading=ft.Container(visible=False,expand=True,bgcolor="#990F172A",alignment=ft.Alignment.CENTER,content=ft.Container(width=460,height=188,bgcolor=WHITE,border_radius=14,padding=28,content=ft.Column([ft.Row([ft.Text("SGL",weight=ft.FontWeight.BOLD),ft.Container(expand=True),self.load_ring]),self.load_title,self.load_detail,self.load_bar],spacing=12,tight=True)))
        pagina=ft.Column([self.label("Configuração da análise"),filtros,faixa,centro,ft.Container(content=ft.Text("Desenvolvido por Delkzo One Technology",size=10,color=MUTED),alignment=ft.Alignment.CENTER,padding=16,border=ft.Border.only(top=ft.BorderSide(1,BORDER)))],expand=True,scroll=ft.ScrollMode.AUTO,spacing=18)
        self.page.add(ft.Stack([ft.Column([topo,ft.Container(content=pagina,padding=ft.Padding.only(left=28,right=28,top=24,bottom=40),expand=True)],expand=True,spacing=0),self.loading],expand=True))

    def _tempo(self,s): return f"{s//60:02d}:{s%60:02d}"
    def _tempo_estimado(self,segundos):
        segundos=max(0,int(segundos));return f"{segundos//60:02d}:{segundos%60:02d}"
    def _contador_leitura(self):
        while self.leitura_parar and not self.leitura_parar.is_set():
            estado=dict(self.leitura_estado);agora=time.perf_counter();decorrido=agora-estado.get("inicio",agora);processadas=int(estado.get("processadas",0));total=int(estado.get("total",0));fase=estado.get("fase","abrindo")
            if fase=="abrindo" or not total:
                detalhe=f"Abrindo e preparando o arquivo · tempo decorrido {self._tempo_estimado(decorrido)}"
            elif not processadas:
                detalhe=f"Leitura preparada: {total:,} linhas · calculando estimativa…".replace(",",".")
            else:
                inicio_leitura=estado.get("inicio_leitura",estado.get("inicio",agora));tempo_leitura=max(.01,agora-inicio_leitura);velocidade=processadas/tempo_leitura;restante=(total-processadas)/velocidade if velocidade else 0;percentual=min(100,processadas/total*100)
                detalhe=(f"{processadas:,} de {total:,} linhas · {percentual:.1f}% · restante estimado {self._tempo_estimado(restante)} · decorrido {self._tempo_estimado(decorrido)}").replace(",",".")
            fracao=max(.02,min(1,processadas/total)) if total else .02
            self._emitir("loading",{"titulo":"Processando concatenado…","detalhe":detalhe,"progresso":fracao})
            self.leitura_parar.wait(1)
    def _carregar_perfil(self):
        try:
            self.mapa_polos,polos=carregar_mapa_contrato(self.perfil.contrato); self.txt_contrato.value=self.perfil.contrato; self.txt_usuario.value=self.perfil.usuario_sgl or "Configurações"
            self.senha.value=carregar_senha(self.perfil.usuario_sgl)
            self.status.value=f"Perfil carregado · {len(self.mapa_polos):,} ULs em {len(polos)} polos".replace(",",".")
        except Exception as e:self.status.value=f"Revise o perfil: {e}"
        self.page.update()
    def _trocar_contrato(self,contrato):
        try:
            if self.registros and contrato!=self.contrato_detectado:
                return self._msg("Contrato definido pelo concatenado",f"O concatenado carregado pertence ao contrato {self.contrato_detectado}. Selecione outro arquivo para alterar o contrato.")
            mapa,polos=carregar_mapa_contrato(contrato);self.mapa_polos=mapa;self.perfil=Perfil(contrato,"",self.perfil.usuario_sgl,self.perfil.pasta_relatorios,self.perfil.tempo_limite,self.perfil.base_iwos);salvar_perfil(self.perfil);self.txt_contrato.value=contrato
            self.status.value=f"Contrato {contrato} selecionado · {len(mapa):,} ULs em {len(polos)} polos".replace(",",".");self.page.update()
        except Exception as e:self._msg("Contrato inválido",str(e))
    async def _selecionar(self,_):
        a=await ft.FilePicker().pick_files(dialog_title="Selecionar concatenado atualizado",file_type=ft.FilePickerFileType.CUSTOM,allowed_extensions=["xlsx"])
        if a:self.caminho=a[0].path; self.arquivo.value=a[0].name; self.arquivo.color=FIELD_TEXT; self._load("Processando concatenado…","Abrindo e preparando o arquivo.",.02); self._thread(self._ler,"concatenado")
    def _ler(self):
        inicio=time.perf_counter();self.leitura_estado={"inicio":inicio,"fase":"abrindo","processadas":0,"total":0};self.leitura_parar=threading.Event();self._thread(self._contador_leitura,"contador-leitura");resultado=None;erro=None
        try:
            def progresso(linhas,total,fase):
                if fase=="lendo" and self.leitura_estado.get("fase")!="lendo":self.leitura_estado["inicio_leitura"]=time.perf_counter()
                self.leitura_estado.update({"processadas":linhas,"total":total,"fase":fase})
            r,s,contrato,pontuacao,mapa,polos=carregar_concatenado_auto(self.caminho,progresso)
            colaboradores,linhas_iwos=carregar_base_iwos(self.perfil.base_iwos) if self.perfil.base_iwos else ({},[])
            identificados=0
            if colaboradores:
                enriquecidos=[]
                for registro in r:
                    pessoa=colaboradores.get(registro.matricula_leiturista.casefold())
                    if pessoa:
                        identificados+=1
                        registro=replace(registro,nome_leiturista=pessoa.nome,id_iwos=pessoa.id_iwos,
                            centro_iwos=pessoa.centro,funcao_iwos=pessoa.funcao,admissao_iwos=pessoa.admissao,
                            disponibilidade_iwos=pessoa.disponibilidade)
                    enriquecidos.append(registro)
                r=enriquecidos
            duracao=time.perf_counter()-inicio
            resultado={"registros":r,"resumo":s,"contrato":contrato,"pontuacao":pontuacao,"mapa":mapa,"polos":polos,"duracao":duracao,"linhas_iwos":linhas_iwos,"identificados_iwos":identificados}
        except Exception as e:erro=str(e)
        finally:self.leitura_parar.set()
        self._emitir("concatenado_ok",resultado) if resultado else self._emitir("concatenado_erro",{"mensagem":erro})
    def _aplicar(self,d):
        contrato=d.get("contrato",self.perfil.contrato);self.contrato_detectado=contrato;self.mapa_polos=d.get("mapa",self.mapa_polos)
        if contrato!=self.perfil.contrato:self.perfil=Perfil(contrato,"",self.perfil.usuario_sgl,self.perfil.pasta_relatorios,self.perfil.tempo_limite,self.perfil.base_iwos);salvar_perfil(self.perfil)
        self.txt_contrato.value=contrato;self.registros=d["registros"]; s=d["resumo"]; refs=sorted(s["referencias"],key=lambda x:(x[3:],x[:2]),reverse=True)
        self.referencia.items=[ft.PopupMenuItem(content=ft.Text(x),on_click=lambda _, valor=x:self._mudar_ref(valor)) for x in refs]
        self.referencia_valor=refs[0] if refs else None;self.txt_referencia.value=self.referencia_valor or "Selecione";self.txt_referencia.color=FIELD_TEXT if self.referencia_valor else FIELD_HINT; self.iniciar.disabled=False
        referencias=", ".join(refs); total=f"{int(s['total']):,}".replace(",",".")
        self.linhas_iwos=d.get("linhas_iwos",[]); identificados=int(d.get("identificados_iwos",0))
        acertos=d.get("pontuacao",{}).get(contrato,0);duracao=float(d.get("duracao",0));self.resumo_base.value=f"{total} registros · Referências: {referencias} · {s['uls_sem_polo']} ULs sem polo"; self.status.value=f"Contrato {contrato} identificado · {identificados:,} registros vinculados à IWOS · carregado em {duracao:.1f} s.".replace(",","."); self._opcoes()
    def _mudar_ref(self,valor):self.referencia_valor=str(valor);self.txt_referencia.value=self.referencia_valor;self.txt_referencia.color=FIELD_TEXT;self.sel_razoes.clear();self.sel_codigos.clear();self._opcoes();self.page.update()
    def _alternar_senha(self,_):
        self.senha.password=not self.senha.password
        self.olho_senha.icon=ft.Icons.VISIBILITY if self.senha.password else ft.Icons.VISIBILITY_OFF
        self.olho_senha.tooltip="Exibir senha" if self.senha.password else "Ocultar senha"
        self.senha_box.update()
    def _opcoes(self):
        if not self.registros or not self.referencia_valor:return
        self.razoes=[str(x) for x in opcoes_dependentes(self.registros,self.referencia_valor)["razoes"]]; self.sel_razoes&=set(self.razoes)
        rs=[int(x) for x in self.sel_razoes]; cs=opcoes_dependentes(self.registros,self.referencia_valor,razao=rs or None)["codigos"]
        self.codigos=filtrar_codigos_cemig([str(x) for x in cs]);self.sel_codigos&=set(self.codigos);self._resumir();self._preview()
    def _seletor(self,tipo):
        vals=self.razoes if tipo=="razao" else self.codigos; atuais=self.sel_razoes if tipo=="razao" else self.sel_codigos
        if not vals:return self._msg("Nenhuma opção disponível","Carregue o concatenado e confira os filtros anteriores.")
        temp=set(atuais)
        def mudar(e): temp.add(str(e.control.data)) if e.control.value else temp.discard(str(e.control.data))
        def aplicar(_): atuais.clear();atuais.update(temp);self.page.pop_dialog();self._opcoes() if tipo=="razao" else (self._resumir(),self._preview());self.page.update()
        self.page.show_dialog(ft.AlertDialog(modal=True,title=f"Selecionar {'razões de leitura' if tipo=='razao' else 'códigos CEMIG'}",content=ft.Container(width=420,height=430,content=ft.Column([ft.Checkbox(label=x,value=x in temp,data=x,on_change=mudar) for x in vals],scroll=ft.ScrollMode.AUTO)),actions=[self.botao("Cancelar",lambda _:self.page.pop_dialog(),True),self.botao("Aplicar seleção",aplicar)]))
    def _resumir(self):
        r="; ".join(sorted(self.sel_razoes,key=int)) or "—";c="; ".join(sorted(self.sel_codigos)) or "—";self.resumo.value=f"Razões: {r}    Códigos: {c}"
        self.txt_razao.value=r if self.sel_razoes else "Selecione um ou mais";self.txt_razao.color=FIELD_TEXT if self.sel_razoes else FIELD_HINT
        self.txt_codigo.value=c if self.sel_codigos else "Selecione um ou mais";self.txt_codigo.color=FIELD_TEXT if self.sel_codigos else FIELD_HINT;self.page.update()
    def _preview(self):
        if not(self.registros and self.referencia_valor and self.sel_razoes and self.sel_codigos):return
        xs=filtrar_registros(self.registros,self.referencia_valor,[int(x) for x in self.sel_razoes],self.sel_codigos);c={}
        for r in xs:
            if r.polo!="NÃO IDENTIFICADO":c[r.polo]=c.get(r.polo,0)+1
        self._progresso({"progresso":{p:0 for p in sorted(c)},"consultadas":{p:0 for p in c},"restantes":c})

    def _perfil(self,_):
        contrato=ft.Dropdown(value=self.perfil.contrato,options=[ft.DropdownOption(key=x,text=x) for x in CONTRATOS_INTERNOS],label="Contrato",disabled=bool(self.contrato_detectado));usuario=self.campo(value=self.perfil.usuario_sgl,label="Usuário SGL");pasta=self.campo(value=self.perfil.pasta_relatorios,label="Pasta dos relatórios",read_only=True,expand=True);base_iwos=self.campo(value=self.perfil.base_iwos,label="Planilha auxiliar com IWOS",read_only=True,expand=True);tempo=self.campo(value=str(self.perfil.tempo_limite),label="Tempo por instalação (segundos)")
        async def escolher(_):
            x=await ft.FilePicker().get_directory_path(dialog_title="Selecionar pasta dos relatórios")
            if x:pasta.value=x;pasta.update()
        async def escolher_iwos(_):
            x=await ft.FilePicker().pick_files(dialog_title="Selecionar planilha auxiliar com IWOS",file_type=ft.FilePickerFileType.CUSTOM,allowed_extensions=["xlsx"])
            if x:base_iwos.value=x[0].path;base_iwos.update()
        def salvar(_):
            try:
                limite=int(tempo.value)
                if not 15<=limite<=300:raise ValueError("O tempo deve ficar entre 15 e 300 segundos.")
                if not contrato.value or not usuario.value.strip() or not pasta.value.strip():raise ValueError("Preencha o contrato, o usuário SGL e a pasta dos relatórios.")
                if base_iwos.value.strip():carregar_base_iwos(base_iwos.value.strip())
                if self.contrato_detectado and contrato.value!=self.contrato_detectado:raise ValueError(f"O concatenado carregado pertence ao contrato {self.contrato_detectado}. Para mudar o contrato, carregue o arquivo correspondente.")
                contrato_efetivo=self.contrato_detectado or contrato.value;mapa,polos=carregar_mapa_contrato(contrato_efetivo);self.perfil=Perfil(contrato_efetivo,"",usuario.value.strip(),pasta.value.strip(),limite,base_iwos.value.strip());salvar_perfil(self.perfil);self.mapa_polos=mapa
                self.txt_contrato.value=contrato_efetivo;self.txt_usuario.value=usuario.value.strip();self.senha.value=carregar_senha(usuario.value.strip());self.timer.value=self._tempo(limite);self.timer_ring.value=1;self.status.value="Configurações salvas. As alterações já estão em vigor.";self.page.pop_dialog();self.page.update()
            except Exception as e:self._msg("Configurações inválidas",str(e))
        aviso=ft.Text(f"Contrato identificado pelo concatenado: {self.contrato_detectado}." if self.contrato_detectado else "O contrato será confirmado automaticamente ao carregar o concatenado.",size=10,color=BRASS if self.contrato_detectado else MUTED)
        self.page.show_dialog(ft.AlertDialog(modal=True,title="Perfil e configurações fixas",content=ft.Container(width=680,content=ft.Column([ft.Text("Preencha uma vez e altere somente quando houver mudança operacional.",color=MUTED),contrato,aviso,usuario,ft.Row([pasta,self.botao("Selecionar pasta",escolher,True)]),ft.Row([base_iwos,self.botao("Selecionar IWOS",escolher_iwos,True)]),ft.Text("A planilha será relida a cada importação do concatenado.",size=10,color=MUTED),tempo],spacing=14)),actions=[self.botao("Cancelar",lambda _:self.page.pop_dialog(),True),self.botao("Salvar alterações",salvar)]))
    def _iniciar(self,_):
        try:
            if not self.registros:raise ValueError("Carregue o concatenado atualizado.")
            if not self.sel_razoes:raise ValueError("Selecione pelo menos uma razão de leitura.")
            if not self.sel_codigos:raise ValueError("Selecione pelo menos um código CEMIG.")
            if not self.senha.value:raise ValueError("Informe a senha do SGL para iniciar.")
            salvar_senha(self.perfil.usuario_sgl,self.senha.value)
            xs=[r for r in filtrar_registros(self.registros,self.referencia_valor,[int(x) for x in self.sel_razoes],self.sel_codigos) if r.polo!="NÃO IDENTIFICADO"]
            if not xs:raise ValueError("Nenhuma instalação corresponde aos filtros selecionados.")
            conf=ConfiguracaoSessao(self.perfil.contrato,self.referencia_valor,tuple(sorted(int(x) for x in self.sel_razoes)),tuple(sorted(self.sel_codigos)),self.perfil.tempo_limite)
            self.sessao=SessaoAnalise(xs,conf,GerenciadorRelatorios(self.perfil.pasta_relatorios,self.referencia_valor,self.linhas_iwos),self.perfil.usuario_sgl,self.senha.value,self._emitir);self._bloquear(True);self.iniciar.disabled=True;self.encerrar.disabled=False;self._load("Conectando ao SGL…","Confirme o certificado no navegador, se solicitado.");self._thread(self.sessao.executar,"sessao")
        except Exception as e:self._msg("Não foi possível iniciar a análise",str(e))
    def _bloquear(self,v):
        for x in(self.btn_arquivo,self.referencia,self.btn_razao,self.btn_codigo,self.senha,self.olho_senha,self.menu_contrato):x.disabled=v
        self.page.update()
    def _decidir(self,d):
        if self.sessao:self._decisao(False);self.sessao.decidir(d)
    def _encerrar(self,_):
        if self.sessao:self.sessao.solicitar_parada();self.status.value="Encerrando a análise e salvando os resultados…";self.page.update()
    def _emitir(self,t,d):self.fila.put((t,d))
    async def _eventos(self):
        while not self.fechada:
            atualizou=False
            try:
                # Selenium, Excel e relatórios publicam apenas dados na fila.
                # Os controles Flet são modificados exclusivamente neste loop,
                # que pertence à thread da interface. Isso evita congelamentos
                # e atualizações que só apareciam depois de trocar o foco.
                for _ in range(50):
                    try:t,d=self.fila.get_nowait()
                    except queue.Empty:break
                    self._tratar(t,d);atualizou=True
                if atualizou:self.page.update()
            except Exception:
                self._hide();diagnostico(traceback.format_exc())
                try:self.page.update()
                except Exception:pass
            await asyncio.sleep(.05)
    def _tratar(self,t,d):
        if t=="concatenado_ok":self._hide();self._aplicar(d)
        elif t=="concatenado_erro":self._hide();self._msg("Não foi possível carregar o concatenado",str(d["mensagem"]))
        elif t=="loading":self._load(str(d["titulo"]),str(d.get("detalhe","")),d.get("progresso"),False)
        elif t=="status":self.status.value=str(d["texto"]);self.load_detail.value=str(d["texto"]) if self.loading.visible else self.load_detail.value
        elif t=="consulta":self._load("Buscando evidências…",f"Consultando a instalação {d['registro'].instalacao} no SGL.");self.badge.value="BUSCANDO FOTOS";self.badge.color=AMBER;self.status.value=f"Buscando fotos da instalação {d['registro'].instalacao}…";self._registro(d["registro"]);self._progresso(d);self._decisao(False)
        elif t=="avaliar":self._hide();self.badge.value=f"FOTO {d['foto']} DE {d['total']}";self.badge.color=SLATE;self.status.value=f"Confira se a foto corresponde ao código {d['registro'].codigo}.";self._registro(d["registro"]);self._decisao(True)
        elif t=="cronometro":r=int(d["restante"]);self.timer.value=self._tempo(r);self.timer.color=RED if r<=10 else INK;self.timer_ring.value=max(0,min(1,r/max(1,self.perfil.tempo_limite)))
        elif t in("resultado","progresso_polos"):
            if t=="resultado":self._hide();self._decisao(False)
            self._progresso(d)
        elif t in("fim","erro_fatal"):
            self._hide();self._decisao(False);self._bloquear(False);self.encerrar.disabled=True;self.iniciar.disabled=False
            if t=="fim":self.badge.value="ANÁLISE CONCLUÍDA";self.badge.color=GREEN;self.status.value=str(d["motivo"]);self._msg("Análise concluída",str(d["motivo"]))
            else:self.badge.value="ATENÇÃO NECESSÁRIA";self.badge.color=RED;self._msg("Não foi possível continuar",f"{d['mensagem']}\nDiagnóstico: {diagnostico(str(d.get('detalhes',d['mensagem'])))}")
    def _registro(self,r):
        for k,v in zip(self.valores,(r.polo.title(),r.ul,str(r.razao),str(r.codigo))):self.valores[k].value=v
    def _progresso(self,d):
        p=d.get("progresso",{});c=d.get("consultadas",{});rest=d.get("restantes",{})
        if not p:return
        self.total_polos.value=f"{sum(int(x)>=20 for x in p.values())} / {len(p)} concluídos";cards=[];self.cobertura_vazia.visible=False
        for polo,n in p.items():
            n=int(n);ver=int(c.get(polo,0));total=ver+int(rest.get(polo,0));estado="META ALCANÇADA" if n>=20 else("EM ANÁLISE" if ver else "NÃO INICIADO")
            cards.append(ft.Container(col={"sm":12,"md":6,"lg":6},bgcolor=SURFACE,padding=14,border=ft.Border.all(1,BORDER),border_radius=8,content=ft.Column([ft.Row([ft.Text(str(polo).title(),size=12,weight=ft.FontWeight.W_600),ft.Container(expand=True),ft.Text(f"{n} / 20",size=10,color=SLATE,font_family="Consolas")]),ft.ProgressBar(value=min(n/20,1),color=BRASS,bgcolor="#EBEDF1",bar_height=6,border_radius=4),ft.Text(f"{ver} / {total} ULs verificadas · {estado.lower()}",size=9,color=MUTED,font_family="Consolas")],spacing=8)))
        self.polos.controls=cards
    def _decisao(self,v):self.aprovar.disabled=not v;self.reprovar.disabled=not v;self.page.update()
    def _load(self,t,d,progresso=None,atualizar=True):
        self.load_title.value=t;self.load_detail.value=d;self.load_ring.value=progresso;self.load_bar.value=progresso;self.loading.visible=True
        if atualizar:self.page.update()
    def _hide(self):self.loading.visible=False
    def _msg(self,t,s):self.page.show_dialog(ft.AlertDialog(modal=True,title=t,content=ft.Text(s,selectable=True),actions=[self.botao("Fechar",lambda _:self.page.pop_dialog())]))
    def _fechar(self,_):self.fechada=True;self.sessao.solicitar_parada() if self.sessao else None

def executar():
    try:ft.run(lambda page:App(page))
    except Exception:
        detalhes=traceback.format_exc();diagnostico(detalhes)
        if "CERTIFICATE_VERIFY_FAILED" in detalhes:
            print("\nNao foi possivel validar o certificado HTTPS usado para preparar o Flet.")
            print("A cadeia do certifi e os certificados confiaveis do Windows ja foram aplicados.")
            print("Se o erro continuar, solicite ao suporte de TI a instalacao do certificado raiz da rede no Windows.")
            raise SystemExit(2)
        raise
