from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


URL_SGL = "https://sglempreiteira.cemig.com.br/"


@dataclass(slots=True)
class ResultadoConsulta:
    possui_foto: bool
    links_fotos: list[object]
    mensagem: str = ""


class AutomacaoSGL:
    def __init__(self, status: Callable[[str], None], timeout: int = 20) -> None:
        self.status = status
        self.timeout = timeout
        self.driver: webdriver.Chrome | None = None
        self._ultima_instalacao = ""
        self._ultima_referencia = ""
        self._resultado_precisa_restaurar = False
        self._usuario = ""
        self._senha = ""

    def abrir(self, usuario: str, senha: str) -> None:
        self._usuario = usuario
        self._senha = senha
        opcoes = webdriver.ChromeOptions()
        opcoes.add_argument("--start-maximized")
        opcoes.add_argument("--log-level=3")
        opcoes.add_argument("--disable-logging")
        opcoes.add_argument("--disable-background-networking")
        opcoes.add_argument("--disable-component-update")
        opcoes.add_argument("--disable-notifications")
        opcoes.add_experimental_option("excludeSwitches", ["enable-logging", "enable-automation"])
        opcoes.add_experimental_option("detach", False)
        self.driver = webdriver.Chrome(options=opcoes)
        self.status("Confirme o certificado no navegador, caso solicitado.")
        self.driver.get(URL_SGL)
        espera_certificado = WebDriverWait(self.driver, 120)
        campo_usuario = espera_certificado.until(
            EC.presence_of_element_located((By.ID, "UserName"))
        )
        campo_senha = self.driver.find_element(By.ID, "Password")
        campo_usuario.clear()
        campo_usuario.send_keys(usuario)
        campo_senha.clear()
        campo_senha.send_keys(senha)
        self.driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
        espera = WebDriverWait(self.driver, self.timeout)
        espera.until(EC.element_to_be_clickable((By.XPATH, "//span[contains(normalize-space(),'CONSULTA')]"))).click()
        espera.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(normalize-space(),'Consulta Foto')]"))).click()
        espera.until(EC.presence_of_element_located((By.ID, "instalacao")))
        self.status("SGL pronto para consulta.")

    def reiniciar(self, motivo: str = "") -> None:
        """Restaura navegador, autenticação e rota após intervenção externa."""
        if not self._usuario or not self._senha:
            raise RuntimeError("Não há credenciais em memória para restaurar o SGL.")
        detalhe = f" ({motivo})" if motivo else ""
        self.status(f"Restaurando a sessão do SGL{detalhe}.")
        self.fechar()
        self.abrir(self._usuario, self._senha)

    def navegador_disponivel(self) -> bool:
        if not self.driver:
            return False
        try:
            return bool(self.driver.window_handles)
        except WebDriverException:
            return False

    def garantir_consulta(self) -> None:
        if not self.navegador_disponivel():
            self.reiniciar("navegador ou aba fechada")
            return
        try:
            if not self.driver.find_elements(By.ID, "instalacao"):
                self.reiniciar("página alterada fora da aplicação")
        except WebDriverException:
            self.reiniciar("navegador indisponível")

    def consultar(self, instalacao: str, referencia: str) -> ResultadoConsulta:
        self.garantir_consulta()
        driver = self.driver
        self._ultima_instalacao = instalacao
        self._ultima_referencia = referencia
        self._resultado_precisa_restaurar = False
        # Garante que nenhum visualizador residual bloqueie os campos.
        overlays = driver.find_elements(
            By.CSS_SELECTOR,
            ".modal.show, [role='dialog'], .fancybox-container, .mfp-wrap, .lightbox, .ekko-lightbox",
        )
        if any(elemento.is_displayed() for elemento in overlays):
            self.fechar_foto()
        espera = WebDriverWait(driver, self.timeout)
        campo_in = espera.until(EC.presence_of_element_located((By.ID, "instalacao")))
        campo_data = driver.find_element(By.ID, "data")

        for campo, valor in ((campo_in, instalacao), (campo_data, referencia)):
            campo.click()
            campo.send_keys(Keys.CONTROL, "a")
            campo.send_keys(Keys.DELETE)
            campo.send_keys(valor)

        resultados_anteriores = driver.find_elements(
            By.XPATH, "//div[h2[contains(normalize-space(),'Resultado')]]"
        )
        resultado_anterior = resultados_anteriores[0] if resultados_anteriores else None
        driver.find_element(By.ID, "btnVisualizar").click()

        try:
            if resultado_anterior is not None:
                # O SGL normalmente substitui todo o container a cada resposta.
                # Uma espera curta evita interpretar o resultado anterior como o novo.
                WebDriverWait(driver, min(self.timeout, 8)).until(
                    EC.staleness_of(resultado_anterior)
                )
            resultado = espera.until(
                EC.presence_of_element_located((By.XPATH, "//div[h2[contains(normalize-space(),'Resultado')]]"))
            )
            espera.until(lambda _: instalacao in resultado.text or "Nenhum resultado encontrado" in resultado.text)
        except TimeoutException as exc:
            # Alguns builds do SGL atualizam o mesmo nó em vez de substituí-lo.
            # Nesse caso, faz uma última leitura segura do conteúdo corrente.
            atuais = driver.find_elements(By.XPATH, "//div[h2[contains(normalize-space(),'Resultado')]]")
            if not atuais:
                raise TimeoutError("O resultado da consulta não carregou no tempo esperado.") from exc
            resultado = atuais[0]
            texto_atual = resultado.text
            if instalacao not in texto_atual and "Nenhum resultado encontrado" not in texto_atual:
                raise TimeoutError("O resultado da consulta não carregou no tempo esperado.") from exc

        texto = resultado.text.strip()
        if "Nenhum resultado encontrado" in texto or not texto:
            self._resultado_precisa_restaurar = False
            return ResultadoConsulta(False, [], "Nenhum resultado encontrado.")

        links = resultado.find_elements(By.XPATH, ".//a[contains(normalize-space(),'Visualizar a foto')] | .//button[contains(normalize-space(),'Visualizar a foto')]")
        self._resultado_precisa_restaurar = False
        return ResultadoConsulta(bool(links), links, "" if links else "Resultado sem link de foto.")

    def abrir_foto(self, indice: int, total_esperado: int) -> None:
        self.garantir_consulta()
        if self._resultado_precisa_restaurar:
            recuperada = self.consultar(self._ultima_instalacao, self._ultima_referencia)
            if not recuperada.possui_foto:
                raise RuntimeError("Não foi possível restaurar as fotos da instalação.")
            self._resultado_precisa_restaurar = False
        resultados = self.driver.find_elements(By.XPATH, "//div[h2[contains(normalize-space(),'Resultado')]]")
        if not resultados and self._ultima_instalacao:
            recuperada = self.consultar(self._ultima_instalacao, self._ultima_referencia)
            if not recuperada.possui_foto:
                raise RuntimeError("Não foi possível restaurar as fotos da instalação.")
            resultados = self.driver.find_elements(By.XPATH, "//div[h2[contains(normalize-space(),'Resultado')]]")
        if not resultados:
            raise RuntimeError("O resultado com as fotos não está mais disponível.")
        resultado = resultados[0]
        links = resultado.find_elements(By.XPATH, ".//a[contains(normalize-space(),'Visualizar a foto')] | .//button[contains(normalize-space(),'Visualizar a foto')]")
        if len(links) != total_esperado:
            raise RuntimeError("A lista de fotos mudou durante a avaliação.")
        self.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", links[indice])
        self.driver.execute_script("arguments[0].click();", links[indice])
        time.sleep(0.4)

    def fechar_foto(self) -> None:
        if not self.navegador_disponivel():
            self.reiniciar("navegador fechado durante a análise")
            self._resultado_precisa_restaurar = True
            return
        driver = self.driver

        # Primeiro reproduz o clique manual diretamente no elemento localizado
        # no centro da tela, onde o SGL exibe a fotografia.
        try:
            driver.execute_script(
                """
                const alvo = document.elementFromPoint(
                    Math.floor(window.innerWidth / 2),
                    Math.floor(window.innerHeight / 2)
                );
                if (alvo) {
                    alvo.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, view:window}));
                    alvo.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, view:window}));
                    alvo.dispatchEvent(new MouseEvent('click', {bubbles:true, cancelable:true, view:window}));
                }
                """
            )
            time.sleep(0.25)
        except WebDriverException:
            pass

        # Tenta também a maior imagem visível, mas não usa esse elemento para
        # decidir se o modal fechou: essa verificação gerava falsos positivos.
        imagem = driver.execute_script(
            """
            const imagens = [...document.querySelectorAll('img')].filter(img => {
                const r = img.getBoundingClientRect();
                const s = getComputedStyle(img);
                return r.width >= 250 && r.height >= 250 &&
                       s.display !== 'none' && s.visibility !== 'hidden' &&
                       r.bottom > 0 && r.right > 0;
            });
            const emModal = imagens.filter(img => img.closest(
                '.modal, [role="dialog"], .fancybox-container, .mfp-wrap, .lightbox, .ekko-lightbox'
            ));
            const candidatas = emModal.length ? emModal : imagens;
            candidatas.sort((a, b) => {
                const ra = a.getBoundingClientRect();
                const rb = b.getBoundingClientRect();
                return (rb.width * rb.height) - (ra.width * ra.height);
            });
            return candidatas[0] || null;
            """
        )
        if imagem is not None:
            try:
                driver.execute_script("arguments[0].click();", imagem)
                time.sleep(0.2)
            except WebDriverException:
                pass

        # Alternativas defensivas para versões do visualizador que exibam um
        # botão de fechar ou aceitem Escape.
        seletores_fechar = (
            "button.close, .modal button[data-dismiss='modal'], "
            ".modal button[data-bs-dismiss='modal'], .mfp-close, "
            ".fancybox-close, .fancybox-button--close"
        )
        for botao in driver.find_elements(By.CSS_SELECTOR, seletores_fechar):
            if botao.is_displayed():
                driver.execute_script("arguments[0].click();", botao)
                time.sleep(0.2)
                break

        try:
            driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
        except WebDriverException:
            driver.execute_script("document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true}));")
        # Fechamento determinístico: a página de consulta é recarregada após
        # toda decisão. Isso elimina o overlay mesmo quando o plugin de imagem
        # não expõe estado, classe ou evento de fechamento confiável.
        self.status("Fechando a foto e restaurando a consulta.")
        try:
            driver.refresh()
            WebDriverWait(driver, self.timeout).until(
                EC.element_to_be_clickable((By.ID, "instalacao"))
            )
            WebDriverWait(driver, self.timeout).until(
                EC.presence_of_element_located((By.ID, "data"))
            )
        except (TimeoutException, WebDriverException):
            self.reiniciar("estado da página modificado durante o fechamento")
        self._resultado_precisa_restaurar = True

    def fechar(self) -> None:
        if self.driver:
            try:
                self.driver.quit()
            except WebDriverException:
                pass
            self.driver = None
