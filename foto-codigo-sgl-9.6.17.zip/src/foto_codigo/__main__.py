from .tls import configurar_certificados

configurar_certificados()

from .app import executar


if __name__ == "__main__":
    executar()
