from __future__ import annotations

import queue
import random
import threading
import time
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Callable

from .browser import AutomacaoSGL
from .models import RegistroBase, ResultadoAnalise, StatusAnalise
from .reports import GerenciadorRelatorios

META_POR_POLO = 20


@dataclass(slots=True)
class ConfiguracaoSessao:
    contrato: str
    referencia: str
    razoes: tuple[int, ...]
    codigos: tuple[str, ...]
    tempo_limite: int = 60


class SessaoAnalise:
    def __init__(self, registros: list[RegistroBase], configuracao: ConfiguracaoSessao,
                 relatorios: GerenciadorRelatorios, usuario: str, senha: str,
                 emitir: Callable[[str, dict[str, object]], None]) -> None:
        self.registros = list(registros)
        self.config = configuracao
        self.relatorios = relatorios
        self.usuario = usuario
        self.senha = senha
        self.emitir = emitir
        self.decisoes: queue.Queue[str] = queue.Queue()
        self.parar = threading.Event()
        self.automacao = AutomacaoSGL(lambda texto: self.emitir("status", {"texto": texto}))

    def decidir(self, decisao: str) -> None:
        self.decisoes.put(decisao)

    def solicitar_parada(self) -> None:
        self.parar.set()
        self.decisoes.put("encerrar")

    def _montar_filas(self, processadas: set[str]) -> dict[str, deque[RegistroBase]]:
        grupos: dict[str, list[RegistroBase]] = defaultdict(list)
        for registro in self.registros:
            if registro.instalacao not in processadas and registro.polo != "NÃO IDENTIFICADO":
                grupos[registro.polo].append(registro)
        aleatorio = random.SystemRandom()
        for candidatos in grupos.values():
            aleatorio.shuffle(candidatos)
        return {polo: deque(candidatos) for polo, candidatos in sorted(grupos.items())}

    def executar(self) -> None:
        consultadas: dict[str, int] = defaultdict(int)
        try:
            processadas = self.relatorios.processadas(
                self.config.contrato, self.config.referencia, self.config.razoes, self.config.codigos
            )
            aprovadas = defaultdict(int, self.relatorios.aprovadas_por_polo(
                self.config.contrato, self.config.referencia, self.config.razoes, self.config.codigos
            ))
            filas = self._montar_filas(processadas)
            polos = sorted({r.polo for r in self.registros if r.polo != "NÃO IDENTIFICADO"})
            for polo in polos:
                aprovadas[polo] = min(aprovadas[polo], META_POR_POLO)
            self.emitir("progresso_polos", self._painel(polos, aprovadas, filas, consultadas))
            if not polos:
                raise ValueError("Nenhum polo identificado para os filtros selecionados.")
            if all(aprovadas[p] >= META_POR_POLO for p in polos):
                self.emitir("loading", {"titulo": "Finalizando a análise…", "detalhe": "Atualizando os arquivos de resultado."})
                try:
                    self.relatorios.finalizar()
                except (PermissionError, OSError):
                    self.emitir("status", {"texto": "O relatório está aberto; a sessão será concluída sem reformatá-lo."})
                self.emitir("fim", {"progresso": dict(aprovadas), "motivo": "Todos os polos já possuem 20 aprovações."})
                return

            self.automacao.abrir(self.usuario, self.senha)
            while not self.parar.is_set():
                pendentes = [p for p in polos if aprovadas[p] < META_POR_POLO and filas.get(p)]
                if not pendentes:
                    break
                # Uma consulta por polo a cada rodada evita sequência por polo.
                for polo in pendentes:
                    if self.parar.is_set():
                        break
                    if aprovadas[polo] >= META_POR_POLO or not filas[polo]:
                        continue
                    registro = filas[polo].popleft()
                    consultadas[polo] += 1
                    self.emitir("consulta", {"registro": registro, **self._painel(polos, aprovadas, filas, consultadas)})
                    inicio = time.monotonic()
                    try:
                        consulta = self._consultar_com_recuperacao(registro)
                        if not consulta.possui_foto:
                            resultado = ResultadoAnalise(self.config.contrato, registro, StatusAnalise.SEM_FOTO, observacao=consulta.mensagem)
                        else:
                            resultado = self._avaliar(registro, len(consulta.links_fotos), inicio)
                    except Exception as exc:
                        resultado = ResultadoAnalise(
                            self.config.contrato, registro, StatusAnalise.ERRO,
                            duracao_segundos=int(time.monotonic() - inicio), observacao=str(exc),
                        )
                    gravado = self.relatorios.registrar_com_respaldo(resultado)
                    if not gravado:
                        self.emitir("status", {
                            "texto": "Relatório aberto ou bloqueado. Resultado preservado no arquivo de respaldo."
                        })
                    if resultado.status == StatusAnalise.APROVADA:
                        aprovadas[polo] += 1
                    painel = self._painel(polos, aprovadas, filas, consultadas)
                    self.relatorios.salvar_estado({
                        "meta_por_polo": META_POR_POLO, "aprovadas": dict(aprovadas),
                        "consultadas": dict(consultadas), "ultima_instalacao": registro.instalacao,
                    })
                    self.emitir("resultado", {"resultado": resultado, **painel})

            self.emitir("loading", {"titulo": "Finalizando a análise…", "detalhe": "Atualizando o relatório de aprovadas e o registro técnico."})
            try:
                self.relatorios.finalizar()
            except (PermissionError, OSError):
                self.emitir("status", {
                    "texto": "Não foi possível formatar o relatório porque ele está aberto. Os dados já foram preservados."
                })
            completas = [p for p in polos if aprovadas[p] >= META_POR_POLO]
            esgotadas = [p for p in polos if aprovadas[p] < META_POR_POLO and not filas.get(p)]
            if len(completas) == len(polos):
                motivo = "Meta de 20 aprovações alcançada em todos os polos."
            elif self.parar.is_set():
                motivo = "Análise encerrada pelo usuário. O progresso foi salvo."
            else:
                motivo = "Todas as instalações elegíveis dos polos pendentes foram consultadas."
            self.emitir("fim", {"progresso": dict(aprovadas), "completas": completas, "esgotadas": esgotadas, "motivo": motivo})
        except Exception as exc:
            self.emitir("erro_fatal", {"mensagem": str(exc), "detalhes": traceback.format_exc()})
        finally:
            self.automacao.fechar()

    def _consultar_com_recuperacao(self, registro: RegistroBase):
        try:
            return self.automacao.consultar(registro.instalacao, registro.referencia)
        except Exception as primeira_falha:
            if self.parar.is_set():
                raise
            self.emitir("status", {
                "texto": "A página do SGL foi alterada ou perdeu resposta. Restaurando e repetindo a consulta uma vez."
            })
            self.automacao.reiniciar(str(primeira_falha)[:120])
            return self.automacao.consultar(registro.instalacao, registro.referencia)

    @staticmethod
    def _painel(polos, aprovadas, filas, consultadas) -> dict[str, object]:
        return {
            "progresso": {p: int(aprovadas[p]) for p in polos},
            "restantes": {p: len(filas.get(p, ())) for p in polos},
            "consultadas": {p: int(consultadas[p]) for p in polos},
            "meta_por_polo": META_POR_POLO,
        }

    def _avaliar(self, registro: RegistroBase, total: int, inicio: float) -> ResultadoAnalise:
        verificadas = 0
        for indice in range(total):
            if self.parar.is_set():
                return ResultadoAnalise(self.config.contrato, registro, StatusAnalise.INTERROMPIDA, total_fotos=total, fotos_verificadas=verificadas, duracao_segundos=int(time.monotonic() - inicio))
            try:
                self.automacao.abrir_foto(indice, total)
            except Exception as primeira_falha:
                if self.parar.is_set():
                    raise
                self.emitir("status", {
                    "texto": "A foto ou a página foi alterada fora da aplicação. Restaurando a consulta."
                })
                self.automacao.reiniciar(str(primeira_falha)[:120])
                recuperada = self.automacao.consultar(registro.instalacao, registro.referencia)
                if not recuperada.possui_foto or len(recuperada.links_fotos) != total:
                    raise RuntimeError("Não foi possível recuperar a mesma lista de fotos.")
                self.automacao.abrir_foto(indice, total)
            restante = max(0, self.config.tempo_limite - int(time.monotonic() - inicio))
            self.emitir("avaliar", {"registro": registro, "foto": indice + 1, "total": total, "restante": restante})
            decisao = self._aguardar_decisao(inicio)
            try:
                self.automacao.fechar_foto()
            except Exception as exc:
                # Não deixa o modal aberto contaminar silenciosamente todas as
                # consultas seguintes. Registra a instalação para verificação.
                return ResultadoAnalise(
                    self.config.contrato, registro, StatusAnalise.ERRO,
                    total_fotos=total, fotos_verificadas=verificadas,
                    duracao_segundos=int(time.monotonic() - inicio),
                    observacao=f"Falha ao fechar a foto automaticamente: {exc}",
                )
            if decisao == "reprovar":
                return ResultadoAnalise(self.config.contrato, registro, StatusAnalise.REPROVADA, total_fotos=total, fotos_verificadas=verificadas + 1, foto_reprovada=indice + 1, duracao_segundos=int(time.monotonic() - inicio), observacao="Foto incompatível")
            if decisao in ("tempo", "pular"):
                observacao = f"Tempo de verificação esgotado após {self.config.tempo_limite} segundos" if decisao == "tempo" else "Verificação adiada pelo usuário"
                return ResultadoAnalise(self.config.contrato, registro, StatusAnalise.VERIFICACAO, total_fotos=total, fotos_verificadas=verificadas, duracao_segundos=int(time.monotonic() - inicio), observacao=observacao)
            if decisao == "encerrar":
                self.parar.set()
                return ResultadoAnalise(self.config.contrato, registro, StatusAnalise.INTERROMPIDA, total_fotos=total, fotos_verificadas=verificadas, duracao_segundos=int(time.monotonic() - inicio))
            verificadas += 1
        return ResultadoAnalise(self.config.contrato, registro, StatusAnalise.APROVADA, total_fotos=total, fotos_verificadas=verificadas, duracao_segundos=int(time.monotonic() - inicio))

    def _aguardar_decisao(self, inicio: float) -> str:
        while not self.parar.is_set():
            restante = self.config.tempo_limite - int(time.monotonic() - inicio)
            if restante <= 0:
                return "tempo"
            self.emitir("cronometro", {"restante": restante})
            try:
                return self.decisoes.get(timeout=1)
            except queue.Empty:
                continue
        return "encerrar"
