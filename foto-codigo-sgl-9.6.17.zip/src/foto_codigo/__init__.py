"""Validador de fotos e códigos do SGL."""

__version__ = "9.6.17"
