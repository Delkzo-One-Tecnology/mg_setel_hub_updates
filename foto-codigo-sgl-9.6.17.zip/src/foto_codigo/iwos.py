from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

from openpyxl import load_workbook

from .data import normalizar_identificador


@dataclass(frozen=True, slots=True)
class ColaboradorIWOS:
    matricula: str
    nome: str
    id_iwos: str = ""
    centro: str = ""
    funcao: str = ""
    admissao: str = ""
    disponibilidade: str = ""


def _data(valor: object) -> str:
    if isinstance(valor, (date, datetime)):
        return valor.strftime("%d/%m/%Y")
    return str(valor or "").strip()


def carregar_base_iwos(caminho: str | Path) -> tuple[dict[str, ColaboradorIWOS], list[list[object]]]:
    """Lê a planilha auxiliar e relaciona matrícula operacional, MATRÍCULAS e IWOS."""
    if not caminho:
        return {}, []
    arquivo = Path(caminho)
    if not arquivo.exists():
        raise FileNotFoundError(f"A base IWOS não foi encontrada: {arquivo}")
    wb = load_workbook(arquivo, read_only=True, data_only=True, keep_links=False)
    try:
        if "IWOS" not in wb.sheetnames or "MATRÍCULAS" not in wb.sheetnames:
            raise ValueError("A planilha auxiliar precisa conter as abas IWOS e MATRÍCULAS.")

        ws_iwos = wb["IWOS"]
        linhas_iwos = [list(linha) for linha in ws_iwos.iter_rows(values_only=True)]
        if not linhas_iwos:
            return {}, []
        cab_iwos = {str(v or "").strip().casefold(): i for i, v in enumerate(linhas_iwos[0])}
        por_nome: dict[str, dict[str, str]] = {}
        for linha in linhas_iwos[1:]:
            nome = str(linha[cab_iwos.get("nome", 1)] or "").strip()
            if not nome:
                continue
            por_nome[nome.casefold()] = {
                "id": normalizar_identificador(linha[cab_iwos.get("id", 0)]),
                "centro": str(linha[cab_iwos.get("centro", 2)] or "").strip(),
                "funcao": str(linha[cab_iwos.get("função", 3)] or "").strip(),
                "admissao": _data(linha[cab_iwos.get("admissão", 4)]),
                "disponibilidade": str(linha[cab_iwos.get("disponibilidade", 5)] or "").strip(),
            }

        ws_mat = wb["MATRÍCULAS"]
        linhas = ws_mat.iter_rows(values_only=True)
        cab = [str(v or "").strip().casefold() for v in next(linhas)]
        aliases = {
            "matricula": ("matrícula", "matricula"),
            "nome": ("nome do leiturista", "nome"),
            "id": ("id",), "polo": ("polo",),
            "funcao": ("experiência / função", "função", "funcao"),
            "status": ("estatus", "status"), "admissao": ("admissão", "admissao"),
        }
        def indice(chave: str) -> int | None:
            return next((cab.index(a) for a in aliases[chave] if a in cab), None)
        indices = {chave: indice(chave) for chave in aliases}
        if indices["matricula"] is None or indices["nome"] is None:
            raise ValueError("A aba MATRÍCULAS precisa das colunas MATRÍCULA e NOME DO LEITURISTA.")

        colaboradores: dict[str, ColaboradorIWOS] = {}
        for linha in linhas:
            matricula = normalizar_identificador(linha[indices["matricula"]])
            nome = str(linha[indices["nome"]] or "").strip()
            if not matricula or not nome or matricula.casefold() == "demitido":
                continue
            atual = por_nome.get(nome.casefold(), {})
            def local(chave: str) -> str:
                i = indices.get(chave)
                return str(linha[i] or "").strip() if i is not None else ""
            colaboradores[matricula.casefold()] = ColaboradorIWOS(
                matricula=matricula, nome=nome,
                id_iwos=atual.get("id") or local("id"),
                centro=atual.get("centro") or local("polo"),
                funcao=atual.get("funcao") or local("funcao"),
                admissao=atual.get("admissao") or (_data(linha[indices["admissao"]]) if indices["admissao"] is not None else ""),
                disponibilidade=atual.get("disponibilidade") or local("status"),
            )
        return colaboradores, linhas_iwos
    finally:
        wb.close()
