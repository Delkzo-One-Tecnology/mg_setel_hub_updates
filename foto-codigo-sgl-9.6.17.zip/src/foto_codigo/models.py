from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from enum import StrEnum


class StatusAnalise(StrEnum):
    APROVADA = "Aprovada"
    REPROVADA = "Reprovada — Foto incompatível"
    VERIFICACAO = "Verificação — Tempo esgotado"
    SEM_FOTO = "Sem foto"
    ERRO = "Erro na consulta"
    INTERROMPIDA = "Interrompida"


@dataclass(frozen=True, slots=True)
class RegistroBase:
    ul: str
    razao: int
    instalacao: str
    codigo: str
    endereco: str
    referencia: str
    data_origem: str
    hora_origem: str
    polo: str
    matricula_leiturista: str = ""
    nome_leiturista: str = "NÃO INFORMADO"
    id_iwos: str = ""
    centro_iwos: str = ""
    funcao_iwos: str = ""
    admissao_iwos: str = ""
    disponibilidade_iwos: str = ""
    leitura_anterior: str = ""
    leitura_executada: str = ""


@dataclass(slots=True)
class ResultadoAnalise:
    contrato: str
    registro: RegistroBase
    status: StatusAnalise
    total_fotos: int = 0
    fotos_verificadas: int = 0
    foto_reprovada: int | None = None
    duracao_segundos: int = 0
    observacao: str = ""
    analisado_em: str = ""

    def __post_init__(self) -> None:
        if not self.analisado_em:
            self.analisado_em = datetime.now().isoformat(timespec="seconds")

    def linha_tecnica(self) -> dict[str, object]:
        base = asdict(self.registro)
        return {
            "contrato": self.contrato,
            **base,
            "status": str(self.status),
            "total_fotos": self.total_fotos,
            "fotos_verificadas": self.fotos_verificadas,
            "foto_reprovada": self.foto_reprovada or "",
            "duracao_segundos": self.duracao_segundos,
            "observacao": self.observacao,
            "analisado_em": self.analisado_em,
        }
