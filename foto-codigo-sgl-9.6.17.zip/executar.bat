@echo off
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Criando o ambiente do programa...
    py -3 -m venv .venv
    if errorlevel 1 goto :erro
)

rem Confere as dependencias mesmo quando a pasta .venv ja existe.
rem Isso tambem repara ambientes copiados, incompletos ou de versoes anteriores.
".venv\Scripts\python.exe" -c "import certifi, flet, openpyxl, selenium" >nul 2>&1
if errorlevel 1 (
    echo Instalando ou reparando as dependencias necessarias...
    ".venv\Scripts\python.exe" -m ensurepip --upgrade >nul 2>&1
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto :erro_dependencias
)

".venv\Scripts\python.exe" -c "import certifi, flet, openpyxl, selenium" >nul 2>&1
if errorlevel 1 goto :erro_dependencias

set PYTHONPATH=%CD%\src
".venv\Scripts\python.exe" -m foto_codigo
if errorlevel 1 goto :erro
exit /b 0

:erro_dependencias
echo.
echo Nao foi possivel instalar as dependencias do programa.
echo Verifique a conexao com a internet e tente novamente.
echo Se o erro continuar, exclua somente a pasta .venv e execute este arquivo outra vez.
pause
exit /b 1

:erro
echo.
echo Nao foi possivel iniciar o programa.
pause
exit /b 1
