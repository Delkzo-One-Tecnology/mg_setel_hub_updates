@echo off
cd /d "%~dp0"
where py >nul 2>&1 || (
  echo Python nao foi encontrado.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\pythonw.exe" (
  py -3.12 -m venv .venv
  .venv\Scripts\python.exe -m pip install --upgrade pip
  .venv\Scripts\python.exe -m pip install -r requirements.txt
)
start "" .venv\Scripts\pythonw.exe app_flet.py
