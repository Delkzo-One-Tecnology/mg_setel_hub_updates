from __future__ import annotations

import json
import os
import queue
import shutil
import tempfile
import threading
import time
import tkinter as tk
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

import keyring
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait


APP_NAME = "RelatoriosSGL"
APP_VERSION = "0.1.0"
LOGIN_URL = "https://sglempreiteira.cemig.com.br/SGLEmpreiteira/conta/Login"
KEYRING_SERVICE = "MGSetelHub.RelatoriosSGL"

CONTRACTS = {
    "Mantiqueira": [
        "Benfica", "Conselheiro Lafaiete", "São João del Rei", "Ouro Preto",
        "Ponte Nova", "Viçosa", "Barbacena", "Manoel Honorio", "Juiz de Fora",
    ],
    "Uberaba": ["Araxá", "Frutal", "Uberaba"],
    "Divinopolis": ["Miller"],
}


def app_data_dir() -> Path:
    base = Path(os.getenv("APPDATA") or Path.home()) / "MGSetelHub" / APP_NAME
    base.mkdir(parents=True, exist_ok=True)
    return base


SETTINGS_PATH = app_data_dir() / "settings.json"


def load_settings() -> dict:
    if not SETTINGS_PATH.exists():
        return {"users": {}, "output": str(Path.home() / "Downloads")}
    try:
        return json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"users": {}, "output": str(Path.home() / "Downloads")}


def save_settings(settings: dict) -> None:
    SETTINGS_PATH.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")


def credential_key(contract: str, city: str) -> str:
    return f"{contract}:{city}"


@dataclass
class Credentials:
    username: str
    password: str


class Cancelled(Exception):
    pass


class Processor:
    def __init__(self, emit, stop_event: threading.Event):
        self.emit = emit
        self.stop_event = stop_event
        self.driver = None

    def check_cancelled(self):
        if self.stop_event.is_set():
            raise Cancelled()

    def create_driver(self, download_dir: Path):
        options = Options()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--incognito")
        options.add_experimental_option("prefs", {
            "download.default_directory": str(download_dir.resolve()),
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "plugins.always_open_pdf_externally": True,
        })
        driver = webdriver.Chrome(service=Service(), options=options)
        try:
            driver.execute_cdp_cmd("Page.setDownloadBehavior", {
                "behavior": "allow", "downloadPath": str(download_dir.resolve())
            })
        except Exception:
            pass
        return driver

    @staticmethod
    def fill_confirm(driver, wait, field_id: str, value: str, retries=5) -> bool:
        for _ in range(retries):
            try:
                field = wait.until(EC.presence_of_element_located((By.ID, field_id)))
                field.clear()
                field.send_keys(value)
                time.sleep(0.5)
                if (field.get_attribute("value") or "").strip() == value:
                    return True
            except Exception:
                time.sleep(0.6)
        return False

    @staticmethod
    def login(driver, wait, credentials: Credentials) -> None:
        driver.get(LOGIN_URL)
        user = wait.until(EC.presence_of_element_located((By.ID, "UserName")))
        password = wait.until(EC.presence_of_element_located((By.ID, "Password")))
        user.clear()
        user.send_keys(credentials.username)
        password.clear()
        password.send_keys(credentials.password)
        driver.find_element(By.XPATH, "//button[contains(.,'Login')]").click()
        time.sleep(1.2)

    @staticmethod
    def logout(driver, wait) -> None:
        try:
            wait.until(EC.element_to_be_clickable((By.XPATH, "//a[@title='Configurações']"))).click()
            time.sleep(0.6)
            wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href,'LogOff')]"))).click()
            time.sleep(1)
        except Exception:
            pass

    def setup_report(self, driver, wait, reference: str) -> None:
        menu = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[contains(@class,'nav-label')][contains(.,'RELATÓRIOS')]")))
        menu.click()
        time.sleep(0.5)
        wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href,'RlSequenciaLeituraExecutada')]"))).click()
        time.sleep(0.7)
        if not self.fill_confirm(driver, wait, "txtMesAno", reference, 6):
            raise RuntimeError("O mês/ano não permaneceu no formulário do SGL.")
        select = Select(wait.until(EC.presence_of_element_located((By.ID, "cmbSequencia"))))
        select.select_by_value("0")

    def wait_download(self, folder: Path, before: set[str], timeout=300) -> Path | None:
        started = time.time()
        stable_size = None
        stable_count = 0
        candidate = None
        while time.time() - started < timeout:
            self.check_cancelled()
            names = {p.name for p in folder.iterdir() if p.is_file()}
            partial = any(name.endswith((".crdownload", ".tmp", ".part")) for name in names)
            new_names = [name for name in names - before if not name.endswith((".crdownload", ".tmp", ".part"))]
            if new_names and not partial:
                candidate = folder / sorted(new_names)[-1]
                try:
                    size = candidate.stat().st_size
                except OSError:
                    time.sleep(0.5)
                    continue
                if size == stable_size and size > 0:
                    stable_count += 1
                    if stable_count >= 2:
                        return candidate
                else:
                    stable_size, stable_count = size, 0
            time.sleep(1)
        return None

    @staticmethod
    def process_sheet(sheet: pd.DataFrame) -> pd.DataFrame | None:
        if sheet.shape[0] <= 12 or sheet.shape[1] < 10:
            return None
        df = sheet.iloc[12:].reset_index(drop=True).copy()
        col0 = df.iloc[:, 0].astype(str)
        unit_mask = col0.str.startswith("Unidade de Leitura", na=False)
        df["Unidade de Leitura"] = col0.where(unit_mask).str.extract(r"(\d{8})", expand=False).ffill()
        df["Matriculas"] = df.iloc[:, 0].shift(-1).astype(str).str[-3:].where(unit_mask).ffill()
        columns = sheet.shape[1]
        if columns <= 18:
            def at(index): return df.iloc[:, min(index, columns - 1)]
            df["Data"] = pd.to_datetime(at(8), dayfirst=True, errors="coerce")
            df["Hora"] = pd.to_datetime(at(9), errors="coerce")
            df["Código"] = pd.to_numeric(at(6), errors="coerce").astype("Int64")
            df["Leitura Anterior"] = pd.to_numeric(at(13), errors="coerce")
            df["Leitura Executada"] = pd.to_numeric(at(14), errors="coerce")
            df["instalação concatenada"] = col0 + at(3).astype(str) + at(9).shift(-1).astype(str)
        else:
            df["Data"] = pd.to_datetime(df.iloc[:, 15], dayfirst=True, errors="coerce")
            df["Hora"] = pd.to_datetime(df.iloc[:, 17], errors="coerce")
            df["Código"] = pd.to_numeric(df.iloc[:, 12], errors="coerce").astype("Int64")
            df["Leitura Anterior"] = pd.to_numeric(df.iloc[:, 25], errors="coerce")
            df["Leitura Executada"] = pd.to_numeric(df.iloc[:, 28], errors="coerce")
            df["instalação concatenada"] = col0 + df.iloc[:, 3].astype(str) + df.iloc[:, 17].shift(-1).astype(str)
        df["Instalação"] = pd.to_numeric(col0, errors="coerce").astype("Int64")
        df.dropna(subset=["Instalação", "Data", "Hora"], inplace=True)
        if df.empty:
            return None
        df["Data"] = df["Data"].dt.strftime("%d/%m/%Y")
        df["Hora"] = df["Hora"].dt.strftime("%H:%M:%S")
        return df[["Unidade de Leitura", "Matriculas", "Data", "Hora", "Código",
                   "instalação concatenada", "Instalação", "Leitura Anterior", "Leitura Executada"]]

    def process_workbook(self, source: Path, target: Path) -> pd.DataFrame:
        engine = "openpyxl" if source.suffix.lower() == ".xlsx" else "xlrd"
        sheets = pd.read_excel(source, sheet_name=None, engine=engine)
        frames = []
        for sheet in sheets.values():
            self.check_cancelled()
            result = self.process_sheet(sheet)
            if result is not None:
                frames.append(result)
        if not frames:
            raise ValueError("Nenhum registro válido encontrado no arquivo.")
        result = pd.concat(frames, ignore_index=True)
        result["_ordem"] = pd.to_datetime(result["Data"] + " " + result["Hora"], dayfirst=True, errors="coerce")
        result.sort_values(["_ordem", "Matriculas", "Unidade de Leitura"], inplace=True)
        result.drop(columns="_ordem", inplace=True)
        target.parent.mkdir(parents=True, exist_ok=True)
        result.to_excel(target, index=False, engine="openpyxl")
        return result

    @staticmethod
    def save_consolidated(frames: list[pd.DataFrame], target: Path) -> None:
        if not frames:
            return
        result = pd.concat(frames, ignore_index=True)
        result["_ordem"] = pd.to_datetime(result["Data"] + " " + result["Hora"], dayfirst=True, errors="coerce")
        result.sort_values(["_ordem", "Matriculas", "Unidade de Leitura"], inplace=True)
        result.drop(columns="_ordem", inplace=True)
        target.parent.mkdir(parents=True, exist_ok=True)
        result.to_excel(target, index=False, engine="openpyxl")

    def run(self, contract: str, reference: str, output_root: Path, credentials: dict[str, Credentials]):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        root = output_root / f"Relatorios_{contract}_{reference.replace('/', '-')}_{stamp}"
        root.mkdir(parents=True, exist_ok=True)
        ranges = [(f"{i:02}000000", f"{i:02}999999") for i in range(1, 19)]
        total = len(CONTRACTS[contract]) * len(ranges)
        completed = 0
        contract_frames = []
        errors = []

        temp_download = Path(tempfile.mkdtemp(prefix="relatorios_sgl_"))
        try:
            self.driver = self.create_driver(temp_download)
            wait = WebDriverWait(self.driver, 20)
            for city in CONTRACTS[contract]:
                self.check_cancelled()
                city_root = root / city
                originals = city_root / "Originais"
                processed = city_root / "Processados"
                originals.mkdir(parents=True, exist_ok=True)
                processed.mkdir(parents=True, exist_ok=True)
                city_frames = []
                self.emit("stage", f"Entrando no SGL — {city}")
                try:
                    self.login(self.driver, wait, credentials[city])
                    self.setup_report(self.driver, wait, reference)
                except Exception as exc:
                    errors.append(f"{city}: falha no login/configuração — {exc}")
                    self.emit("log", errors[-1])
                    completed += len(ranges)
                    self.emit("progress", completed, total)
                    continue

                for start, end in ranges:
                    self.check_cancelled()
                    self.emit("stage", f"{city} · faixa {start}–{end}")
                    success = False
                    for attempt in range(1, 4):
                        try:
                            before = {p.name for p in temp_download.iterdir()}
                            if not self.fill_confirm(self.driver, wait, "txtUnidadeLeitura", start):
                                raise RuntimeError("campo inicial não confirmou o valor")
                            if not self.fill_confirm(self.driver, wait, "txtUnidadeLeituraFinal", end):
                                raise RuntimeError("campo final não confirmou o valor")
                            wait.until(EC.element_to_be_clickable((By.ID, "btnGerarExcel"))).click()
                            downloaded = self.wait_download(temp_download, before)
                            if downloaded is None:
                                raise TimeoutError("download não foi concluído")
                            extension = downloaded.suffix.lower() or ".xlsx"
                            original = originals / f"{city}_{start}-{end}{extension}"
                            shutil.move(str(downloaded), original)
                            target = processed / f"{city}_{start}-{end}_processado.xlsx"
                            frame = self.process_workbook(original, target)
                            city_frames.append(frame)
                            contract_frames.append(frame)
                            self.emit("log", f"✓ {city} · {start}-{end}: {len(frame)} registros")
                            success = True
                            break
                        except Cancelled:
                            raise
                        except Exception as exc:
                            self.emit("log", f"⚠ {city} · {start}-{end} · tentativa {attempt}/3: {exc}")
                            if attempt < 3:
                                self.logout(self.driver, wait)
                                self.login(self.driver, wait, credentials[city])
                                self.setup_report(self.driver, wait, reference)
                    if not success:
                        errors.append(f"{city}: faixa {start}-{end} não processada")
                    completed += 1
                    self.emit("progress", completed, total)

                self.save_consolidated(city_frames, city_root / f"{city}_consolidado.xlsx")
                self.logout(self.driver, wait)

            self.save_consolidated(contract_frames, root / f"{contract}_consolidado.xlsx")
            (root / "log_processamento.txt").write_text("\n".join(errors) if errors else "Processamento concluído sem erros.", encoding="utf-8")
            return root, len(contract_frames), errors
        finally:
            if self.driver:
                try:
                    self.driver.quit()
                except Exception:
                    pass
            shutil.rmtree(temp_download, ignore_errors=True)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Relatórios e Consolidação SGL · v{APP_VERSION}")
        self.geometry("900x680")
        self.minsize(820, 620)
        self.configure(bg="#edf3f7")
        self.settings = load_settings()
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.started_at = None
        self.running = False
        self.build_ui()
        self.after(120, self.poll_events)

    def build_ui(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#ffffff")
        style.configure("Title.TLabel", background="#ffffff", foreground="#102c42", font=("Segoe UI", 20, "bold"))
        style.configure("Sub.TLabel", background="#ffffff", foreground="#687b89", font=("Segoe UI", 10))
        style.configure("TLabel", background="#ffffff", foreground="#263b49", font=("Segoe UI", 10))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(16, 10))
        style.configure("TButton", font=("Segoe UI", 9), padding=(11, 8))

        card = ttk.Frame(self, padding=28)
        card.pack(fill="both", expand=True, padx=24, pady=24)
        ttk.Label(card, text="Relatórios e Consolidação SGL", style="Title.TLabel").grid(row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(card, text="Download, tratamento e consolidação em um único processo.", style="Sub.TLabel").grid(row=1, column=0, columnspan=4, sticky="w", pady=(3, 22))

        ttk.Label(card, text="Contrato").grid(row=2, column=0, sticky="w")
        self.contract = ttk.Combobox(card, values=list(CONTRACTS), state="readonly", width=25)
        self.contract.set("Mantiqueira")
        self.contract.grid(row=3, column=0, sticky="ew", padx=(0, 12))
        ttk.Label(card, text="Referência (MM/AAAA)").grid(row=2, column=1, sticky="w")
        self.reference = ttk.Entry(card, width=18)
        self.reference.insert(0, datetime.now().strftime("%m/%Y"))
        self.reference.grid(row=3, column=1, sticky="ew", padx=(0, 12))
        ttk.Label(card, text="Pasta de saída").grid(row=2, column=2, sticky="w")
        self.output = ttk.Entry(card)
        self.output.insert(0, self.settings.get("output", str(Path.home() / "Downloads")))
        self.output.grid(row=3, column=2, sticky="ew", padx=(0, 8))
        ttk.Button(card, text="Escolher", command=self.choose_output).grid(row=3, column=3, sticky="ew")

        actions = ttk.Frame(card)
        actions.grid(row=4, column=0, columnspan=4, sticky="ew", pady=20)
        self.start_button = ttk.Button(actions, text="Iniciar processo completo", style="Accent.TButton", command=self.start)
        self.start_button.pack(side="left")
        ttk.Button(actions, text="Credenciais", command=self.configure_credentials).pack(side="left", padx=8)
        self.stop_button = ttk.Button(actions, text="Interromper", command=self.stop, state="disabled")
        self.stop_button.pack(side="left")

        status = ttk.Frame(card, padding=16)
        status.grid(row=5, column=0, columnspan=4, sticky="ew")
        self.stage = ttk.Label(status, text="Pronto para iniciar", font=("Segoe UI", 11, "bold"))
        self.stage.pack(anchor="w")
        self.progress = ttk.Progressbar(status, mode="determinate")
        self.progress.pack(fill="x", pady=(10, 5))
        self.counter = ttk.Label(status, text="0/0 etapas · 00:00")
        self.counter.pack(anchor="w")

        ttk.Label(card, text="Histórico da execução", font=("Segoe UI", 10, "bold")).grid(row=6, column=0, columnspan=4, sticky="w", pady=(18, 7))
        self.log = tk.Text(card, height=15, bg="#102c42", fg="#d8e7ef", insertbackground="white", relief="flat", padx=12, pady=12, font=("Consolas", 9), state="disabled")
        self.log.grid(row=7, column=0, columnspan=4, sticky="nsew")
        card.columnconfigure(2, weight=1)
        card.rowconfigure(7, weight=1)

    def choose_output(self):
        folder = filedialog.askdirectory(initialdir=self.output.get() or str(Path.home()))
        if folder:
            self.output.delete(0, tk.END)
            self.output.insert(0, folder)

    def configure_credentials(self):
        contract = self.contract.get()
        updated = 0
        for city in CONTRACTS[contract]:
            key = credential_key(contract, city)
            current = self.settings.setdefault("users", {}).get(key, "")
            username = simpledialog.askstring("Credenciais SGL", f"Usuário de {city}:", initialvalue=current, parent=self)
            if username is None:
                break
            password = simpledialog.askstring("Credenciais SGL", f"Senha de {city}:", show="•", parent=self)
            if password is None:
                break
            self.settings["users"][key] = username.strip()
            keyring.set_password(KEYRING_SERVICE, key, password)
            updated += 1
        save_settings(self.settings)
        if updated:
            messagebox.showinfo("Credenciais", f"{updated} credencial(is) armazenada(s) com segurança.")

    def get_credentials(self, contract: str) -> dict[str, Credentials] | None:
        result = {}
        missing = []
        for city in CONTRACTS[contract]:
            key = credential_key(contract, city)
            username = self.settings.get("users", {}).get(key, "")
            password = keyring.get_password(KEYRING_SERVICE, key)
            if not username or not password:
                missing.append(city)
            else:
                result[city] = Credentials(username, password)
        if missing:
            messagebox.showwarning("Credenciais pendentes", "Cadastre as credenciais destas cidades:\n\n" + "\n".join(missing))
            return None
        return result

    def start(self):
        reference = self.reference.get().strip()
        try:
            datetime.strptime(reference, "%m/%Y")
        except ValueError:
            messagebox.showwarning("Referência inválida", "Informe a referência no formato MM/AAAA.")
            return
        contract = self.contract.get()
        credentials = self.get_credentials(contract)
        if credentials is None:
            return
        output = Path(self.output.get().strip())
        output.mkdir(parents=True, exist_ok=True)
        self.settings["output"] = str(output)
        save_settings(self.settings)
        self.running = True
        self.stop_event.clear()
        self.started_at = time.time()
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.progress["value"] = 0
        self.write_log(f"Iniciando {contract} · {reference}")

        def worker():
            try:
                emit = lambda *event: self.events.put(event)
                result = Processor(emit, self.stop_event).run(contract, reference, output, credentials)
                self.events.put(("done", result))
            except Cancelled:
                self.events.put(("cancelled",))
            except Exception as exc:
                self.events.put(("error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.update_clock()

    def stop(self):
        self.stop_event.set()
        self.stage.configure(text="Interrompendo com segurança...")
        self.stop_button.configure(state="disabled")

    def write_log(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "stage":
                    self.stage.configure(text=event[1])
                elif kind == "log":
                    self.write_log(event[1])
                elif kind == "progress":
                    done, total = event[1], event[2]
                    self.progress["maximum"] = total
                    self.progress["value"] = done
                    self.counter.configure(text=f"{done}/{total} etapas")
                elif kind == "done":
                    root, files, errors = event[1]
                    self.finish()
                    self.stage.configure(text="Processamento concluído")
                    messagebox.showinfo("Concluído", f"Processo finalizado.\n\nPacotes processados: {files}\nPendências: {len(errors)}\n\nSaída: {root}")
                    os.startfile(root)
                elif kind == "cancelled":
                    self.finish()
                    self.stage.configure(text="Processamento interrompido")
                elif kind == "error":
                    self.finish()
                    self.stage.configure(text="Falha no processamento")
                    messagebox.showerror("Erro", event[1])
        except queue.Empty:
            pass
        self.after(120, self.poll_events)

    def update_clock(self):
        if not self.running or self.started_at is None:
            return
        elapsed = int(time.time() - self.started_at)
        current = self.counter.cget("text").split(" · ")[0]
        self.counter.configure(text=f"{current} · {elapsed // 60:02d}:{elapsed % 60:02d}")
        self.after(1000, self.update_clock)

    def finish(self):
        self.running = False
        self.start_button.configure(state="normal")
        self.stop_button.configure(state="disabled")


if __name__ == "__main__":
    App().mainloop()
