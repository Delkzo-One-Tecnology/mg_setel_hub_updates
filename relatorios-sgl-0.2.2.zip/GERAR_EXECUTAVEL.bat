@echo off
cd /d "%~dp0"
py -3.12 -m pip install --upgrade pyinstaller
py -3.12 -m pip install -r requirements.txt
py -3.12 -m PyInstaller --noconfirm --clean --windowed --onedir --name RelatoriosSGL --collect-all keyring --collect-all flet app_flet.py
echo.
echo Executavel gerado em dist\RelatoriosSGL\RelatoriosSGL.exe
pause
