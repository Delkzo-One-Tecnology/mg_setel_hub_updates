from __future__ import annotations

import os
import threading
import time
from datetime import datetime
from pathlib import Path

import flet as ft
import keyring

from app import (
    CONTRACTS,
    KEYRING_SERVICE,
    Cancelled,
    Credentials,
    Processor,
    credential_key,
    load_settings,
    save_settings,
)


VERSION = "0.2.2"
BG = "#FAFAF8"
SURFACE = "#FFFFFF"
SURFACE_SOFT = "#F5F4F0"
TEXT = "#171717"
TEXT_SOFT = "#6F6C64"
TEXT_MUTED = "#A29F97"
BORDER = "#ECE8E0"
PRIMARY = "#171717"
SUCCESS = "#10B981"
SUCCESS_SOFT = "#DDF7EC"
INFO = "#2464A1"
WARNING = "#9B6508"
WARNING_SOFT = "#FFF2D8"
ERROR = "#B93832"
ERROR_SOFT = "#F7E2DF"


class RelatoriosSGLApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.settings = load_settings()
        self.stop_event = threading.Event()
        self.running = False
        self.started_at: float | None = None
        self.output_result: Path | None = None

        self.contract = ft.Dropdown(
            label="Contrato",
            value="Mantiqueira",
            options=[ft.dropdown.Option(item) for item in CONTRACTS],
            border_color=BORDER,
            focused_border_color=BORDER,
            bgcolor=SURFACE,
            text_style=ft.TextStyle(size=12, color=TEXT),
            border_radius=14,
            expand=True,
        )
        self.reference = ft.TextField(
            label="Referência",
            value=datetime.now().strftime("%m/%Y"),
            hint_text="MM/AAAA",
            border_color=BORDER,
            focused_border_color=BORDER,
            bgcolor=SURFACE,
            color=TEXT,
            width=190,
            border_radius=14,
        )
        self.output = ft.TextField(
            label="Pasta de saída",
            value=self.settings.get("output", str(Path.home() / "Downloads")),
            border_color=BORDER,
            focused_border_color=BORDER,
            bgcolor=SURFACE,
            color=TEXT,
            read_only=True,
            border_radius=14,
            expand=True,
        )
        self.stage = ft.Text("Pronto para iniciar", size=16, weight=ft.FontWeight.W_700, color=TEXT)
        self.stage_detail = ft.Text("Configure o contrato e a referência para começar.", size=12, color=TEXT_SOFT)
        self.progress = ft.ProgressBar(value=0, color=SUCCESS, bgcolor="#E8E4DD", height=8, bar_height=8)
        self.progress_count = ft.Text("0/0 etapas", size=11, weight=ft.FontWeight.W_700, color="#8B8B86")
        self.elapsed = ft.Text("00:00", size=11, weight=ft.FontWeight.W_700, color="#8B8B86")
        self.log = ft.ListView(expand=True, spacing=7, auto_scroll=True, padding=0)
        self.status_badge = self.badge("AGUARDANDO", SURFACE_SOFT, TEXT_SOFT)
        self.start_button = ft.ElevatedButton(
            "Iniciar processo completo",
            icon=ft.Icons.PLAY_ARROW_ROUNDED,
            bgcolor=PRIMARY,
            color="white",
            height=46,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=14)),
            on_click=self.start,
        )
        self.stop_button = ft.OutlinedButton(
            "Interromper",
            icon=ft.Icons.STOP_ROUNDED,
            disabled=True,
            height=46,
            style=ft.ButtonStyle(color=ERROR, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=14)),
            on_click=self.stop,
        )
        self.open_output_button = ft.OutlinedButton(
            "Abrir resultado",
            icon=ft.Icons.FOLDER_OPEN_ROUNDED,
            disabled=True,
            height=42,
            style=ft.ButtonStyle(color=TEXT, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=14)),
            on_click=self.open_result,
        )

        self.folder_picker = ft.FilePicker(on_result=self.folder_selected)
        self.page.overlay.append(self.folder_picker)
        self.configure_page()
        self.render()

    def configure_page(self):
        self.page.title = f"Relatórios e Consolidação SGL · v{VERSION}"
        self.page.bgcolor = BG
        self.page.padding = 0
        self.page.window.width = 1180
        self.page.window.height = 780
        self.page.window.min_width = 980
        self.page.window.min_height = 680
        self.page.theme = ft.Theme(font_family="Segoe UI", color_scheme_seed=SUCCESS)

    @staticmethod
    def label(text: str) -> ft.Text:
        return ft.Text(text.upper(), size=11, weight=ft.FontWeight.W_700, color="#A0A8B4", font_family="Montserrat")

    @staticmethod
    def badge(text: str, background: str, color: str):
        return ft.Container(
            content=ft.Text(text, size=9, weight=ft.FontWeight.W_700, color=color),
            bgcolor=background,
            border_radius=20,
            border=ft.Border.all(1, BORDER),
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
        )

    @staticmethod
    def card(content, padding=22, expand=False):
        return ft.Container(
            content=content,
            bgcolor=SURFACE,
            border=ft.border.all(1, BORDER),
            border_radius=24,
            padding=padding,
            shadow=ft.BoxShadow(blur_radius=18, color="#1717170A", offset=ft.Offset(0, 8)),
            expand=expand,
        )

    def render(self):
        configuration = self.card(
            ft.Column(
                [
                    self.label("Configuração do processo"),
                    ft.Text("Informe os dados da extração que será executada no SGL.", size=14, color=TEXT_SOFT),
                    ft.Row(
                        [
                            self.contract,
                            self.reference,
                            self.output,
                            ft.IconButton(
                                icon=ft.Icons.FOLDER_OPEN_ROUNDED,
                                tooltip="Escolher pasta",
                                icon_color=TEXT,
                                on_click=lambda _: self.folder_picker.get_directory_path(dialog_title="Selecione a pasta de saída"),
                            ),
                        ],
                        spacing=12,
                    ),
                    ft.Row(
                        [
                            self.start_button,
                            self.stop_button,
                            ft.OutlinedButton("Credenciais", icon=ft.Icons.KEY_ROUNDED, height=46, style=ft.ButtonStyle(color=TEXT, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=14)), on_click=self.open_credentials),
                        ],
                        spacing=10,
                    ),
                ],
                spacing=14,
            ),
        )

        progress_card = ft.Container(
            bgcolor=PRIMARY,
            border_radius=34,
            padding=28,
            shadow=ft.BoxShadow(blur_radius=28, color="#17171722", offset=ft.Offset(0, 14)),
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Text("EXECUTION SCORE", size=11, weight=ft.FontWeight.W_700, color="#8B8B86", font_family="Montserrat"),
                            ft.Container(expand=True),
                            ft.Icon(ft.Icons.SHIELD_OUTLINED, size=18, color=SUCCESS),
                        ]
                    ),
                    ft.Row([ft.Column([self.stage, self.stage_detail], spacing=4, expand=True), self.status_badge], vertical_alignment=ft.CrossAxisAlignment.START),
                    self.progress,
                    ft.Row(
                        [
                            ft.Row([ft.Icon(ft.Icons.FORMAT_LIST_NUMBERED_ROUNDED, size=15, color="#8B8B86"), self.progress_count], spacing=6),
                            ft.Row([ft.Icon(ft.Icons.TIMER_OUTLINED, size=15, color="#8B8B86"), self.elapsed], spacing=6),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    ),
                ],
                spacing=14,
            ),
        )

        log_card = self.card(
            ft.Column(
                [
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    self.label("Atividade da execução"),
                                    ft.Text("Acompanhe downloads, tentativas e arquivos processados em tempo real.", size=14, color=TEXT_SOFT),
                                ],
                                spacing=8,
                                expand=True,
                            ),
                            self.open_output_button,
                        ]
                    ),
                    ft.Container(
                        content=self.log,
                        bgcolor=PRIMARY,
                        border_radius=22,
                        padding=16,
                        expand=True,
                    ),
                ],
                spacing=14,
                expand=True,
            ),
            expand=True,
        )

        hero = ft.Container(
            padding=ft.padding.only(left=30, top=28, right=30, bottom=18),
            content=ft.Row(
                [
                    ft.Column(
                        [
                            self.label("RELATÓRIOS SGL"),
                            ft.Text("Consolidação operacional local", size=38, weight=ft.FontWeight.W_600, color=TEXT, font_family="Montserrat"),
                            ft.Text("Baixe, processe e consolide as leituras sem trocar de aplicativo.", size=14, color=TEXT_SOFT),
                        ],
                        spacing=10,
                        expand=True,
                    ),
                    self.badge(f"VERSÃO {VERSION}", SURFACE, INFO),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.START,
            ),
        )

        body = ft.Container(
            padding=ft.padding.only(left=30, right=30, bottom=30),
            content=ft.ResponsiveRow(
                [
                    ft.Container(col={"sm": 12, "lg": 7}, content=configuration),
                    ft.Container(col={"sm": 12, "lg": 5}, content=progress_card),
                    ft.Container(col={"sm": 12}, content=log_card),
                ],
                spacing=20,
                run_spacing=20,
            ),
        )

        self.page.add(ft.Column([hero, body], spacing=0, expand=True, scroll=ft.ScrollMode.AUTO))

    def folder_selected(self, event: ft.FilePickerResultEvent):
        if event.path:
            self.output.value = event.path
            self.page.update()

    def show_message(self, title: str, message: str, error=False):
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(title),
            content=ft.Text(message, color=ERROR if error else TEXT),
            actions=[ft.TextButton("Fechar", on_click=lambda _: self.close_dialog(dialog))],
        )
        self.page.open(dialog)

    def close_dialog(self, dialog):
        self.page.close(dialog)

    def open_credentials(self, _):
        contract = self.contract.value
        controls = []
        fields = {}
        for city in CONTRACTS[contract]:
            key = credential_key(contract, city)
            user = self.settings.setdefault("users", {}).get(key, "")
            username = ft.TextField(label=f"Usuário · {city}", value=user, border_color=BORDER, focused_border_color=BORDER, border_radius=14, expand=True)
            password = ft.TextField(label="Senha", password=True, can_reveal_password=True, border_color=BORDER, focused_border_color=BORDER, border_radius=14, width=230)
            fields[city] = (username, password)
            controls.append(ft.Row([username, password], spacing=10))

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Credenciais · {contract}", weight=ft.FontWeight.BOLD),
            content=ft.Container(
                content=ft.Column(
                    [
                        ft.Text("As senhas serão armazenadas pelo Gerenciador de Credenciais do Windows.", size=10, color=TEXT_SOFT),
                        *controls,
                    ],
                    scroll=ft.ScrollMode.AUTO,
                    spacing=10,
                ),
                width=650,
                height=min(520, 86 + len(controls) * 66),
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda _: self.close_dialog(dialog)),
                ft.ElevatedButton("Salvar credenciais", bgcolor=PRIMARY, color="white", on_click=lambda _: self.save_credentials(dialog, contract, fields)),
            ],
        )
        self.page.open(dialog)

    def save_credentials(self, dialog, contract, fields):
        saved = 0
        for city, (username, password) in fields.items():
            key = credential_key(contract, city)
            if username.value.strip():
                self.settings["users"][key] = username.value.strip()
            if password.value:
                keyring.set_password(KEYRING_SERVICE, key, password.value)
            if username.value.strip() and (password.value or keyring.get_password(KEYRING_SERVICE, key)):
                saved += 1
        save_settings(self.settings)
        self.close_dialog(dialog)
        self.show_message("Credenciais salvas", f"{saved} credencial(is) configurada(s) para {contract}.")

    def get_credentials(self):
        contract = self.contract.value
        result = {}
        missing = []
        for city in CONTRACTS[contract]:
            key = credential_key(contract, city)
            username = self.settings.get("users", {}).get(key, "")
            password = keyring.get_password(KEYRING_SERVICE, key)
            if not username or not password:
                missing.append(city)
            else:
                result[city] = Credentials(username, password)
        if missing:
            self.show_message("Credenciais pendentes", "Cadastre usuário e senha para:\n\n" + "\n".join(missing), True)
            return None
        return result

    def start(self, _):
        try:
            datetime.strptime(self.reference.value.strip(), "%m/%Y")
        except ValueError:
            self.show_message("Referência inválida", "Informe o período no formato MM/AAAA.", True)
            return
        credentials = self.get_credentials()
        if credentials is None:
            return
        output = Path(self.output.value.strip())
        try:
            output.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self.show_message("Pasta inválida", str(exc), True)
            return

        self.settings["output"] = str(output)
        save_settings(self.settings)
        self.running = True
        self.started_at = time.time()
        self.stop_event.clear()
        self.output_result = None
        self.log.controls.clear()
        self.progress.value = 0
        self.progress_count.value = "0/0 etapas"
        self.stage.value = "Preparando o ambiente"
        self.stage_detail.value = "O navegador será iniciado para consultar o SGL."
        self.status_badge.content.value = "PROCESSANDO"
        self.status_badge.bgcolor = WARNING_SOFT
        self.status_badge.content.color = WARNING
        self.start_button.disabled = True
        self.stop_button.disabled = False
        self.open_output_button.disabled = True
        self.add_log(f"Iniciando {self.contract.value} · {self.reference.value}", "info")
        self.page.update()

        contract = self.contract.value
        reference = self.reference.value.strip()

        def worker():
            emit = self.receive_event
            try:
                result = Processor(emit, self.stop_event).run(contract, reference, output, credentials)
                self.finished(result)
            except Cancelled:
                self.cancelled()
            except Exception as exc:
                self.failed(str(exc))

        threading.Thread(target=worker, daemon=True).start()
        threading.Thread(target=self.clock_loop, daemon=True).start()

    def receive_event(self, *event):
        kind = event[0]
        if kind == "stage":
            self.stage.value = event[1]
            self.stage_detail.value = "Download e processamento automático em andamento."
        elif kind == "log":
            self.add_log(event[1], "warning" if str(event[1]).startswith("⚠") else "success")
        elif kind == "progress":
            done, total = event[1], event[2]
            self.progress.value = done / total if total else 0
            self.progress_count.value = f"{done}/{total} etapas"
        self.safe_update()

    def add_log(self, message: str, kind="info"):
        colors = {"success": "#7BE0C0", "warning": "#F0BF63", "error": "#FF9D95", "info": "#D6D1C7"}
        self.log.controls.append(
            ft.Row(
                [
                    ft.Text(datetime.now().strftime("%H:%M:%S"), size=9, color="#948D83", width=58),
                    ft.Text(message, size=10, color=colors.get(kind, "#D6D1C7"), selectable=True, expand=True),
                ],
                vertical_alignment=ft.CrossAxisAlignment.START,
            )
        )

    def clock_loop(self):
        while self.running and self.started_at:
            elapsed = int(time.time() - self.started_at)
            self.elapsed.value = f"{elapsed // 60:02d}:{elapsed % 60:02d}"
            self.safe_update()
            time.sleep(1)

    def stop(self, _):
        self.stop_event.set()
        self.stage.value = "Interrompendo com segurança"
        self.stage_detail.value = "A etapa atual será finalizada antes de fechar o navegador."
        self.stop_button.disabled = True
        self.add_log("Interrupção solicitada pelo usuário.", "warning")
        self.page.update()

    def finished(self, result):
        root, files, errors = result
        self.output_result = root
        self.running = False
        self.progress.value = 1
        self.stage.value = "Processamento concluído"
        self.stage_detail.value = f"{files} pacotes processados · {len(errors)} pendência(s)."
        self.status_badge.content.value = "CONCLUÍDO"
        self.status_badge.bgcolor = SUCCESS_SOFT
        self.status_badge.content.color = SUCCESS
        self.start_button.disabled = False
        self.stop_button.disabled = True
        self.open_output_button.disabled = False
        self.add_log(f"Resultado salvo em: {root}", "success")
        self.safe_update()

    def cancelled(self):
        self.running = False
        self.stage.value = "Processamento interrompido"
        self.stage_detail.value = "Os arquivos concluídos foram preservados."
        self.status_badge.content.value = "INTERROMPIDO"
        self.status_badge.bgcolor = WARNING_SOFT
        self.status_badge.content.color = WARNING
        self.start_button.disabled = False
        self.stop_button.disabled = True
        self.safe_update()

    def failed(self, error):
        self.running = False
        self.stage.value = "Falha no processamento"
        self.stage_detail.value = error
        self.status_badge.content.value = "FALHA"
        self.status_badge.bgcolor = ERROR_SOFT
        self.status_badge.content.color = ERROR
        self.start_button.disabled = False
        self.stop_button.disabled = True
        self.add_log(error, "error")
        self.safe_update()

    def open_result(self, _):
        if self.output_result and self.output_result.exists():
            os.startfile(self.output_result)

    def safe_update(self):
        try:
            self.page.update()
        except Exception:
            pass


def main(page: ft.Page):
    RelatoriosSGLApp(page)


if __name__ == "__main__":
    ft.app(target=main)
