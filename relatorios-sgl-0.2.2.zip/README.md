# Relatórios e Consolidação SGL — v0.2.1

Versão inicial independente para validar o fluxo antes da integração ao MG Setel Hub.

A interface desta versão utiliza Flet e segue o padrão visual corporativo dos demais módulos, sem repetir a barra lateral exclusiva do Hub.

## Fluxo

1. Selecione o contrato, a referência e a pasta de saída.
2. Em **Credenciais**, cadastre usuário e senha de cada cidade.
3. Clique em **Iniciar processo completo**.
4. O aplicativo baixa cada faixa, processa os arquivos e cria consolidados por cidade e por contrato.

As senhas são gravadas pelo `keyring` no Gerenciador de Credenciais do Windows. O arquivo local de configurações guarda apenas os nomes de usuário.

## Executar pelo código

Execute `EXECUTAR.bat` em um computador com Python 3.12 e Google Chrome.

## Gerar executável

Execute `GERAR_EXECUTAVEL.bat`. Distribua a pasta inteira `dist/RelatoriosSGL` durante o teste.

## Observações desta versão

- O processamento usa os dois layouts encontrados nos scripts originais: simplificado (até 18 colunas) e completo.
- Arquivos não são descartados pelo tamanho. A validade é confirmada pela leitura do Excel.
- É possível interromper entre downloads; o Selenium não deve ser encerrado à força enquanto o site estiver respondendo.
- O aplicativo não contém usuários ou senhas no código-fonte.
