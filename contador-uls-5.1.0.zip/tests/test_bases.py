from contador_uls import identificar_base


def test_bases_mantiqueira_por_nome_da_aba():
    assert identificar_base("Adnilson - Barbacena") == "Barbacena"
    assert identificar_base("Reginaldo - Lafaiete") == "Lafaiete"
    assert identificar_base("João Paulo - JFBF") == "JFBF"
    assert identificar_base("JF - Centro") == "JF Centro"
    assert identificar_base("Freelancer -JFMH") == "JFMH"
    assert identificar_base("Equipe - Ouro Preto") == "Ouro Preto"
    assert identificar_base("Ponte Nova") == "Ponte Nova"
    assert identificar_base("Viçosa") == "Viçosa"


def test_base_generica_preserva_o_ultimo_segmento():
    assert identificar_base("João da Silva - Divinópolis") == "Divinópolis"
