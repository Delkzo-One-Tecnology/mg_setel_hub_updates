from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from contador_uls import ler_concatenado, ler_uls_cronogramas, numero_seguro


AZUL = "1F4E78"
AZUL_CLARO = "D9EAF7"
VERDE = "E2F0D9"
AMARELO = "FFF2CC"
VERMELHO = "FCE4D6"
BRANCO = "FFFFFF"
BORDA = Side(style="thin", color="B7B7B7")


def pasta_dados() -> Path:
    raiz = os.getenv("LOCALAPPDATA") or os.getenv("APPDATA") or str(Path.home())
    caminho = Path(raiz) / "Delkzo" / "ContadorULs"
    caminho.mkdir(parents=True, exist_ok=True)
    return caminho


def carregar_json(caminho: Path, padrao):
    try:
        return json.loads(caminho.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return padrao


def salvar_json(caminho: Path, dados) -> None:
    temporario = caminho.with_suffix(caminho.suffix + ".tmp")
    temporario.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
    temporario.replace(caminho)


def chave_ul(arquivo: str, aba: str, ul: str) -> str:
    return f"{arquivo}|{aba}|{ul}"


def estilizar_cabecalho(ws, linha: int, colunas: int) -> None:
    for celula in ws.iter_cols(min_row=linha, max_row=linha, min_col=1, max_col=colunas):
        c = celula[0]
        c.fill = PatternFill("solid", fgColor=AZUL)
        c.font = Font(color=BRANCO, bold=True)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = Border(left=BORDA, right=BORDA, top=BORDA, bottom=BORDA)
    ws.row_dimensions[linha].height = 32


def finalizar_aba(ws, max_col: int, max_row: int, tabela: bool = True) -> None:
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(max_col)}{max_row}"
    ws.sheet_view.showGridLines = False
    ws.row_dimensions[1].height = 32
    for row in ws.iter_rows(min_row=2, max_row=max_row, max_col=max_col):
        for c in row:
            c.border = Border(bottom=Side(style="hair", color="D9D9D9"))
            c.alignment = Alignment(vertical="center")
    if tabela and max_row >= 2:
        nome = "Tabela" + "".join(ch for ch in ws.title if ch.isalnum())[:20]
        tab = Table(displayName=nome, ref=f"A1:{get_column_letter(max_col)}{max_row}")
        tab.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False,
            showRowStripes=True, showColumnStripes=False
        )
        ws.add_table(tab)


def ajustar_larguras(ws, datas_inicio: int | None = None) -> None:
    limites = {1: 36, 2: 30, 3: 12, 4: 16, 5: 17, 6: 15, 7: 13, 8: 13, 9: 18}
    for coluna in range(1, ws.max_column + 1):
        if datas_inicio and coluna >= datas_inicio:
            largura = 13
        else:
            maior = max((len(str(ws.cell(linha, coluna).value or "")) for linha in range(1, min(ws.max_row, 200) + 1)), default=10)
            largura = min(max(maior + 2, 11), limites.get(coluna, 28))
        ws.column_dimensions[get_column_letter(coluna)].width = largura


def gerar_excel(concatenado: Path, cronogramas: list[Path], destino: Path, ciclo: str, progresso=None) -> dict:
    informar = progresso or (lambda _texto, _valor: None)
    informar("Lendo o concatenado...", 10)
    contagens, datas_concatenado = ler_concatenado(concatenado)
    if not datas_concatenado:
        raise ValueError("O concatenado não possui ULs e datas válidas.")
    ano = max(datas_concatenado).year

    informar("Localizando as ULs nos cronogramas...", 35)
    registros = ler_uls_cronogramas(cronogramas, ano)
    if ciclo in {"97", "98", "99"}:
        registros = [r for r in registros if r.ciclo == ciclo]
    if not registros:
        raise ValueError(f"Nenhuma UL foi encontrada nas abas operacionais de {ano}.")
    uls = {r.ul for r in registros}
    datas = sorted({d for (ul, d), qtd in contagens.items() if ul in uls and qtd and d.weekday() != 6})

    historico_path = pasta_dados() / f"historico_ciclo_{ciclo}.json"
    historico = carregar_json(historico_path, {})
    primeira_execucao = not bool(historico)
    atual = {}
    for r in registros:
        k = chave_ul(r.arquivo, r.aba, r.ul)
        atual[k] = {d.isoformat(): contagens[(r.ul, d)] for d in datas if contagens[(r.ul, d)]}

    informar("Montando o relatório Excel...", 55)
    wb = Workbook()
    wb.remove(wb.active)

    # 1. Contagem acumulada: somente ULs com alguma execução.
    ws = wb.create_sheet("Contagem por UL")
    cab = ["CICLO", "ARQUIVO", "ABA / LEITURISTA", "BLOCO", "ORDEM", "UL", "QTDE. PREVISTA", "TOTAL EXECUTADO", "A EXECUTAR", "EXCEDENTE", *[d.strftime("%d/%m/%Y") for d in datas]]
    ws.append(cab)
    for r in registros:
        por_dia = [contagens[(r.ul, d)] for d in datas]
        total = sum(por_dia)
        if total == 0:
            continue
        previsto = numero_seguro(r.previsto)
        a_executar = max(previsto - total, 0) if isinstance(previsto, (int, float)) else ""
        excedente = max(total - previsto, 0) if isinstance(previsto, (int, float)) else ""
        ws.append([r.ciclo, r.arquivo, r.aba, r.bloco, r.ordem, r.ul, previsto, total, a_executar, excedente, *por_dia])
    estilizar_cabecalho(ws, 1, len(cab))
    ws.conditional_formatting.add(f"J2:J{max(ws.max_row,2)}", CellIsRule(operator="greaterThan", formula=["0"], fill=PatternFill("solid", fgColor=VERMELHO)))
    finalizar_aba(ws, len(cab), ws.max_row)
    ajustar_larguras(ws, 11)

    # Matriz na ordem física dos modelos, pronta para copiar e colar.
    ws = wb.create_sheet("Copiar e colar", 2)
    linha_saida = 1
    grupos = defaultdict(list)
    for r in registros:
        grupos[(r.arquivo, r.aba, r.ciclo, r.bloco, r.datas_bloco)].append(r)
    for (arquivo, aba, ciclo_bloco, bloco, datas_bloco), itens in grupos.items():
        datas_validas = [d for d in datas_bloco if d.weekday() != 6]
        ws.cell(linha_saida, 1, f"{arquivo} | {aba} | CICLO {ciclo_bloco} | BLOCO {bloco}")
        ws.cell(linha_saida, 1).font = Font(bold=True, color=BRANCO)
        ws.cell(linha_saida, 1).fill = PatternFill("solid", fgColor=AZUL)
        linha_saida += 1
        ws.cell(linha_saida, 1, "UL")
        for c, dia in enumerate(datas_validas, 2): ws.cell(linha_saida, c, dia.strftime("%d/%m/%Y"))
        estilizar_cabecalho(ws, linha_saida, max(1, len(datas_validas)+1))
        linha_saida += 1
        for item in itens:
            ws.cell(linha_saida, 1, item.ul)
            for c, dia in enumerate(datas_validas, 2): ws.cell(linha_saida, c, contagens[(item.ul, dia)])
            linha_saida += 1
        linha_saida += 2
    ws.freeze_panes = "A1"; ws.sheet_view.showGridLines = False
    ajustar_larguras(ws, 2)

    # 2. Incrementos desde a execução anterior.
    ws = wb.create_sheet("Novas do dia")
    cab_novas = ["ARQUIVO", "ABA / LEITURISTA", "UL", "TOTAL ANTERIOR", "TOTAL ATUAL", "NOVAS LEITURAS", "NOVA DATA", "QUANTIDADE"]
    ws.append(cab_novas)
    if not primeira_execucao:
        for r in sorted(registros, key=lambda x: (x.arquivo.casefold(), x.aba.casefold(), x.ul)):
            k = chave_ul(r.arquivo, r.aba, r.ul)
            antes = historico.get(k, {})
            agora = atual.get(k, {})
            total_antes = sum(int(v) for v in antes.values())
            total_agora = sum(int(v) for v in agora.values())
            for dia in sorted(set(antes) | set(agora)):
                diferenca = int(agora.get(dia, 0)) - int(antes.get(dia, 0))
                if diferenca > 0:
                    ws.append([r.arquivo, r.aba, r.ul, total_antes, total_agora, total_agora-total_antes, datetime.fromisoformat(dia).date(), diferenca])
    if ws.max_row == 1:
        if primeira_execucao:
            ws.append(["BASE INICIAL CRIADA", "Na próxima execução esta aba mostrará somente os acréscimos.", "", "", "", "", "", ""])
        else:
            ws.append(["SEM NOVAS LEITURAS", "Nenhum acréscimo foi identificado desde o processamento anterior.", "", "", "", "", "", ""])
    estilizar_cabecalho(ws, 1, len(cab_novas))
    for c in ws["G"][1:]:
        c.number_format = "dd/mm/yyyy"
    finalizar_aba(ws, len(cab_novas), ws.max_row)
    ajustar_larguras(ws)

    # 3. Excedentes.
    ws = wb.create_sheet("Excedentes")
    cab_exc = ["ARQUIVO", "ABA / LEITURISTA", "UL", "QTDE. PREVISTA", "TOTAL EXECUTADO", "EXCEDENTE"]
    ws.append(cab_exc)
    for r in registros:
        previsto = numero_seguro(r.previsto)
        total = sum(contagens[(r.ul, d)] for d in datas)
        if isinstance(previsto, (int, float)) and total > previsto:
            ws.append([r.arquivo, r.aba, r.ul, previsto, total, total-previsto])
    if ws.max_row == 1:
        ws.append(["SEM EXCEDENTES", "", "", "", "", 0])
    estilizar_cabecalho(ws, 1, len(cab_exc))
    finalizar_aba(ws, len(cab_exc), ws.max_row)
    ajustar_larguras(ws)

    # 4. ULs previstas sem qualquer execução.
    ws = wb.create_sheet("Sem execução")
    cab_sem = ["ARQUIVO", "ABA / LEITURISTA", "UL", "QTDE. PREVISTA"]
    ws.append(cab_sem)
    for r in registros:
        if not any(contagens[(r.ul, d)] for d in datas):
            ws.append([r.arquivo, r.aba, r.ul, numero_seguro(r.previsto)])
    estilizar_cabecalho(ws, 1, len(cab_sem))
    finalizar_aba(ws, len(cab_sem), ws.max_row)
    ajustar_larguras(ws)

    # 5. Divergências rastreáveis.
    ws = wb.create_sheet("Divergências")
    cab_div = ["TIPO", "ARQUIVO", "ABA / LEITURISTA", "UL", "DETALHE"]
    ws.append(cab_div)
    locais = defaultdict(list)
    for r in registros:
        locais[r.ul].append((r.arquivo, r.aba))
        if not isinstance(numero_seguro(r.previsto), (int, float)):
            ws.append(["PREVISÃO INVÁLIDA", r.arquivo, r.aba, r.ul, "Quantidade prevista vazia ou calculada por fórmula não disponível."])
    for ul, posicoes in locais.items():
        if len(posicoes) > 1:
            ws.append(["UL REPETIDA", posicoes[0][0], posicoes[0][1], ul, f"Encontrada em {len(posicoes)} posições selecionadas."])
    if ws.max_row == 1:
        ws.append(["SEM DIVERGÊNCIAS", "", "", "", ""])
    estilizar_cabecalho(ws, 1, len(cab_div))
    finalizar_aba(ws, len(cab_div), ws.max_row)
    ajustar_larguras(ws)

    # 6. Resumo operacional.
    ws = wb.create_sheet("Resumo", 0)
    executadas = [r for r in registros if any(contagens[(r.ul, d)] for d in datas)]
    total_exec = sum(sum(contagens[(r.ul, d)] for d in datas) for r in executadas)
    resumo = [
        ("RELATÓRIO DE ACOMPANHAMENTO DE ULS", ""),
        ("Ciclo", ciclo),
        ("Data do processamento", datetime.now()),
        ("Concatenado", concatenado.name),
        ("Cronogramas processados", len(cronogramas)),
        ("ULs previstas", len(registros)),
        ("ULs com execução", len(executadas)),
        ("ULs sem execução", len(registros)-len(executadas)),
        ("Total de leituras executadas", total_exec),
        ("Primeira data encontrada", min(datas) if datas else ""),
        ("Última data encontrada", max(datas) if datas else ""),
        ("Comparação diária", "Base inicial criada" if primeira_execucao else "Comparada com o processamento anterior"),
    ]
    for item in resumo:
        ws.append(item)
    ws.merge_cells("A1:D1")
    ws["A1"].fill = PatternFill("solid", fgColor=AZUL)
    ws["A1"].font = Font(color=BRANCO, bold=True, size=16)
    ws["A1"].alignment = Alignment(horizontal="center")
    for linha in range(2, ws.max_row + 1):
        ws.cell(linha, 1).font = Font(bold=True, color=AZUL)
        ws.cell(linha, 1).fill = PatternFill("solid", fgColor=AZUL_CLARO)
    ws["B3"].number_format = "dd/mm/yyyy hh:mm"
    ws["B10"].number_format = "dd/mm/yyyy"
    ws["B11"].number_format = "dd/mm/yyyy"
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 70
    ws.sheet_view.showGridLines = False

    destino.mkdir(parents=True, exist_ok=True)
    nome = f"ACOMPANHAMENTO_ULS_CICLO_{ciclo}_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    saida = destino / nome
    informar("Salvando o relatório...", 90)
    wb.save(saida)
    salvar_json(historico_path, atual)
    informar("Concluído.", 100)
    return {
        "arquivo": str(saida), "uls": len(registros), "executadas": len(executadas),
        "leituras": total_exec, "datas": len(datas), "primeira_execucao": primeira_execucao
    }


def abrir_arquivo(caminho: str) -> None:
    if sys.platform.startswith("win"):
        os.startfile(caminho)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", caminho])
    else:
        subprocess.Popen(["xdg-open", caminho])


def executar_interface() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    config_path = pasta_dados() / "config.json"
    config = carregar_json(config_path, {})
    root = tk.Tk()
    root.title("Sistema de Gestão Logística · Contador de ULs")
    root.geometry("980x720")
    root.minsize(880, 660)
    root.configure(bg="#F3F6F9")

    style = ttk.Style(root)
    try: style.theme_use("clam")
    except tk.TclError: pass
    style.configure("App.TFrame", background="#F3F6F9")
    style.configure("Card.TFrame", background="#FFFFFF", relief="flat")
    style.configure("Card.TLabel", background="#FFFFFF", foreground="#172033", font=("Segoe UI", 10))
    style.configure("CardTitle.TLabel", background="#FFFFFF", foreground="#172033", font=("Segoe UI Semibold", 11))
    style.configure("Muted.TLabel", background="#FFFFFF", foreground="#667085", font=("Segoe UI", 9))
    style.configure("Status.TLabel", background="#FFFFFF", foreground="#344054", font=("Segoe UI Semibold", 10))
    style.configure("Primary.TButton", background="#176B87", foreground="#FFFFFF", borderwidth=0, padding=(22, 13), font=("Segoe UI Semibold", 10))
    style.map("Primary.TButton", background=[("active", "#12566D"), ("disabled", "#9BB6C1")])
    style.configure("Secondary.TButton", background="#EAF2F5", foreground="#176B87", borderwidth=0, padding=(18, 12), font=("Segoe UI Semibold", 10))
    style.map("Secondary.TButton", background=[("active", "#D7E7EC")])
    style.configure("Select.TButton", background="#EEF4F7", foreground="#344054", borderwidth=0, padding=(16, 9), font=("Segoe UI Semibold", 9))
    style.map("Select.TButton", background=[("active", "#DDEAF0")])
    style.configure("App.TEntry", fieldbackground="#F8FAFC", foreground="#344054", bordercolor="#D0D5DD", padding=9)
    style.configure("App.TCombobox", fieldbackground="#F8FAFC", padding=8)
    style.configure("App.Horizontal.TProgressbar", background="#19A7A0", troughcolor="#E5EDF1", borderwidth=0, lightcolor="#19A7A0", darkcolor="#19A7A0")

    concatenado = tk.StringVar(value=config.get("concatenado", ""))
    destino = tk.StringVar(value=config.get("destino", ""))
    ciclo = tk.StringVar(value=config.get("ciclo", "Todos"))
    cronogramas: list[Path] = [Path(p) for p in config.get("cronogramas", []) if Path(p).exists()]
    cronogramas_texto = tk.StringVar(value=f"{len(cronogramas)} arquivo(s) selecionado(s)" if cronogramas else "")
    status = tk.StringVar(value="Selecione os arquivos e gere o acompanhamento.")
    progresso = tk.DoubleVar(value=0)
    ultimo_resultado = tk.StringVar(value="")
    resultado_resumo = tk.StringVar(value="Nenhum relatório gerado nesta sessão.")

    header = tk.Frame(root, bg="#102A43", height=108)
    header.pack(fill="x")
    header.pack_propagate(False)
    marca = tk.Frame(header, bg="#102A43")
    marca.pack(fill="both", expand=True, padx=34, pady=20)
    tk.Label(marca, text="DELKZO ONE TECHNOLOGY", bg="#102A43", fg="#5DD9D0", font=("Segoe UI Semibold", 9)).pack(anchor="w")
    tk.Label(marca, text="Contador de ULs", bg="#102A43", fg="#FFFFFF", font=("Segoe UI Semibold", 23)).pack(anchor="w", pady=(2, 0))
    tk.Label(marca, text="Sistema de Gestão Logística · Acompanhamento rural", bg="#102A43", fg="#B8C7D9", font=("Segoe UI", 10)).pack(anchor="w")

    quadro = ttk.Frame(root, padding=(32, 24, 32, 14), style="App.TFrame")
    quadro.pack(fill="both", expand=True)

    topo = ttk.Frame(quadro, style="App.TFrame")
    topo.pack(fill="x", pady=(0, 12))
    ttk.Label(topo, text="CONFIGURAÇÃO DO PROCESSAMENTO", background="#F3F6F9", foreground="#475467", font=("Segoe UI Semibold", 9)).pack(side="left")
    ttk.Label(topo, text="V3", background="#DDF4F2", foreground="#137A75", font=("Segoe UI Semibold", 9), padding=(10, 4)).pack(side="right")

    card = ttk.Frame(quadro, padding=20, style="Card.TFrame")
    card.pack(fill="x")

    def linha(titulo, variavel, comando):
        ttk.Label(card, text=titulo, style="CardTitle.TLabel").pack(anchor="w")
        f = ttk.Frame(card, style="Card.TFrame"); f.pack(fill="x", pady=(6, 15))
        ttk.Entry(f, textvariable=variavel, state="readonly", style="App.TEntry").pack(side="left", fill="x", expand=True, ipady=3)
        ttk.Button(f, text="SELECIONAR", command=comando, style="Select.TButton").pack(side="left", padx=(10, 0))

    def sel_concat():
        p = filedialog.askopenfilename(title="Selecione o concatenado", filetypes=[("Excel", "*.xlsx")])
        if p: concatenado.set(p)

    def sel_cronos():
        ps = filedialog.askopenfilenames(title="Selecione os cronogramas", filetypes=[("Excel", "*.xlsx")])
        if ps:
            cronogramas[:] = [Path(p) for p in ps]
            cronogramas_texto.set(f"{len(cronogramas)} arquivo(s) selecionado(s)")

    def sel_destino():
        p = filedialog.askdirectory(title="Selecione a pasta dos relatórios")
        if p: destino.set(p)

    linha("Concatenado atualizado", concatenado, sel_concat)
    linha("Cronogramas do ciclo", cronogramas_texto, sel_cronos)
    linha("Pasta dos relatórios", destino, sel_destino)

    fc = ttk.Frame(card, style="Card.TFrame"); fc.pack(fill="x")
    ttk.Label(fc, text="Ciclo a considerar", style="CardTitle.TLabel").pack(side="left")
    ttk.Label(fc, text="O modo Todos identifica o ciclo de cada bloco automaticamente.", style="Muted.TLabel").pack(side="left", padx=(14, 0))
    ttk.Combobox(fc, textvariable=ciclo, values=("Todos", "97", "98", "99"), state="readonly", width=10, style="App.TCombobox").pack(side="right")

    status_card = ttk.Frame(quadro, padding=18, style="Card.TFrame")
    status_card.pack(fill="x", pady=(14, 0))
    status_top = ttk.Frame(status_card, style="Card.TFrame"); status_top.pack(fill="x")
    ttk.Label(status_top, text="STATUS DO PROCESSAMENTO", style="CardTitle.TLabel").pack(side="left")
    barra = ttk.Progressbar(status_card, variable=progresso, maximum=100, style="App.Horizontal.TProgressbar")
    barra.pack(fill="x", pady=(12, 8), ipady=3)
    ttk.Label(status_card, textvariable=status, style="Status.TLabel").pack(anchor="w")
    ttk.Label(status_card, textvariable=resultado_resumo, style="Muted.TLabel").pack(anchor="w", pady=(4, 0))

    botoes = ttk.Frame(quadro, style="App.TFrame"); botoes.pack(fill="x", pady=(16, 0))
    botao_gerar = ttk.Button(botoes, text="GERAR ACOMPANHAMENTO", style="Primary.TButton")
    botao_gerar.pack(side="left", fill="x", expand=True)
    botao_abrir = ttk.Button(botoes, text="ABRIR RESULTADO", state="disabled", style="Secondary.TButton")
    botao_abrir.pack(side="left", padx=(12, 0))

    def atualizar_progresso(texto, valor):
        root.after(0, lambda: (status.set(texto), progresso.set(valor)))

    def concluir(resultado=None, erro=None):
        botao_gerar.config(state="normal")
        if erro:
            status.set("Falha no processamento.")
            messagebox.showerror("Erro", str(erro))
            return
        ultimo_resultado.set(resultado["arquivo"])
        botao_abrir.config(state="normal")
        status.set("Relatório concluído.")
        resultado_resumo.set(f"{resultado['executadas']} ULs com execução · {resultado['leituras']} leituras · {resultado['datas']} datas consideradas")
        messagebox.showinfo(
            "Concluído",
            f"Relatório criado com sucesso.\n\nULs previstas: {resultado['uls']}\n"
            f"ULs com execução: {resultado['executadas']}\n"
            f"Leituras contabilizadas: {resultado['leituras']}\nDatas encontradas: {resultado['datas']}"
        )

    def iniciar():
        if not concatenado.get() or not cronogramas or not destino.get():
            messagebox.showwarning("Arquivos obrigatórios", "Selecione o concatenado, os cronogramas e a pasta dos relatórios.")
            return
        salvar_json(config_path, {"concatenado": concatenado.get(), "cronogramas": [str(p) for p in cronogramas], "destino": destino.get(), "ciclo": ciclo.get()})
        botao_gerar.config(state="disabled"); botao_abrir.config(state="disabled"); progresso.set(0)

        def trabalho():
            try:
                resultado = gerar_excel(Path(concatenado.get()), cronogramas, Path(destino.get()), ciclo.get(), atualizar_progresso)
                root.after(0, lambda: concluir(resultado=resultado))
            except Exception as exc:
                root.after(0, lambda: concluir(erro=exc))
        threading.Thread(target=trabalho, daemon=True).start()

    botao_gerar.config(command=iniciar)
    botao_abrir.config(command=lambda: abrir_arquivo(ultimo_resultado.get()))
    rodape = tk.Frame(root, bg="#E8EEF3", height=34)
    rodape.pack(fill="x", side="bottom")
    rodape.pack_propagate(False)
    tk.Label(rodape, text="Os cronogramas originais não são alterados.", bg="#E8EEF3", fg="#667085", font=("Segoe UI", 9)).pack(side="left", padx=32)
    tk.Label(rodape, text="@ Delkzo One Technology", bg="#E8EEF3", fg="#475467", font=("Segoe UI Semibold", 9)).pack(side="right", padx=32)
    root.mainloop()


if __name__ == "__main__":
    executar_interface()
