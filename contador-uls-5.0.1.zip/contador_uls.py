from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Iterable

import openpyxl


@dataclass(frozen=True)
class UlCronograma:
    arquivo: str
    aba: str
    ul: str
    previsto: int | float | str | None
    ciclo: str = ""
    bloco: int = 0
    ordem: int = 0
    datas_bloco: tuple[date, ...] = ()


def normalizar_ul(valor):
    if valor is None or isinstance(valor, bool): return None
    if isinstance(valor, (int, float)):
        if isinstance(valor, float) and not valor.is_integer(): return None
        texto = str(int(valor))
    else: texto = re.sub(r"\D", "", str(valor).strip())
    return texto.zfill(8) if 6 <= len(texto) <= 8 else None


def como_data(valor):
    if isinstance(valor, datetime): return valor.date()
    if isinstance(valor, date): return valor
    if isinstance(valor, str):
        for formato in ("%d/%m/%Y", "%Y-%m-%d", "%d/%m/%y"):
            try: return datetime.strptime(valor.strip().split()[0], formato).date()
            except ValueError: pass
    return None


def ler_concatenado(caminho: Path):
    wb = openpyxl.load_workbook(caminho, read_only=True, data_only=True)
    try:
        ws = wb.active
        cab = [str(c.value or "").strip().casefold() for c in next(ws.iter_rows(min_row=1, max_row=1))]
        def localizar(*nomes):
            for nome in nomes:
                for i, titulo in enumerate(cab):
                    if titulo == nome.casefold(): return i
            raise ValueError(f"Coluna não encontrada: {', '.join(nomes)}")
        iu = localizar("Unidade de Leitura", "UL", "U.L.", "U.L.s")
        idata = localizar("Data", "Data de execução", "Data da leitura")
        contagens, datas = Counter(), set()
        for linha in ws.iter_rows(min_row=2, values_only=True):
            ul = normalizar_ul(linha[iu] if iu < len(linha) else None)
            dia = como_data(linha[idata] if idata < len(linha) else None)
            if ul and dia: contagens[(ul, dia)] += 1; datas.add(dia)
        return contagens, datas
    finally: wb.close()


def aba_eh_atual(ws, ano):
    for linha in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 500), max_col=min(ws.max_column, 25), values_only=True):
        for valor in linha:
            dia = como_data(valor)
            if dia and dia.year == ano: return True
    return False


def ler_uls_cronogramas(caminhos: Iterable[Path], ano: int):
    encontrados, vistos = [], set()
    for caminho in caminhos:
        wb = openpyxl.load_workbook(caminho, read_only=True, data_only=False)
        try:
            for ws in wb.worksheets:
                ciclo_atual, bloco, ordem = "", 0, 0
                linhas = list(ws.iter_rows(values_only=True))
                i = 0
                while i < len(linhas):
                    linha = linhas[i]
                    for valor in linha:
                        if isinstance(valor, str):
                            m = re.search(r"CICLO\s*(97|98|99)", valor.upper())
                            if m: ciclo_atual = m.group(1)
                    titulo_ul = str(linha[1] if len(linha) > 1 else "").upper()
                    if "U.L" not in titulo_ul:
                        i += 1; continue
                    bloco += 1
                    datas_bloco = tuple(
                        d for d in (como_data(v) for v in linha[4:])
                        if d and d.year == ano and d.weekday() != 6
                    )
                    j = i + 2
                    while j < len(linhas):
                        atual = linhas[j]
                        if str(atual[0] if atual else "").strip().upper() == "TOTAL": break
                        ul = normalizar_ul(atual[1] if len(atual) > 1 else None)
                        if ul:
                            ordem += 1
                            chave = (caminho.name, ws.title, ciclo_atual, bloco, ul)
                            if chave not in vistos:
                                previsto = atual[2] if len(atual) > 2 else None
                                encontrados.append(UlCronograma(caminho.name, ws.title, ul, previsto, ciclo_atual, bloco, ordem, datas_bloco))
                                vistos.add(chave)
                        j += 1
                    i = j + 1
        finally: wb.close()
    return encontrados


def numero_seguro(valor):
    if isinstance(valor, (int, float)) and not isinstance(valor, bool): return valor
    return "" if valor is None or str(valor).startswith("=") else str(valor)
