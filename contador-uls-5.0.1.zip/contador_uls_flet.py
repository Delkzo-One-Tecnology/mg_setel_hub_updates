from __future__ import annotations

import threading
from pathlib import Path

import flet as ft

from contador_uls_v2 import gerar_excel, abrir_arquivo, carregar_json, salvar_json, pasta_dados


AZUL = "#0F2942"
VERDE = "#0F6E56"
VERDE_CLARO = "#1D9E75"
FUNDO = "#EEF2F6"
SUPERFICIE = "#FFFFFF"
SUPERFICIE_2 = "#F6F8FA"
TEXTO = "#1D2939"
SECUNDARIO = "#475467"
MUTED = "#667085"
BORDER = "#D7DEE5"


def main(page: ft.Page):
    page.title = "Sistema de Gestão Logística · Contador de ULs"
    page.window.width = 960
    page.window.height = 820
    page.window.min_width = 820
    page.window.min_height = 680
    page.bgcolor = FUNDO
    page.padding = 22
    page.theme_mode = ft.ThemeMode.LIGHT
    page.theme = ft.Theme(font_family="Segoe UI", color_scheme_seed=VERDE)

    config_path = pasta_dados() / "config.json"
    config = carregar_json(config_path, {})
    cronogramas: list[Path] = [Path(p) for p in config.get("cronogramas", []) if Path(p).exists()]
    ultimo_resultado = ""

    estilo_campo = dict(read_only=True, border_color=BORDER, bgcolor=SUPERFICIE_2, height=40, text_size=12, expand=True)
    concat_txt = ft.TextField(value=config.get("concatenado", ""), **estilo_campo)
    cronos_txt = ft.TextField(value=f"{len(cronogramas)} arquivo(s) selecionado(s)" if cronogramas else "", **estilo_campo)
    destino_txt = ft.TextField(value=config.get("destino", ""), **estilo_campo)
    ciclo = ft.Dropdown(value=config.get("ciclo", "Todos"), options=[ft.dropdown.Option(x) for x in ("Todos", "97", "98", "99")], width=120, border_color=BORDER, bgcolor=SUPERFICIE_2)
    progresso = ft.ProgressBar(value=0, color=VERDE_CLARO, bgcolor="#E4E9EE", height=6)
    status_icon = ft.Icon(ft.Icons.INFO_OUTLINE, size=18, color=MUTED)
    status = ft.Text("Aguardando configuração", size=14, weight=ft.FontWeight.W_500, color=TEXTO)
    stat_uls = ft.Text("—", size=22, weight=ft.FontWeight.W_500, color=TEXTO)
    stat_leituras = ft.Text("—", size=22, weight=ft.FontWeight.W_500, color=TEXTO)
    stat_datas = ft.Text("—", size=22, weight=ft.FontWeight.W_500, color=TEXTO)

    def snack(texto, cor="#344054"):
        page.snack_bar = ft.SnackBar(ft.Text(texto, color="white"), bgcolor=cor)
        page.snack_bar.open = True
        page.update()

    def selecionou_concat(e: ft.FilePickerResultEvent):
        if e.files:
            concat_txt.value = e.files[0].path
            page.update()

    def selecionou_cronos(e: ft.FilePickerResultEvent):
        if e.files:
            selecionados = {Path(f.path).resolve() for f in e.files}
            cronogramas[:] = sorted(selecionados, key=lambda p: str(p).casefold())
            cronos_txt.value = f"{len(cronogramas)} cronograma(s) selecionado(s)"
            page.update()

    def selecionou_pasta_cronos(e: ft.FilePickerResultEvent):
        if not e.path:
            return
        pasta = Path(e.path)
        encontrados = {
            p.resolve()
            for p in pasta.rglob("*.xlsx")
            if not p.name.startswith("~$")
            and not p.name.upper().startswith("ACOMPANHAMENTO_ULS_")
        }
        if not encontrados:
            snack("Nenhum cronograma .xlsx foi encontrado na pasta selecionada.", "#B54708")
            return
        cronogramas[:] = sorted(encontrados, key=lambda p: str(p).casefold())
        cronos_txt.value = f"{len(cronogramas)} cronograma(s) carregado(s) da pasta"
        snack(f"{len(cronogramas)} cronograma(s) carregado(s).", VERDE)
        page.update()

    def selecionou_destino(e: ft.FilePickerResultEvent):
        if e.path:
            destino_txt.value = e.path
            page.update()

    picker_concat = ft.FilePicker(on_result=selecionou_concat)
    picker_cronos = ft.FilePicker(on_result=selecionou_cronos)
    picker_pasta_cronos = ft.FilePicker(on_result=selecionou_pasta_cronos)
    picker_destino = ft.FilePicker(on_result=selecionou_destino)
    page.overlay.extend([picker_concat, picker_cronos, picker_pasta_cronos, picker_destino])

    def seletor(titulo, subtitulo, campo, clique, icone):
        return ft.Column([
            ft.Row([ft.Icon(icone, size=17, color=SECUNDARIO), ft.Text(titulo, size=14, weight=ft.FontWeight.W_500, color=TEXTO)], spacing=8),
            ft.Text(subtitulo, size=12, color=MUTED),
            ft.Row([campo, ft.OutlinedButton("Selecionar", icon=ft.Icons.FOLDER_OPEN, on_click=clique, height=40, style=ft.ButtonStyle(color=SECUNDARIO, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=7)))], spacing=10),
        ], spacing=4)

    def seletor_cronogramas():
        return ft.Column([
            ft.Row([ft.Icon(ft.Icons.FOLDER_OUTLINED, size=17, color=SECUNDARIO), ft.Text("Modelos de cronograma", size=14, weight=ft.FontWeight.W_500, color=TEXTO)], spacing=8),
            ft.Text("Selecione qualquer quantidade de arquivos ou carregue a pasta completa do contrato.", size=12, color=MUTED),
            ft.Row([
                cronos_txt,
                ft.OutlinedButton("Arquivos", icon=ft.Icons.INSERT_DRIVE_FILE_OUTLINED, on_click=lambda _: picker_cronos.pick_files(allow_multiple=True, allowed_extensions=["xlsx"]), height=40, style=ft.ButtonStyle(color=SECUNDARIO, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=7))),
                ft.OutlinedButton("Pasta", icon=ft.Icons.FOLDER_OPEN, on_click=lambda _: picker_pasta_cronos.get_directory_path(), height=40, style=ft.ButtonStyle(color=SECUNDARIO, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=7))),
            ], spacing=10),
        ], spacing=4)

    abrir_btn = ft.OutlinedButton("Abrir resultado", icon=ft.Icons.OPEN_IN_NEW, disabled=True, height=44, style=ft.ButtonStyle(color=SECUNDARIO, side=ft.BorderSide(1, BORDER), shape=ft.RoundedRectangleBorder(radius=7)))
    gerar_btn = ft.ElevatedButton("Gerar acompanhamento", icon=ft.Icons.PLAY_ARROW_ROUNDED, height=44, expand=True, style=ft.ButtonStyle(bgcolor=VERDE, color="white", shape=ft.RoundedRectangleBorder(radius=7)))

    def atualizar_progresso(texto, valor):
        status.value = texto
        progresso.value = valor / 100
        page.update()

    def processar(_):
        nonlocal ultimo_resultado
        if not concat_txt.value or not cronogramas or not destino_txt.value:
            snack("Selecione o concatenado, os cronogramas e a pasta de saída.", "#B54708")
            return
        salvar_json(config_path, {"concatenado": concat_txt.value, "cronogramas": [str(p) for p in cronogramas], "destino": destino_txt.value, "ciclo": ciclo.value})
        gerar_btn.disabled = True
        abrir_btn.disabled = True
        progresso.value = 0
        status_icon.name = ft.Icons.SYNC
        status_icon.color = VERDE
        status.value = "Processamento em andamento"
        stat_uls.value = stat_leituras.value = stat_datas.value = "—"
        page.update()

        def trabalho():
            nonlocal ultimo_resultado
            try:
                resultado = gerar_excel(Path(concat_txt.value), cronogramas, Path(destino_txt.value), ciclo.value, atualizar_progresso)
                ultimo_resultado = resultado["arquivo"]
                status.value = "Relatório concluído com sucesso."
                status_icon.name = ft.Icons.CHECK_CIRCLE_OUTLINE
                status_icon.color = VERDE
                stat_uls.value = str(resultado["executadas"])
                stat_leituras.value = f"{resultado['leituras']:,}".replace(",", ".")
                stat_datas.value = str(resultado["datas"])
                abrir_btn.disabled = False
                snack("Relatório criado com sucesso.", "#137A75")
            except Exception as exc:
                status.value = "Falha no processamento."
                status_icon.name = ft.Icons.ERROR_OUTLINE
                status_icon.color = "#B42318"
                stat_uls.value = stat_leituras.value = stat_datas.value = "—"
                snack(f"Erro: {exc}", "#B42318")
            finally:
                gerar_btn.disabled = False
                page.update()
        threading.Thread(target=trabalho, daemon=True).start()

    gerar_btn.on_click = processar
    abrir_btn.on_click = lambda _: abrir_arquivo(ultimo_resultado) if ultimo_resultado else None

    header = ft.Container(
        bgcolor=AZUL,
        border_radius=12,
        padding=ft.padding.symmetric(horizontal=28, vertical=20),
        content=ft.Column([
            ft.Text("Contador de ULs", size=24, weight=ft.FontWeight.W_500, color="white"),
            ft.Text("Sistema de gestão logística · Acompanhamento rural", size=13, color="#B8C4D1"),
        ], spacing=2),
    )

    card = ft.Container(
        bgcolor=SUPERFICIE, border_radius=12, padding=ft.padding.symmetric(horizontal=20, vertical=4),
        content=ft.Column([
            ft.Container(seletor("Concatenado atualizado", "Base diária utilizada para a contagem das leituras.", concat_txt, lambda _: picker_concat.pick_files(allowed_extensions=["xlsx"]), ft.Icons.STORAGE), padding=ft.padding.symmetric(vertical=14)),
            ft.Divider(height=1, color=BORDER),
            ft.Container(seletor_cronogramas(), padding=ft.padding.symmetric(vertical=14)),
            ft.Divider(height=1, color=BORDER),
            ft.Container(seletor("Pasta dos relatórios", "Local onde o acompanhamento será salvo.", destino_txt, lambda _: picker_destino.get_directory_path(), ft.Icons.DOWNLOAD_OUTLINED), padding=ft.padding.symmetric(vertical=14)),
            ft.Divider(height=1, color=BORDER),
            ft.Container(ft.Row([ft.Column([ft.Text("Ciclo a considerar", size=14, weight=ft.FontWeight.W_500, color=TEXTO), ft.Text("Todos identifica automaticamente o ciclo de cada bloco.", size=12, color=MUTED)], spacing=2, expand=True), ciclo]), padding=ft.padding.symmetric(vertical=14)),
        ], spacing=0),
    )

    status_card = ft.Container(
        bgcolor=SUPERFICIE, border_radius=12, padding=20,
        content=ft.Column([
            progresso,
            ft.Row([status_icon, status], spacing=8),
            ft.Row([
                ft.Container(ft.Column([ft.Text("ULs com execução", size=12, color=MUTED), stat_uls], spacing=3), bgcolor=SUPERFICIE_2, border_radius=7, padding=12, expand=True),
                ft.Container(ft.Column([ft.Text("Leituras", size=12, color=MUTED), stat_leituras], spacing=3), bgcolor=SUPERFICIE_2, border_radius=7, padding=12, expand=True),
                ft.Container(ft.Column([ft.Text("Datas consideradas", size=12, color=MUTED), stat_datas], spacing=3), bgcolor=SUPERFICIE_2, border_radius=7, padding=12, expand=True),
            ], spacing=12),
        ], spacing=14),
    )

    conteudo = ft.Container(
        bgcolor="#F5F7F9", border_radius=12, padding=ft.padding.only(left=28, top=22, right=28, bottom=18), expand=True,
        content=ft.Column([
            ft.Text("CONFIGURAÇÃO DO PROCESSAMENTO", size=12, weight=ft.FontWeight.W_500, color=MUTED),
            card,
            ft.Text("STATUS DO PROCESSAMENTO", size=12, weight=ft.FontWeight.W_500, color=MUTED),
            status_card,
            ft.Row([gerar_btn, abrir_btn], spacing=12),
            ft.Divider(height=1, color=BORDER),
            ft.Row([ft.Row([ft.Icon(ft.Icons.INFO_OUTLINE, size=15, color=SECUNDARIO), ft.Text("Os cronogramas originais não são alterados.", size=12, color=SECUNDARIO)], spacing=6), ft.Text("© Delkzo One Technology", size=12, color=MUTED)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        ], spacing=14, scroll=ft.ScrollMode.AUTO),
    )
    page.add(
        ft.Column(
            [header, conteudo],
            spacing=8,
            expand=True,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        )
    )


if __name__ == "__main__":
    ft.app(target=main)
